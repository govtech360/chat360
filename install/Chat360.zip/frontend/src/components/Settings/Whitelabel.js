import React, { useEffect, useState, useContext, useRef } from "react";

import Grid from "@material-ui/core/Grid";
import FormControl from "@material-ui/core/FormControl";
import TextField from "@material-ui/core/TextField";
import useSettings from "../../hooks/useSettings";
import { toast } from 'react-toastify';
import { makeStyles } from "@material-ui/core/styles";
import OnlyForSuperUser from "../OnlyForSuperUser";
import useAuth from "../../hooks/useAuth.js/index.js";

import {
  IconButton,
  InputAdornment,
  Button,
  Tooltip,
} from "@material-ui/core";

import { Colorize, AttachFile, Delete, Restore } from "@material-ui/icons";
import ColorPicker from "../ColorPicker";
import ColorModeContext from "../../layout/themeContext";
import api from "../../services/api";
import { getBackendUrl } from "../../config";

import defaultLogoLight from "../../assets/logo-black.png";
import defaultLogoDark from "../../assets/logo-black.png";
import defaultLogoFavicon from "../../assets/favicon.ico";
import ColorBoxModal from "../ColorBoxModal/index.js";

const useStyles = makeStyles((theme) => ({
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  fixedHeightPaper: {
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column",
    height: 240,
  },
  tab: {
    borderRadius: 4,
    width: "100%",
    "& .MuiTab-wrapper": {
      color: "#128c7e"
    },
    "& .MuiTabs-flexContainer": {
      justifyContent: "center"
    }


  },
  paper: {
    padding: theme.spacing(2),
    display: "flex",
    alignItems: "center",
    marginBottom: 12,
    width: "100%",
  },
  cardAvatar: {
    fontSize: "55px",
    color: theme.palette.text.secondary,
    backgroundColor: theme.palette.background.paper,
    width: theme.spacing(7),
    height: theme.spacing(7),
  },
  cardTitle: {
    fontSize: "18px",
    color: theme.palette.primary.main,
  },
  cardSubtitle: {
    color: theme.palette.text.secondary,
    fontSize: "14px",
  },
  alignRight: {
    textAlign: "right",
  },
  fullWidth: {
    width: "100%",
  },
  selectContainer: {
    width: "100%",
    textAlign: "left",
    marginBottom: "16px",
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
      backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.02)",
      transition: "all 0.3s ease",
      "&:hover": {
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.08)" : "rgba(0, 0, 0, 0.04)",
        "& fieldset": {
          borderColor: theme.palette.primary.light,
        },
      },
      "&.Mui-focused": {
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.03)",
        "& fieldset": {
          borderColor: theme.palette.primary.main,
          borderWidth: "2px",
        },
      },
    },
    "& .MuiInputLabel-outlined, & .MuiInputLabel-standard": {
      fontSize: "0.9rem",
      color: theme.palette.text.secondary,
      "&.Mui-focused": {
        color: theme.palette.primary.main,
      },
    },
    "& .MuiInput-underline": {
      "&:before": {
        borderBottomColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.12)",
      },
      "&:hover:not(.Mui-disabled):before": {
        borderBottomColor: theme.palette.primary.light,
      },
      "&:after": {
        borderBottomColor: theme.palette.primary.main,
        borderBottomWidth: "2px",
      },
    },
    "& .MuiOutlinedInput-input, & .MuiInput-input": {
      padding: "12px 14px",
      fontSize: "0.9rem",
      color: theme.palette.text.primary,
    },
    "& .MuiOutlinedInput-notchedOutline": {
      borderColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.12)",
    },
  },
  colorAdorment: {
    width: 20,
    height: 20,
  },

  uploadInput: {
    display: "none",
  },

  appLogoLightPreviewDiv: {
    backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.95)" : "#ffffff",
    padding: "10px",
    borderStyle: "solid",
    borderWidth: "1px",
    borderColor: theme.palette.divider,
    textAlign: "center",
  },

  appLogoDarkPreviewDiv: {
    backgroundColor: theme.palette.mode === "dark" ? "rgba(0, 0, 0, 0.5)" : "#424242",
    padding: "10px",
    borderStyle: "solid",
    borderWidth: "1px",
    borderColor: theme.palette.divider,
    textAlign: "center",
  },

  appLogoFaviconPreviewDiv: {
    padding: "10px",
    borderStyle: "solid",
    borderWidth: "1px",
    borderColor: theme.palette.divider,
    textAlign: "center",
    backgroundColor: theme.palette.background.default,
  },

  appLogoLightPreviewImg: {
    width: "100%",
    maxHeight: 72,
    content: "url(" + theme.calculatedLogoLight() + ")"
  },

  appLogoDarkPreviewImg: {
    width: "100%",
    maxHeight: 72,
    content: "url(" + theme.calculatedLogoDark() + ")"
  },

  appLogoFaviconPreviewImg: {
    width: "100%",
    maxHeight: 72,
    content: "url(" + ((theme.appLogoFavicon) ? theme.appLogoFavicon : "") + ")"
  },
  resetButton: {
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(2),
    borderRadius: 8,
    padding: "8px 24px",
    textTransform: "none",
    fontWeight: 600,
  },
  uploadButton: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    fontWeight: 700,
    padding: "8px 16px",
    fontSize: "0.95rem",
    borderRadius: "10px",
    textTransform: "none",
    boxShadow: `0 2px 8px ${theme.palette.primary.main}4D`,
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: theme.palette.primary.dark,
      boxShadow: `0 4px 12px ${theme.palette.primary.main}80`,
      transform: "translateY(-1px)",
    },
    "&:active": {
      transform: "translateY(0)",
    },
  },
  deleteButton: {
    color: theme.palette.error.main,
    borderColor: theme.palette.error.main,
    fontWeight: 600,
    fontSize: "0.9rem",
    borderRadius: "10px",
    textTransform: "none",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: `${theme.palette.error.main}14`,
      borderColor: theme.palette.error.dark,
      transform: "translateY(-1px)",
    },
  },
  iconButton: {
    color: theme.palette.primary.main,
    padding: "8px",
    transition: "all 0.2s ease",
    "&:hover": {
      backgroundColor: `${theme.palette.primary.main}1A`,
      color: theme.palette.primary.dark,
      transform: "scale(1.1)",
    },
  },
  deleteIconButton: {
    color: theme.palette.error.main,
    padding: "8px",
    transition: "all 0.2s ease",
    "&:hover": {
      backgroundColor: `${theme.palette.error.main}1A`,
      color: theme.palette.error.dark,
      transform: "scale(1.1)",
    },
  },
}));

export default function Whitelabel(props) {
  const { settings } = props;
  const classes = useStyles();
  const [settingsLoaded, setSettingsLoaded] = useState({});

  const { getCurrentUserInfo } = useAuth();
  const [currentUser, setCurrentUser] = useState({});

  const { colorMode } = useContext(ColorModeContext);
  const [primaryColorLightModalOpen, setPrimaryColorLightModalOpen] = useState(false);
  const [primaryColorDarkModalOpen, setPrimaryColorDarkModalOpen] = useState(false);

  const logoLightInput = useRef(null);
  const logoDarkInput = useRef(null);
  const logoFaviconInput = useRef(null);
  const appNameInput = useRef(null);
  const [appName, setAppName] = useState(settingsLoaded.appName || "");

  const { update } = useSettings();

  function updateSettingsLoaded(key, value) {
    console.log("|=========== updateSettingsLoaded ==========|")
    console.log(key, value)
    console.log("|===========================================|")
    if (key === 'primaryColorLight' || key === 'primaryColorDark' || key === 'appName') {
      localStorage.setItem(key, value);
    };
    const newSettings = { ...settingsLoaded };
    newSettings[key] = value;
    setSettingsLoaded(newSettings);
  }

  useEffect(() => {
    getCurrentUserInfo().then(
      (u) => {
        setCurrentUser(u);
      }
    );

    if (Array.isArray(settings) && settings.length) {
      const primaryColorLight = settings.find((s) => s.key === "primaryColorLight")?.value;
      const primaryColorDark = settings.find((s) => s.key === "primaryColorDark")?.value;
      const appLogoLight = settings.find((s) => s.key === "appLogoLight")?.value;
      const appLogoDark = settings.find((s) => s.key === "appLogoDark")?.value;
      const appLogoFavicon = settings.find((s) => s.key === "appLogoFavicon")?.value;
      const appName = settings.find((s) => s.key === "appName")?.value;

      setAppName(appName || "");
      setSettingsLoaded({ ...settingsLoaded, primaryColorLight, primaryColorDark, appLogoLight, appLogoDark, appLogoFavicon, appName });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings]);

  async function handleSaveSetting(key, value) {

    await update({
      key,
      value,
    });
    updateSettingsLoaded(key, value);
    toast.success("Operação atualizada com sucesso.");
  }

  const handleResetWhitelabel = async () => {
    if (!window.confirm("Tem certeza que deseja restaurar todas as configurações de whitelabel para o padrão de fábrica? Esta ação não pode ser desfeita.")) {
      return;
    }

    try {
      // Restaura cores padrão
      await handleSaveSetting("primaryColorLight", "#3E3AF2");
      await handleSaveSetting("primaryColorDark", "#3E3AF2");
      
      // Remove logos customizados
      await handleSaveSetting("appLogoLight", "");
      await handleSaveSetting("appLogoDark", "");
      await handleSaveSetting("appLogoFavicon", "");
      
      // Restaura nome padrão
      await handleSaveSetting("appName", "");

      // Aplica as mudanças no ColorModeContext
      colorMode.setPrimaryColorLight("#3E3AF2");
      colorMode.setPrimaryColorDark("#3E3AF2");
      colorMode.setAppLogoLight(defaultLogoLight);
      colorMode.setAppLogoDark(defaultLogoDark);
      colorMode.setAppLogoFavicon(defaultLogoFavicon);
      colorMode.setAppName("Chat360");

      toast.success("Whitelabel restaurado para o padrão de fábrica com sucesso!");
      
      // Recarrega a página para aplicar todas as mudanças
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      console.error("Erro ao restaurar whitelabel:", error);
      toast.error("Erro ao restaurar configurações. Tente novamente.");
    }
  }

  const uploadLogo = async (e, mode) => {
    if (!e.target.files) {
      return;
    }

    const file = e.target.files[0];
    const formData = new FormData();

    formData.append("typeArch", "logo");
    formData.append("mode", mode);
    formData.append("file", file);

    await api.post("/settings-whitelabel/logo", formData, {
      onUploadProgress: (event) => {
        let progress = Math.round(
          (event.loaded * 100) / event.total
        );
        console.log(
          `A imagem  está ${progress}% carregada... `
        );
      },
    }).then((response) => {
      updateSettingsLoaded(`appLogo${mode}`, response.data);
      colorMode[`setAppLogo${mode}`](getBackendUrl() + "/public/" + response.data);
    }).catch((err) => {
      console.error(
        `Houve um problema ao realizar o upload da imagem.`
      );
      console.log(err);
    });
  };

  return (
    <>
      <Grid spacing={3} container>
        {/* <Grid xs={12} item>
                    <Title>Configurações Gerais</Title>
                </Grid> */}
        <OnlyForSuperUser
          user={currentUser}
          yes={() => (
            <>
              <Grid xs={12} sm={6} md={4} item>
                <FormControl className={classes.selectContainer}>
                  <TextField
                    id="primary-color-light-field"
                    label="Cor Primária Modo Claro"
                    variant="standard"
                    value={settingsLoaded.primaryColorLight || ""}
                    onClick={() => setPrimaryColorLightModalOpen(true)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <div
                            style={{ backgroundColor: settingsLoaded.primaryColorLight }}
                            className={classes.colorAdorment}
                          ></div>
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <IconButton
                          size="small"
                          className={classes.iconButton}
                          onClick={() => setPrimaryColorLightModalOpen(true)}
                        >
                          <Colorize />
                        </IconButton>
                      ),
                    }}
                  />
                </FormControl>
                <ColorBoxModal
                  open={primaryColorLightModalOpen}
                  handleClose={() => setPrimaryColorLightModalOpen(false)}
                  onChange={(color) => {
                    handleSaveSetting("primaryColorLight", `#${color.hex}`);
                    colorMode.setPrimaryColorLight(`#${color.hex}`);
                  }}


                  currentColor={settingsLoaded.primaryColorLight}
                />

              </Grid>
              <Grid xs={12} sm={6} md={4} item>

                <FormControl className={classes.selectContainer}>
                  <TextField
                    id="primary-color-dark-field"
                    label="Cor Primária Modo Escuro"
                    variant="standard"
                    value={settingsLoaded.primaryColorDark || ""}
                    onClick={() => setPrimaryColorDarkModalOpen(true)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <div
                            style={{ backgroundColor: settingsLoaded.primaryColorDark }}
                            className={classes.colorAdorment}
                          ></div>
                        </InputAdornment>
                      ),
                      endAdornment: (
                        <IconButton
                          size="small"
                          className={classes.iconButton}
                          onClick={() => setPrimaryColorDarkModalOpen(true)}
                        >
                          <Colorize />
                        </IconButton>
                      ),
                    }}
                  />
                </FormControl>
                <ColorBoxModal
                  open={primaryColorDarkModalOpen}
                  handleClose={() => setPrimaryColorDarkModalOpen(false)}
                  onChange={(color) => {
                    handleSaveSetting("primaryColorDark", `#${color.hex}`);
                    colorMode.setPrimaryColorDark(`#${color.hex}`);
                  }}
                  currentColor={settingsLoaded.primaryColorDark}
                />
              </Grid>

              <Grid xs={12} sm={6} md={4} item>
                <FormControl className={classes.selectContainer}>
                  <TextField
                    id="appname-field"
                    label="Nome do sistema"
                    variant="standard"
                    name="appName"
                    value={appName}
                    inputRef={appNameInput}
                    onChange={(e) => {
                      setAppName(e.target.value);
                    }}
                    onBlur={async (_) => {
                      await handleSaveSetting("appName", appName);
                      colorMode.setAppName(appName || "Multi100");
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid xs={12} sm={6} md={4} item>
                <FormControl className={classes.selectContainer}>
                  <TextField
                    id="logo-light-upload-field"
                    label="Logotipo claro"
                    variant="standard"
                    value={settingsLoaded.appLogoLight || ""}
                    InputProps={{
                      endAdornment: (
                        <>
                          {settingsLoaded.appLogoLight &&
                            <IconButton
                              size="small"
                              className={classes.deleteIconButton}
                              onClick={() => {
                                handleSaveSetting("appLogoLight", "");
                                colorMode.setAppLogoLight(defaultLogoLight);
                              }
                              }
                            >
                              <Delete />
                            </IconButton>
                          }
                          <input
                            type="file"
                            id="upload-logo-light-button"
                            ref={logoLightInput}
                            className={classes.uploadInput}
                            onChange={(e) => uploadLogo(e, "Light")}
                          />
                          <label htmlFor="upload-logo-light-button">
                            <IconButton
                              size="small"
                              className={classes.iconButton}
                              onClick={
                                () => {
                                  logoLightInput.current.click();
                                }
                              }
                            >
                              <AttachFile />
                            </IconButton>
                          </label>
                        </>
                      ),
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid xs={12} sm={6} md={4} item>
                <FormControl className={classes.selectContainer}>
                  <TextField
                    id="logo-dark-upload-field"
                    label="Logotipo escuro"
                    variant="standard"
                    value={settingsLoaded.appLogoDark || ""}
                    InputProps={{
                      endAdornment: (
                        <>
                          {settingsLoaded.appLogoDark &&
                            <IconButton
                              size="small"
                              className={classes.deleteIconButton}
                              onClick={() => {
                                handleSaveSetting("appLogoDark", "");
                                colorMode.setAppLogoDark(defaultLogoDark);
                              }
                              }
                            >
                              <Delete />
                            </IconButton>
                          }
                          <input
                            type="file"
                            id="upload-logo-dark-button"
                            ref={logoDarkInput}
                            className={classes.uploadInput}
                            onChange={(e) => uploadLogo(e, "Dark")}
                          />
                          <label htmlFor="upload-logo-dark-button">
                            <IconButton
                              size="small"
                              className={classes.iconButton}
                              onClick={
                                () => {
                                  logoDarkInput.current.click();
                                }
                              }
                            >
                              <AttachFile />
                            </IconButton>
                          </label>
                        </>
                      ),
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid xs={12} sm={6} md={4} item>
                <FormControl className={classes.selectContainer}>
                  <TextField
                    id="logo-favicon-upload-field"
                    label="Favicon"
                    variant="standard"
                    value={settingsLoaded.appLogoFavicon || ""}
                    InputProps={{
                      endAdornment: (
                        <>
                          {settingsLoaded.appLogoFavicon &&
                            <IconButton
                              size="small"
                              className={classes.deleteIconButton}
                              onClick={() => {
                                handleSaveSetting("appLogoFavicon", "");
                                colorMode.setAppLogoFavicon(defaultLogoFavicon);
                              }
                              }
                            >
                              <Delete />
                            </IconButton>
                          }
                          <input
                            type="file"
                            id="upload-logo-favicon-button"
                            ref={logoFaviconInput}
                            className={classes.uploadInput}
                            onChange={(e) => uploadLogo(e, "Favicon")}
                          />
                          <label htmlFor="upload-logo-favicon-button">
                            <IconButton
                              size="small"
                              className={classes.iconButton}
                              onClick={
                                () => {
                                  logoFaviconInput.current.click();
                                }
                              }
                            >
                              <AttachFile />
                            </IconButton>
                          </label>
                        </>
                      ),
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid xs={12} sm={6} md={4} item>
                <div className={classes.appLogoLightPreviewDiv}>
                  <img className={classes.appLogoLightPreviewImg} alt="light-logo-preview" />
                </div>
              </Grid>
              <Grid xs={12} sm={6} md={4} item>
                <div className={classes.appLogoDarkPreviewDiv}>
                  <img className={classes.appLogoDarkPreviewImg} alt="dark-logo-preview" />
                </div>
              </Grid>
              <Grid xs={12} sm={6} md={4} item>
                <div className={classes.appLogoFaviconPreviewDiv}>
                  <img className={classes.appLogoFaviconPreviewImg} alt="favicon-preview" />
                </div>
              </Grid>
              <Grid xs={12} item>
                <Tooltip title="Restaura todas as configurações de cores, logos e nome do sistema para os valores originais de fábrica">
                  <Button
                    variant="outlined"
                    color="secondary"
                    className={classes.resetButton}
                    startIcon={<Restore />}
                    onClick={handleResetWhitelabel}
                  >
                    Restaurar Whitelabel Padrão de Fábrica
                  </Button>
                </Tooltip>
              </Grid>
            </>
          )}
        />
      </Grid>
    </>
  );
}
