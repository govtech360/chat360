import React, { useState } from "react";
import { Link as RouterLink } from "react-router-dom";
import { Button, TextField, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Fade } from "@mui/material";
import { Helmet } from "react-helmet";
import { toast } from "react-toastify";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import SecurityIcon from "@material-ui/icons/Security";
import EmailIcon from "@material-ui/icons/Email";
import { InputAdornment } from "@mui/material";
import toastError from "../../errors/toastError";
import api from "../../services/api";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100vw",
    height: "100vh",
    display: "flex",
    position: "relative",
    overflow: "hidden",
    background: "linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%)",
    "&::before": {
      content: '""',
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 
        "radial-gradient(circle at 20% 50%, rgba(99, 102, 241, 0.15) 0%, transparent 50%)," +
        "radial-gradient(circle at 80% 80%, rgba(139, 92, 246, 0.15) 0%, transparent 50%)",
      animation: "$gradientShift 15s ease infinite",
    },
  },
  "@keyframes gradientShift": {
    "0%, 100%": { opacity: 1 },
    "50%": { opacity: 0.8 },
  },
  "@keyframes fadeInUp": {
    "0%": { opacity: 0, transform: "translateY(30px)" },
    "100%": { opacity: 1, transform: "translateY(0)" },
  },
  "@keyframes slideInRight": {
    "0%": { opacity: 0, transform: "translateX(-30px)" },
    "100%": { opacity: 1, transform: "translateX(0)" },
  },
  "@keyframes floatSlow": {
    "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
    "25%": { transform: "translateY(-15px) rotate(1deg)" },
    "50%": { transform: "translateY(-25px) rotate(-1deg)" },
    "75%": { transform: "translateY(-15px) rotate(1deg)" },
  },
  "@keyframes pulse": {
    "0%, 100%": { boxShadow: "0 0 0 0 rgba(102, 126, 234, 0.7)" },
    "50%": { boxShadow: "0 0 0 15px rgba(102, 126, 234, 0)" },
  },
  contentWrapper: {
    width: "100%",
    maxWidth: "1400px",
    margin: "0 auto",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 40px",
    position: "relative",
    zIndex: 1,
    [theme.breakpoints.down("md")]: {
      justifyContent: "center",
      padding: "20px",
    },
  },
  leftSection: {
    flex: 1,
    paddingRight: "60px",
    animation: "$slideInRight 1s ease-out",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
    [theme.breakpoints.down("md")]: {
      display: "none",
    },
  },
  brandLogoContainer: {
    marginBottom: "40px",
    position: "relative",
    "&::before": {
      content: '""',
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "120%",
      height: "120%",
      background: "radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)",
      borderRadius: "50%",
      animation: "$pulse 3s ease-in-out infinite",
    },
  },
  brandLogo: {
    maxWidth: "280px",
    height: "auto",
    filter: "drop-shadow(0 0 30px rgba(255, 255, 255, 0.5))",
    animation: "$floatSlow 6s ease-in-out infinite",
    position: "relative",
    zIndex: 1,
    [theme.breakpoints.down("lg")]: {
      maxWidth: "220px",
    },
  },
  brandTitle: {
    fontSize: "3.5rem",
    fontWeight: 800,
    color: "#ffffff",
    marginBottom: "20px",
    lineHeight: 1.2,
    textShadow: "0 4px 20px rgba(0,0,0,0.2)",
    [theme.breakpoints.down("lg")]: {
      fontSize: "2.8rem",
    },
  },
  brandSubtitle: {
    fontSize: "1.3rem",
    color: "rgba(255,255,255,0.9)",
    marginBottom: "40px",
    lineHeight: 1.6,
    fontWeight: 400,
  },
  featuresList: {
    listStyle: "none",
    padding: 0,
    margin: "30px 0",
  },
  featureItem: {
    display: "flex",
    alignItems: "center",
    marginBottom: "20px",
    color: "#ffffff",
    fontSize: "1.1rem",
    animation: "$fadeInUp 1s ease-out",
    "&:nth-child(1)": { animationDelay: "0.2s" },
    "&:nth-child(2)": { animationDelay: "0.4s" },
    "&:nth-child(3)": { animationDelay: "0.6s" },
  },
  featureIcon: {
    marginRight: "15px",
    color: "#60a5fa",
    fontSize: "1.5rem",
  },
  formSection: {
    flex: "0 0 480px",
    animation: "$fadeInUp 1s ease-out",
    [theme.breakpoints.down("md")]: {
      flex: "0 0 100%",
      maxWidth: "420px",
    },
  },
  formContainer: {
    background: "rgba(255, 255, 255, 0.98)",
    backdropFilter: "blur(20px)",
    borderRadius: "24px",
    padding: "45px 40px",
    boxShadow: 
      "0 20px 60px rgba(0, 0, 0, 0.3)," +
      "0 0 0 1px rgba(255, 255, 255, 0.1)",
    position: "relative",
    [theme.breakpoints.down("sm")]: {
      padding: "35px 25px",
      borderRadius: "20px",
    },
  },
  formTitle: {
    fontSize: "1.8rem",
    fontWeight: 700,
    color: "#1e293b",
    marginBottom: "10px",
    textAlign: "center",
  },
  formSubtitle: {
    fontSize: "0.95rem",
    color: "#64748b",
    marginBottom: "30px",
    textAlign: "center",
    lineHeight: 1.6,
  },
  inputField: {
    marginBottom: "20px",
    "& .MuiOutlinedInput-root": {
      borderRadius: "12px",
      backgroundColor: "#f8fafc",
      transition: "all 0.3s ease",
      "&:hover": {
        backgroundColor: "#f1f5f9",
        "& fieldset": {
          borderColor: "#a5b4fc",
        },
      },
      "&.Mui-focused": {
        backgroundColor: "#ffffff",
        "& fieldset": {
          borderColor: "#667eea",
          borderWidth: "2px",
        },
      },
    },
    "& .MuiOutlinedInput-input": {
      padding: "13px 14px",
      fontSize: "0.95rem",
    },
    "& .MuiInputLabel-outlined": {
      fontSize: "0.95rem",
      "&.Mui-focused": {
        color: "#667eea",
      },
    },
  },
  submitBtn: {
    marginBottom: "12px",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "#fff",
    padding: "10px",
    fontSize: "1rem",
    fontWeight: 700,
    width: "100%",
    borderRadius: "12px",
    textTransform: "none",
    boxShadow: "0 4px 15px rgba(102, 126, 234, 0.4)",
    transition: "all 0.3s ease",
    "&:hover": {
      background: "linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%)",
      boxShadow: "0 6px 20px rgba(102, 126, 234, 0.6)",
      transform: "translateY(-2px)",
    },
    "&:active": {
      transform: "translateY(0)",
    },
    "&:disabled": {
      background: "#94a3b8",
      color: "#ffffff",
    },
  },
  backToLogin: {
    marginTop: "20px",
    textAlign: "center",
  },
  backToLoginLink: {
    color: "#667eea",
    textDecoration: "none",
    fontSize: "0.95rem",
    fontWeight: 600,
    transition: "all 0.2s ease",
    "&:hover": {
      color: "#5568d3",
      textDecoration: "underline",
    },
  },
  securityBadge: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "25px",
    padding: "12px",
    backgroundColor: "#dbeafe",
    borderRadius: "10px",
    border: "1px solid #93c5fd",
  },
  securityText: {
    display: "flex",
    alignItems: "center",
    fontSize: "0.85rem",
    color: "#1e3a8a",
    fontWeight: 500,
    "& svg": {
      marginRight: "8px",
      fontSize: "1.2rem",
      color: "#2563eb",
    },
  },
  successMessage: {
    backgroundColor: "#d1fae5",
    color: "#065f46",
    padding: "12px 16px",
    borderRadius: "10px",
    marginBottom: "20px",
    fontSize: "0.9rem",
    border: "1px solid #6ee7b7",
    textAlign: "center",
  },
}));

const ForgotPassword = () => {
  const classes = useStyles();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post("/auth/forgot-password", { email });
      toast.success("Link de redefinição de senha enviado com sucesso!");
      setSent(true);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      toastError(err);
    }
  };

  return (
    <>
      <Helmet>
        <title>Redefinir Senha - Chat360</title>
        <meta name="description" content="Recupere sua senha da plataforma Chat360" />
        <link rel="icon" type="image/png" href="/favicon.png" />
        <link rel="shortcut icon" type="image/png" href="/favicon.png" />
      </Helmet>

      <div className={classes.root}>
        <div className={classes.contentWrapper}>
          {/* Seção Esquerda - Branding */}
          <div className={classes.leftSection}>
            <div className={classes.brandLogoContainer}>
              <img 
                src="/logo-vertical-branco.png" 
                alt="Chat360 Logo" 
                className={classes.brandLogo} 
              />
            </div>
            
            <Typography className={classes.brandTitle}>
              Recupere seu<br />Acesso Rapidamente
            </Typography>
            <Typography className={classes.brandSubtitle}>
              Enviaremos um link seguro para redefinir sua senha.<br />
              Processo rápido e seguro.
            </Typography>
            
            <ul className={classes.featuresList}>
              <li className={classes.featureItem}>
                <CheckCircleIcon className={classes.featureIcon} />
                <span>Link válido por 1 hora</span>
              </li>
              <li className={classes.featureItem}>
                <CheckCircleIcon className={classes.featureIcon} />
                <span>Processo seguro e criptografado</span>
              </li>
              <li className={classes.featureItem}>
                <CheckCircleIcon className={classes.featureIcon} />
                <span>Suporte disponível para ajudar</span>
              </li>
            </ul>
          </div>

          {/* Seção Direita - Formulário */}
          <div className={classes.formSection}>
            <Fade in={true} timeout={800}>
              <form className={classes.formContainer} onSubmit={handleSubmit}>
                <Typography className={classes.formTitle}>
                  Redefinir Senha
                </Typography>
                <Typography className={classes.formSubtitle}>
                  Digite seu email cadastrado e enviaremos as instruções para redefinir sua senha.
                </Typography>

                {sent && (
                  <Fade in={true}>
                    <div className={classes.successMessage}>
                      ✅ Email enviado com sucesso! Verifique sua caixa de entrada.
                    </div>
                  </Fade>
                )}

                <TextField
                  label="Email"
                  variant="outlined"
                  fullWidth
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={classes.inputField}
                  disabled={loading || sent}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <EmailIcon style={{ color: "#667eea" }} />
                      </InputAdornment>
                    ),
                  }}
                />

                <Button
                  type="submit"
                  variant="contained"
                  className={classes.submitBtn}
                  disabled={loading || sent}
                  disableElevation
                >
                  {loading ? "Enviando..." : sent ? "Email enviado!" : "Enviar link de redefinição"}
                </Button>

                <div className={classes.backToLogin}>
                  <RouterLink
                    to="/login"
                    className={classes.backToLoginLink}
                  >
                    ← Voltar ao login
                  </RouterLink>
                </div>

                <div className={classes.securityBadge}>
                  <div className={classes.securityText}>
                    <SecurityIcon />
                    <span>Suas informações estão protegidas</span>
                  </div>
                </div>
              </form>
            </Fade>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;