import React, { useState, useEffect } from "react";
import qs from "query-string";
import * as Yup from "yup";
import { useHistory } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
import { toast } from "react-toastify";
import { Formik, Form, Field } from "formik";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import { Fade } from "@mui/material";
import { Helmet } from "react-helmet";
import { FormControl, InputLabel, MenuItem, Select } from "@material-ui/core";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import SecurityIcon from "@material-ui/icons/Security";
import usePlans from "../../hooks/usePlans";
import { i18n } from "../../translate/i18n";
import { openApi } from "../../services/api";
import toastError from "../../errors/toastError";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100vw",
    minHeight: "100vh",
    display: "flex",
    position: "relative",
    overflow: "hidden",
    background: "linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%)",
    "&::before": {
      content: '""',
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 
        "radial-gradient(circle at 20% 50%, rgba(99, 102, 241, 0.15) 0%, transparent 50%)," +
        "radial-gradient(circle at 80% 80%, rgba(139, 92, 246, 0.15) 0%, transparent 50%)",
      animation: "$gradientShift 15s ease infinite",
    },
  },
  "@keyframes gradientShift": {
    "0%, 100%": { opacity: 1 },
    "50%": { opacity: 0.8 },
  },
  "@keyframes fadeInUp": {
    "0%": { opacity: 0, transform: "translateY(30px)" },
    "100%": { opacity: 1, transform: "translateY(0)" },
  },
  "@keyframes slideInRight": {
    "0%": { opacity: 0, transform: "translateX(-30px)" },
    "100%": { opacity: 1, transform: "translateX(0)" },
  },
  "@keyframes floatSlow": {
    "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
    "25%": { transform: "translateY(-15px) rotate(1deg)" },
    "50%": { transform: "translateY(-25px) rotate(-1deg)" },
    "75%": { transform: "translateY(-15px) rotate(1deg)" },
  },
  "@keyframes pulse": {
    "0%, 100%": { boxShadow: "0 0 0 0 rgba(102, 126, 234, 0.7)" },
    "50%": { boxShadow: "0 0 0 15px rgba(102, 126, 234, 0)" },
  },
  contentWrapper: {
    width: "100%",
    maxWidth: "1400px",
    margin: "0 auto",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "40px",
    position: "relative",
    zIndex: 1,
    [theme.breakpoints.down("md")]: {
      justifyContent: "center",
      padding: "20px",
    },
  },
  leftSection: {
    flex: 1,
    paddingRight: "60px",
    animation: "$slideInRight 1s ease-out",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
    [theme.breakpoints.down("md")]: {
      display: "none",
    },
  },
  brandLogoContainer: {
    marginBottom: "40px",
    position: "relative",
    "&::before": {
      content: '""',
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "120%",
      height: "120%",
      background: "radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%)",
      borderRadius: "50%",
      animation: "$pulse 3s ease-in-out infinite",
    },
  },
  brandLogo: {
    maxWidth: "280px",
    height: "auto",
    filter: "drop-shadow(0 0 30px rgba(255, 255, 255, 0.5))",
    animation: "$floatSlow 6s ease-in-out infinite",
    position: "relative",
    zIndex: 1,
    [theme.breakpoints.down("lg")]: {
      maxWidth: "220px",
    },
  },
  brandTitle: {
    fontSize: "3.5rem",
    fontWeight: 800,
    color: "#ffffff",
    marginBottom: "20px",
    lineHeight: 1.2,
    textShadow: "0 4px 20px rgba(0,0,0,0.2)",
    [theme.breakpoints.down("lg")]: {
      fontSize: "2.8rem",
    },
  },
  brandSubtitle: {
    fontSize: "1.3rem",
    color: "rgba(255,255,255,0.9)",
    marginBottom: "40px",
    lineHeight: 1.6,
    fontWeight: 400,
  },
  featuresList: {
    listStyle: "none",
    padding: 0,
    margin: "30px 0",
  },
  featureItem: {
    display: "flex",
    alignItems: "center",
    marginBottom: "20px",
    color: "#ffffff",
    fontSize: "1.1rem",
    animation: "$fadeInUp 1s ease-out",
    "&:nth-child(1)": { animationDelay: "0.2s" },
    "&:nth-child(2)": { animationDelay: "0.4s" },
    "&:nth-child(3)": { animationDelay: "0.6s" },
  },
  featureIcon: {
    marginRight: "15px",
    color: "#60a5fa",
    fontSize: "1.5rem",
  },
  formSection: {
    flex: "0 0 550px",
    animation: "$fadeInUp 1s ease-out",
    [theme.breakpoints.down("md")]: {
      flex: "0 0 100%",
      maxWidth: "550px",
    },
  },
  formContainer: {
    background: "rgba(255, 255, 255, 0.98)",
    backdropFilter: "blur(20px)",
    borderRadius: "24px",
    padding: "40px",
    boxShadow: 
      "0 20px 60px rgba(0, 0, 0, 0.3)," +
      "0 0 0 1px rgba(255, 255, 255, 0.1)",
    position: "relative",
    [theme.breakpoints.down("sm")]: {
      padding: "30px 25px",
      borderRadius: "20px",
    },
  },
  formTitle: {
    fontSize: "1.8rem",
    fontWeight: 700,
    color: "#1e293b",
    marginBottom: "10px",
    textAlign: "center",
  },
  formSubtitle: {
    fontSize: "0.95rem",
    color: "#64748b",
    marginBottom: "30px",
    textAlign: "center",
  },
  form: {
    width: "100%",
  },
  inputField: {
    marginBottom: "16px",
    "& .MuiOutlinedInput-root": {
      borderRadius: "12px",
      backgroundColor: "#f8fafc",
      transition: "all 0.3s ease",
      "&:hover": {
        backgroundColor: "#f1f5f9",
        "& fieldset": {
          borderColor: "#a5b4fc",
        },
      },
      "&.Mui-focused": {
        backgroundColor: "#ffffff",
        "& fieldset": {
          borderColor: "#667eea",
          borderWidth: "2px",
        },
      },
    },
    "& .MuiOutlinedInput-input": {
      padding: "13px 14px",
      fontSize: "0.95rem",
    },
    "& .MuiInputLabel-outlined": {
      fontSize: "0.95rem",
      transform: "translate(14px, 14px) scale(1)",
      "&.MuiInputLabel-shrink": {
        transform: "translate(14px, -6px) scale(0.75)",
      },
      "&.Mui-focused": {
        color: "#667eea",
      },
    },
  },
  submitBtn: {
    marginTop: "20px",
    marginBottom: "12px",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "#fff",
    padding: "10px",
    fontSize: "1rem",
    fontWeight: 700,
    width: "100%",
    borderRadius: "12px",
    textTransform: "none",
    boxShadow: "0 4px 15px rgba(102, 126, 234, 0.4)",
    transition: "all 0.3s ease",
    "&:hover": {
      background: "linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%)",
      boxShadow: "0 6px 20px rgba(102, 126, 234, 0.6)",
      transform: "translateY(-2px)",
    },
    "&:active": {
      transform: "translateY(0)",
    },
  },
  loginLink: {
    marginTop: "20px",
    textAlign: "center",
    "& a": {
      color: "#667eea",
      textDecoration: "none",
      fontSize: "0.95rem",
      fontWeight: 600,
      transition: "all 0.2s ease",
      "&:hover": {
        color: "#5568d3",
        textDecoration: "underline",
      },
    },
  },
  securityBadge: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "20px",
    padding: "12px",
    backgroundColor: "#dbeafe",
    borderRadius: "10px",
    border: "1px solid #93c5fd",
  },
  securityText: {
    display: "flex",
    alignItems: "center",
    fontSize: "0.85rem",
    color: "#1e3a8a",
    fontWeight: 500,
    "& svg": {
      marginRight: "8px",
      fontSize: "1.2rem",
      color: "#2563eb",
    },
  },
}));

const UserSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Campo obrigatório"),
  companyName: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Campo obrigatório"),
  password: Yup.string()
    .min(5, "Mínimo 5 caracteres!")
    .max(50, "Muito longo!")
    .required("Campo obrigatório"),
  email: Yup.string()
    .email("Email inválido")
    .required("Campo obrigatório"),
  phone: Yup.string().required("Campo obrigatório"),
  planId: Yup.string().required("Selecione um plano"),
});

const SignUp = () => {
  const classes = useStyles();
  const history = useHistory();
  const { getPlanList } = usePlans();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [userCreationEnabled, setUserCreationEnabled] = useState(true);

  let companyId = null;
  const params = qs.parse(window.location.search);
  if (params.companyId !== undefined) {
    companyId = params.companyId;
  }

  const initialState = {
    name: "",
    email: "",
    password: "",
    phone: "",
    companyId,
    companyName: "",
    planId: "",
  };

  const [user] = useState(initialState);

  const backendUrl =
    process.env.REACT_APP_BACKEND_URL === "https://localhost:8090"
      ? "https://localhost:8090"
      : process.env.REACT_APP_BACKEND_URL;

  useEffect(() => {
    const fetchUserCreationStatus = async () => {
      try {
        const response = await fetch(`${backendUrl}/settings/userCreation`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch user creation status");
        }

        const data = await response.json();
        const isEnabled = data.userCreation === "enabled";
        setUserCreationEnabled(isEnabled);

        if (!isEnabled) {
          toast.info("Cadastro de novos usuários está desabilitado.");
          history.push("/login");
        }
      } catch (err) {
        console.error("Erro ao verificar userCreation:", err);
        setUserCreationEnabled(false);
        toast.error("Erro ao verificar permissão de cadastro.");
        history.push("/login");
      }
    };

    fetchUserCreationStatus();
  }, [backendUrl, history]);

  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      const planList = await getPlanList({ listPublic: "false" });
      setPlans(planList);
      setLoading(false);
    };
    fetchData();
  }, [getPlanList]);

  const handleSignUp = async (values) => {
    try {
      await openApi.post("/auth/signup", values);
      toast.success(i18n.t("signup.toasts.success"));
      history.push("/login");
    } catch (err) {
      toastError(err);
    }
  };

  if (!userCreationEnabled) {
    return null;
  }

  return (
    <>
      <Helmet>
        <title>Cadastro - Chat360 | Crie sua conta</title>
        <meta name="description" content="Crie sua conta na plataforma Chat360 e comece a gerenciar seus atendimentos" />
        <link rel="icon" type="image/png" href="/favicon.png" />
        <link rel="shortcut icon" type="image/png" href="/favicon.png" />
      </Helmet>

      <div className={classes.root}>
        <div className={classes.contentWrapper}>
          {/* Seção Esquerda - Branding */}
          <div className={classes.leftSection}>
            <div className={classes.brandLogoContainer}>
              <img 
                src="/logo-vertical-branco.png" 
                alt="Chat360 Logo" 
                className={classes.brandLogo} 
              />
            </div>
            
            <Typography className={classes.brandTitle}>
              Comece Agora<br />Gratuitamente
            </Typography>
            <Typography className={classes.brandSubtitle}>
              Crie sua conta e tenha acesso a todas as funcionalidades<br />
              da plataforma mais inovadora de atendimento.
            </Typography>
            
            <ul className={classes.featuresList}>
              <li className={classes.featureItem}>
                <CheckCircleIcon className={classes.featureIcon} />
                <span>Setup rápido em minutos</span>
              </li>
              <li className={classes.featureItem}>
                <CheckCircleIcon className={classes.featureIcon} />
                <span>Suporte técnico especializado</span>
              </li>
              <li className={classes.featureItem}>
                <CheckCircleIcon className={classes.featureIcon} />
                <span>Planos flexíveis para seu negócio</span>
              </li>
            </ul>
          </div>

          {/* Seção Direita - Formulário */}
          <div className={classes.formSection}>
            <Fade in={true} timeout={800}>
              <div className={classes.formContainer}>
                <Typography className={classes.formTitle}>
                  Criar Conta
                </Typography>
                <Typography className={classes.formSubtitle}>
                  Preencha os dados abaixo para começar
                </Typography>

                <Formik
                  initialValues={user}
                  enableReinitialize={true}
                  validationSchema={UserSchema}
                  onSubmit={(values, actions) => {
                    setTimeout(() => {
                      handleSignUp(values);
                      actions.setSubmitting(false);
                    }, 400);
                  }}
                >
                  {({ touched, errors, isSubmitting, isValid, dirty }) => (
                    <Form className={classes.form}>
                      <Grid container spacing={2}>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="companyName"
                            label={i18n.t("signup.form.company")}
                            error={touched.companyName && Boolean(errors.companyName)}
                            helperText={touched.companyName && errors.companyName}
                            name="companyName"
                            autoComplete="companyName"
                            autoFocus
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            autoComplete="name"
                            name="name"
                            error={touched.name && Boolean(errors.name)}
                            helperText={touched.name && errors.name}
                            variant="outlined"
                            fullWidth
                            id="name"
                            label={i18n.t("signup.form.name")}
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="email"
                            label={i18n.t("signup.form.email")}
                            name="email"
                            error={touched.email && Boolean(errors.email)}
                            helperText={touched.email && errors.email}
                            autoComplete="email"
                            inputProps={{ style: { textTransform: "lowercase" } }}
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            name="password"
                            error={touched.password && Boolean(errors.password)}
                            helperText={touched.password && errors.password}
                            label={i18n.t("signup.form.password")}
                            type="password"
                            id="password"
                            autoComplete="current-password"
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="phone"
                            label={i18n.t("signup.form.phone")}
                            name="phone"
                            error={touched.phone && Boolean(errors.phone)}
                            helperText={touched.phone && errors.phone}
                            autoComplete="phone"
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <FormControl fullWidth variant="outlined" className={classes.inputField}>
                            <InputLabel id="plan-selection-label">Plano *</InputLabel>
                            <Field
                              as={Select}
                              labelId="plan-selection-label"
                              id="plan-selection"
                              name="planId"
                              label="Plano *"
                              required
                              error={touched.planId && Boolean(errors.planId)}
                            >
                              {plans.map((plan, key) => (
                                <MenuItem key={key} value={plan.id}>
                                  {plan.name} - Atendentes: {plan.users} - WhatsApp: {plan.connections} - R$ {plan.amount}
                                </MenuItem>
                              ))}
                            </Field>
                            {touched.planId && errors.planId && (
                              <Typography variant="caption" color="error" style={{ marginLeft: 14, marginTop: 4 }}>
                                {errors.planId}
                              </Typography>
                            )}
                          </FormControl>
                        </Grid>
                      </Grid>

                      <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        className={classes.submitBtn}
                        disabled={isSubmitting || !isValid || !dirty}
                      >
                        {isSubmitting ? "Criando conta..." : i18n.t("signup.buttons.submit")}
                      </Button>

                      <div className={classes.loginLink}>
                        <RouterLink to="/login">
                          {i18n.t("signup.buttons.login")}
                        </RouterLink>
                      </div>

                      <div className={classes.securityBadge}>
                        <div className={classes.securityText}>
                          <SecurityIcon />
                          <span>Seus dados estão protegidos e seguros</span>
                        </div>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </Fade>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignUp;