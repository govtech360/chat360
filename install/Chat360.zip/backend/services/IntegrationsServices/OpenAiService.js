"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleOpenAi = void 0;
const wbotMessageListener_1 = require("../WbotServices/wbotMessageListener");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const openai_1 = __importDefault(require("openai"));
const generative_ai_1 = require("@google/generative-ai");
const Message_1 = __importDefault(require("../../models/Message"));
const sessionsOpenAi = [];
const sessionsGemini = [];
const deleteFileSync = (path) => {
    try {
        fs_1.default.unlinkSync(path);
    }
    catch (error) {
        console.error("Erro ao deletar o arquivo:", error);
    }
};
const sanitizeName = (name) => {
    let sanitized = name.split(" ")[0];
    sanitized = sanitized.replace(/[^a-zA-Z0-9]/g, "");
    return sanitized.substring(0, 60);
};
// Prepares the AI messages from past messages
const prepareMessagesAI = (pastMessages, isGeminiModel, promptSystem) => {
    const messagesAI = [];
    // For OpenAI, include the system prompt as a 'system' role
    if (!isGeminiModel) {
        messagesAI.push({ role: "system", content: promptSystem });
    }
    // Map past messages to AI message format
    for (const message of pastMessages) {
        if (message.mediaType === "conversation" || message.mediaType === "extendedTextMessage") {
            if (message.fromMe) {
                messagesAI.push({ role: "assistant", content: message.body });
            }
            else {
                messagesAI.push({ role: "user", content: message.body });
            }
        }
    }
    return messagesAI;
};
// Processes the AI response (text or audio)
const processResponse = async (responseText, wbot, msg, ticket, contact, openAiSettings, ticketTraking) => {
    let response = responseText;
    // Check for transfer action trigger
    if (response?.toLowerCase().includes("ação: transferir para o setor de atendimento")) {
        await (0, wbotMessageListener_1.transferQueue)(openAiSettings.queueId, ticket, contact);
        response = response.replace(/ação: transferir para o setor de atendimento/i, "").trim();
    }
    const publicFolder = path_1.default.resolve(__dirname, "..", "..", "..", "public", `company${ticket.companyId}`);
    // Send response based on preferred format (text or voice)
    if (openAiSettings.voice === "texto") {
        const sentMessage = await wbot.sendMessage(msg.key.remoteJid, {
            text: `\u200e ${response}`,
        });
        await (0, wbotMessageListener_1.verifyMessage)(sentMessage, ticket, contact);
    }
    else {
        const fileNameWithOutExtension = `${ticket.id}_${Date.now()}`;
        try {
            await (0, wbotMessageListener_1.convertTextToSpeechAndSaveToFile)((0, wbotMessageListener_1.keepOnlySpecifiedChars)(response), `${publicFolder}/${fileNameWithOutExtension}`, openAiSettings.voiceKey, openAiSettings.voiceRegion, openAiSettings.voice, "mp3");
            const sendMessage = await wbot.sendMessage(msg.key.remoteJid, {
                audio: { url: `${publicFolder}/${fileNameWithOutExtension}.mp3` },
                mimetype: "audio/mpeg",
                ptt: true,
            });
            await (0, wbotMessageListener_1.verifyMediaMessage)(sendMessage, ticket, contact, ticketTraking, false, false, wbot);
            deleteFileSync(`${publicFolder}/${fileNameWithOutExtension}.mp3`);
            deleteFileSync(`${publicFolder}/${fileNameWithOutExtension}.wav`);
        }
        catch (error) {
            console.error(`Erro para responder com audio: ${error}`);
            // Fallback to text response
            const sentMessage = await wbot.sendMessage(msg.key.remoteJid, {
                text: `\u200e ${response}`,
            });
            await (0, wbotMessageListener_1.verifyMessage)(sentMessage, ticket, contact);
        }
    }
};
// Handles OpenAI request
const handleOpenAIRequest = async (openai, messagesAI, openAiSettings) => {
    try {
        const chat = await openai.chat.completions.create({
            model: openAiSettings.model,
            messages: messagesAI,
            max_tokens: openAiSettings.maxTokens,
            temperature: openAiSettings.temperature,
        });
        return chat.choices[0].message?.content || "";
    }
    catch (error) {
        console.error("OpenAI request error:", error);
        throw error;
    }
};
// Handles Gemini request
const handleGeminiRequest = async (gemini, messagesAI, openAiSettings, bodyMessage, promptSystem) => {
    try {
        const model = gemini.getGenerativeModel({
            model: openAiSettings.model,
            systemInstruction: promptSystem, // Use system instruction for Gemini
        });
        // Map messages to Gemini format
        const geminiHistory = messagesAI.map(msg => ({
            role: msg.role === "assistant" ? "model" : "user",
            parts: [{ text: msg.content }],
        }));
        const chat = model.startChat({ history: geminiHistory });
        const result = await chat.sendMessage(bodyMessage);
        return result.response.text();
    }
    catch (error) {
        console.error("Gemini request error:", error);
        throw error;
    }
};
// Main function to handle AI interactions
const handleOpenAi = async (openAiSettings, msg, wbot, ticket, contact, mediaSent, ticketTraking) => {
    if (contact.disableBot) {
        return;
    }
    const bodyMessage = (0, wbotMessageListener_1.getBodyMessage)(msg);
    if (!bodyMessage && !msg.message?.audioMessage)
        return;
    if (!openAiSettings)
        return;
    if (msg.messageStubType)
        return;
    const publicFolder = path_1.default.resolve(__dirname, "..", "..", "..", "public", `company${ticket.companyId}`);
    const isOpenAIModel = ["gpt-3.5-turbo-1106", "gpt-4o"].includes(openAiSettings.model);
    const isGeminiModel = ["gemini-2.0-pro", "gemini-2.0-flash"].includes(openAiSettings.model);
    let openai = null;
    let gemini = null;
    // Initialize AI provider based on model
    if (isOpenAIModel) {
        const openAiIndex = sessionsOpenAi.findIndex(s => s.id === ticket.id);
        if (openAiIndex === -1) {
            openai = new openai_1.default({ apiKey: openAiSettings.apiKey });
            openai.id = ticket.id;
            sessionsOpenAi.push(openai);
        }
        else {
            openai = sessionsOpenAi[openAiIndex];
        }
    }
    else if (isGeminiModel) {
        const geminiIndex = sessionsGemini.findIndex(s => s.id === ticket.id);
        if (geminiIndex === -1) {
            gemini = new generative_ai_1.GoogleGenerativeAI(openAiSettings.apiKey);
            gemini.id = ticket.id;
            sessionsGemini.push(gemini);
        }
        else {
            gemini = sessionsGemini[geminiIndex];
        }
    }
    else {
        console.error(`Unsupported model: ${openAiSettings.model}`);
        return;
    }
    // Initialize OpenAI for transcription if specified
    if (isOpenAIModel && openAiSettings.openAiApiKey && !openai) {
        const openAiIndex = sessionsOpenAi.findIndex(s => s.id === ticket.id);
        if (openAiIndex === -1) {
            openai = new openai_1.default({ apiKey: openAiSettings.openAiApiKey || openAiSettings.apiKey });
            openai.id = ticket.id;
            sessionsOpenAi.push(openai);
        }
        else {
            openai = sessionsOpenAi[openAiIndex];
        }
    }
    // Fetch past messages
    const messages = await Message_1.default.findAll({
        where: { ticketId: ticket.id },
        order: [["createdAt", "ASC"]],
        limit: openAiSettings.maxMessages,
    });
    // Format system prompt
    const clientName = sanitizeName(contact.name || "Amigo(a)");
    const promptSystem = `Instruções do Sistema:
  - Use o nome ${clientName} nas respostas para que o cliente se sinta mais próximo e acolhido.
  - Certifique-se de que a resposta tenha até ${openAiSettings.maxTokens} tokens e termine de forma completa, sem cortes.
  - Sempre que der, inclua o nome do cliente para tornar o atendimento mais pessoal e gentil. se não souber o nome pergunte
  - Se for preciso transferir para outro setor, comece a resposta com 'Ação: Transferir para o setor de atendimento'.
  
  Prompt Específico:
  ${openAiSettings.prompt}
  
  Siga essas instruções com cuidado para garantir um atendimento claro e amigável em todas as respostas.`;
    // Handle text message
    if (msg.message?.conversation || msg.message?.extendedTextMessage?.text) {
        const messagesAI = prepareMessagesAI(messages, isGeminiModel, promptSystem);
        try {
            let responseText = null;
            if (isOpenAIModel && openai) {
                messagesAI.push({ role: "user", content: bodyMessage });
                responseText = await handleOpenAIRequest(openai, messagesAI, openAiSettings);
            }
            else if (isGeminiModel && gemini) {
                responseText = await handleGeminiRequest(gemini, messagesAI, openAiSettings, bodyMessage, promptSystem);
            }
            if (!responseText) {
                console.error("No response from AI provider");
                return;
            }
            await processResponse(responseText, wbot, msg, ticket, contact, openAiSettings, ticketTraking);
        }
        catch (error) {
            console.error("AI request failed:", error);
            const sentMessage = await wbot.sendMessage(msg.key.remoteJid, {
                text: "Desculpe, estou com dificuldades técnicas para processar sua solicitação no momento. Por favor, tente novamente mais tarde.",
            });
            await (0, wbotMessageListener_1.verifyMessage)(sentMessage, ticket, contact);
        }
    }
    // Handle audio message
    else if (msg.message?.audioMessage && mediaSent) {
        const messagesAI = prepareMessagesAI(messages, isGeminiModel, promptSystem);
        try {
            const mediaUrl = mediaSent.mediaUrl.split("/").pop();
            const audioFilePath = `${publicFolder}/${mediaUrl}`;
            if (!fs_1.default.existsSync(audioFilePath)) {
                console.error(`Arquivo de áudio não encontrado: ${audioFilePath}`);
                const sentMessage = await wbot.sendMessage(msg.key.remoteJid, {
                    text: "Desculpe, não foi possível processar seu áudio. Por favor, tente novamente.",
                });
                await (0, wbotMessageListener_1.verifyMessage)(sentMessage, ticket, contact);
                return;
            }
            let transcription = null;
            if (isOpenAIModel && openai) {
                const file = fs_1.default.createReadStream(audioFilePath);
                const transcriptionResult = await openai.audio.transcriptions.create({
                    model: "whisper-1",
                    file: file,
                });
                transcription = transcriptionResult.text;
                const sentTranscriptMessage = await wbot.sendMessage(msg.key.remoteJid, {
                    text: `🎤 *Sua mensagem de voz:* ${transcription}`,
                });
                await (0, wbotMessageListener_1.verifyMessage)(sentTranscriptMessage, ticket, contact);
                messagesAI.push({ role: "user", content: transcription });
                const responseText = await handleOpenAIRequest(openai, messagesAI, openAiSettings);
                if (responseText) {
                    await processResponse(responseText, wbot, msg, ticket, contact, openAiSettings, ticketTraking);
                }
            }
            else if (isGeminiModel && gemini) {
                const model = gemini.getGenerativeModel({
                    model: openAiSettings.model,
                    systemInstruction: promptSystem,
                });
                const audioFileBase64 = fs_1.default.readFileSync(audioFilePath, { encoding: 'base64' });
                const fileExtension = path_1.default.extname(audioFilePath).toLowerCase();
                let mimeType = 'audio/mp3';
                switch (fileExtension) {
                    case '.wav':
                        mimeType = 'audio/wav';
                        break;
                    case '.mp3':
                        mimeType = 'audio/mp3';
                        break;
                    case '.aac':
                        mimeType = 'audio/aac';
                        break;
                    case '.ogg':
                        mimeType = 'audio/ogg';
                        break;
                    case '.flac':
                        mimeType = 'audio/flac';
                        break;
                    case '.aiff':
                        mimeType = 'audio/aiff';
                        break;
                }
                const transcriptionRequest = await model.generateContent({
                    contents: [
                        {
                            role: "user",
                            parts: [
                                { text: "Gere uma transcrição precisa deste áudio." },
                                {
                                    inlineData: {
                                        mimeType: mimeType,
                                        data: audioFileBase64,
                                    },
                                },
                            ],
                        },
                    ],
                });
                transcription = transcriptionRequest.response.text();
                const sentTranscriptMessage = await wbot.sendMessage(msg.key.remoteJid, {
                    text: `🎤 *Sua mensagem de voz:* ${transcription}`,
                });
                await (0, wbotMessageListener_1.verifyMessage)(sentTranscriptMessage, ticket, contact);
                messagesAI.push({ role: "user", content: transcription });
                const responseText = await handleGeminiRequest(gemini, messagesAI, openAiSettings, transcription, promptSystem);
                if (responseText) {
                    await processResponse(responseText, wbot, msg, ticket, contact, openAiSettings, ticketTraking);
                }
            }
            if (!transcription) {
                console.warn("Transcrição vazia recebida");
                const sentMessage = await wbot.sendMessage(msg.key.remoteJid, {
                    text: "Desculpe, não consegui entender o áudio. Por favor, tente novamente ou envie uma mensagem de texto.",
                });
                await (0, wbotMessageListener_1.verifyMessage)(sentMessage, ticket, contact);
            }
        }
        catch (error) {
            console.error("Erro no processamento de áudio:", error);
            const errorMessage = error?.response?.error?.message || error.message || "Erro desconhecido";
            const sentMessage = await wbot.sendMessage(msg.key.remoteJid, {
                text: `Desculpe, houve um erro ao processar sua mensagem de áudio: ${errorMessage}`,
            });
            await (0, wbotMessageListener_1.verifyMessage)(sentMessage, ticket, contact);
        }
    }
};
exports.handleOpenAi = handleOpenAi;
exports.default = exports.handleOpenAi;
