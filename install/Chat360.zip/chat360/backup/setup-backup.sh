#!/bin/bash
################################################################################
# Chat360 - Configuração Rápida do Sistema de Backup
# 
# Este script configura automaticamente o sistema de backup completo
################################################################################

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Chat360 - Configuração Rápida de Backup          ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════╝${NC}"
echo

# 1. Verificar permissões
echo -e "${YELLOW}[1/6]${NC} Verificando permissões..."
if [ "$EUID" -eq 0 ]; then
    echo -e "${GREEN}✅ Executando como root${NC}"
else
    echo -e "${YELLOW}⚠️  Executando como usuário normal (pode precisar sudo)${NC}"
fi

# 2. Instalar dependências
echo -e "${YELLOW}[2/6]${NC} Instalando dependências..."
MISSING_DEPS=()

command -v pg_dump >/dev/null 2>&1 || MISSING_DEPS+=("postgresql-client")
command -v docker >/dev/null 2>&1 || MISSING_DEPS+=("docker.io")
command -v tar >/dev/null 2>&1 || MISSING_DEPS+=("tar")
command -v rsync >/dev/null 2>&1 || MISSING_DEPS+=("rsync")
command -v jq >/dev/null 2>&1 || MISSING_DEPS+=("jq")

if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
    echo "Instalando: ${MISSING_DEPS[*]}"
    apt-get update -qq
    apt-get install -y "${MISSING_DEPS[@]}"
    echo -e "${GREEN}✅ Dependências instaladas${NC}"
else
    echo -e "${GREEN}✅ Todas as dependências já instaladas${NC}"
fi

# 3. Criar diretórios
echo -e "${YELLOW}[3/6]${NC} Criando estrutura de diretórios..."
mkdir -p /home/backups/chat360-snapshots/{daily,weekly,monthly}
mkdir -p /home/deploy/chat360
echo -e "${GREEN}✅ Diretórios criados${NC}"

# 4. Verificar conectividade
echo -e "${YELLOW}[4/6]${NC} Verificando conectividade..."

# PostgreSQL
if PGPASSWORD="Hl8760TyFBDkVUvN7069npanM4YEQ5fa" psql -h localhost -p 5432 -U chat360 -d chat360 -c "SELECT 1;" >/dev/null 2>&1; then
    echo -e "${GREEN}✅ PostgreSQL conectado${NC}"
else
    echo -e "${RED}❌ PostgreSQL não acessível${NC}"
fi

# Docker
if docker ps >/dev/null 2>&1; then
    echo -e "${GREEN}✅ Docker acessível${NC}"
else
    echo -e "${YELLOW}⚠️  Docker não acessível (pode precisar sudo)${NC}"
fi

# 5. Configurar backup automático
echo -e "${YELLOW}[5/6]${NC} Configurando backup automático..."

if crontab -l 2>/dev/null | grep -q "backup-manager.sh"; then
    echo -e "${GREEN}✅ Backup automático já configurado${NC}"
else
    echo "Deseja configurar backup automático diário às 3h da manhã? (s/n)"
    read -r response
    if [[ "$response" =~ ^[Ss]$ ]]; then
        # Adicionar ao crontab
        (crontab -l 2>/dev/null; echo "0 3 * * * /home/deploy/chat360/backup/backup-manager.sh backup >> /var/log/chat360-backup.log 2>&1") | crontab -
        echo -e "${GREEN}✅ Backup automático configurado${NC}"
    else
        echo -e "${YELLOW}⏭️  Pulando configuração automática${NC}"
    fi
fi

# 6. Criar primeiro backup de teste
echo -e "${YELLOW}[6/6]${NC} Deseja criar um backup de teste agora? (s/n)"
read -r response
if [[ "$response" =~ ^[Ss]$ ]]; then
    echo "Criando backup..."
    /home/deploy/chat360/backup/backup-manager.sh backup
else
    echo -e "${YELLOW}⏭️  Pulando backup de teste${NC}"
fi

# Resumo final
echo
echo -e "${BLUE}╔════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Configuração Concluída!                           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════╝${NC}"
echo
echo -e "${GREEN}📋 Comandos disponíveis:${NC}"
echo
echo -e "  ${YELLOW}Criar backup:${NC}"
echo "    /home/deploy/chat360/backup/backup-manager.sh backup"
echo
echo -e "  ${YELLOW}Listar backups:${NC}"
echo "    /home/deploy/chat360/backup/backup-manager.sh list"
echo
echo -e "  ${YELLOW}Ver ajuda:${NC}"
echo "    /home/deploy/chat360/backup/backup-manager.sh help"
echo
echo -e "${GREEN}📚 Documentação:${NC}"
echo "    /home/deploy/chat360/backup/README.md"
echo "    /home/deploy/chat360/backup/GUIA_BACKUP_COMPLETO.md"
echo
echo -e "${GREEN}✨ Sistema de backup pronto para uso!${NC}"
echo

