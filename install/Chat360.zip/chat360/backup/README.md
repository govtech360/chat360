# 📦 Sistema de Backup Completo - Chat360

> Sistema oficial de backup completo (snapshot) da aplicação Chat360.  
> Backup de código, banco de dados, Redis, arquivos e configurações.

---

## 📁 Arquivos

```
/home/deploy/chat360/backup/
├── backup-manager.sh          ⭐ Script principal
├── setup-backup.sh            🚀 Configuração inicial
├── sync-backups-s3.sh         ☁️  Sync AWS S3
├── README.md                  📖 Este arquivo (Quick Start)
├── GUIA_BACKUP_COMPLETO.md    📚 Documentação detalhada
└── CHANGELOG.md               📋 Histórico de mudanças
```

---

## 🚀 Quick Start

### 1. Configurar Sistema (Primeira Vez)
```bash
/home/deploy/chat360/backup/setup-backup.sh
```

### 2. Criar Backup Completo
```bash
/home/deploy/chat360/backup/backup-manager.sh backup
```

### 3. Listar Backups
```bash
/home/deploy/chat360/backup/backup-manager.sh list
```

### 4. Restaurar Backup
```bash
/home/deploy/chat360/backup/backup-manager.sh restore [arquivo.tar.gz]
```

### 5. Ver Ajuda
```bash
/home/deploy/chat360/backup/backup-manager.sh help
```

---

## 🎯 O Que é Incluído no Backup

✅ **Código-fonte completo** (frontend + backend)  
✅ **Banco de dados PostgreSQL** (dump completo)  
✅ **Redis** (cache e dados)  
✅ **Arquivos de mídia** (avatars, uploads, certificados)  
✅ **Configurações** (.env, ecosystem.config.js, nginx)  
✅ **Metadata** (versões, checksums, timestamps)  

---

## ⏰ Backup Automático

### Configurar cron para backup diário às 3h da manhã:

```bash
crontab -e
```

Adicione:
```bash
0 3 * * * /home/deploy/chat360/backup/backup-manager.sh backup >> /var/log/chat360-backup.log 2>&1
```

### Verificar logs:
```bash
tail -f /var/log/chat360-backup.log
```

---

## ☁️ Backup Externo (S3)

### 1. Configurar AWS CLI:
```bash
apt-get install -y awscli
aws configure
```

### 2. Editar script S3:
```bash
nano /home/deploy/chat360/backup/sync-backups-s3.sh
```

Altere:
```bash
S3_BUCKET="s3://seu-bucket-aqui/chat360-backups"
```

### 3. Testar sincronização:
```bash
/home/deploy/chat360/backup/sync-backups-s3.sh
```

### 4. Automatizar (após backup local):
```bash
crontab -e
```

Adicione:
```bash
0 4 * * * /home/deploy/chat360/backup/sync-backups-s3.sh >> /var/log/chat360-s3-sync.log 2>&1
```

---

## 📂 Localização dos Backups

```
/home/backups/chat360-snapshots/
├── manual/     → Backups manuais (SEM rotação automática)
├── daily/      → Últimos 7 backups diários (COM rotação automática)
├── weekly/     → Últimos 4 backups semanais (COM rotação automática)
└── monthly/    → Últimos 3 backups mensais (COM rotação automática)
```

**Detecção Inteligente:**
- **Executado manualmente** (via SSH/terminal) → salvo em `manual/`
- **Executado pelo cron** (automático) → salvo em `daily/weekly/monthly/`

**Rotação automática:** Apenas backups automáticos (daily/weekly/monthly) têm rotação. Backups manuais você gerencia quando quiser.

---

## 💡 Casos de Uso Principais

### Backup Manual (Antes de Deploy/Atualização)
```bash
# Criar backup de segurança manual
/home/deploy/chat360/backup/backup-manager.sh backup

# ✅ Será salvo em: /home/backups/chat360-snapshots/manual/

# Fazer deploy...

# Se necessário, restaurar
/home/deploy/chat360/backup/backup-manager.sh restore [arquivo]
```
**Diferença:** Backups manuais não são deletados automaticamente, você controla quando limpar.

### Migração de Servidor
```bash
# Servidor antigo: criar backup
/home/deploy/chat360/backup/backup-manager.sh backup

# Copiar para novo servidor
scp backup.tar.gz usuario@novo-servidor:/tmp/

# Novo servidor: restaurar
/home/deploy/chat360/backup/backup-manager.sh restore /tmp/backup.tar.gz
```

### Teste com Dados de Produção
```bash
# Produção: criar backup
/home/deploy/chat360/backup/backup-manager.sh backup

# Staging: restaurar
/home/deploy/chat360/backup/backup-manager.sh restore [backup-producao]
```

---

## 📊 Melhores Práticas Implementadas

✅ **Regra 3-2-1** (3 cópias, 2 mídias, 1 externa)  
✅ **Rotação automática** (daily/weekly/monthly)  
✅ **Verificação de integridade** (checksums MD5)  
✅ **Metadata** (versões Git, timestamps)  
✅ **Restore automatizado** (5-15 minutos)  
✅ **Backup externo** (AWS S3 opcional)  
✅ **Documentação completa**  

---

---

## 📚 Documentação Completa

Para instruções detalhadas, casos de uso avançados e troubleshooting:

```bash
cat /home/deploy/chat360/backup/GUIA_BACKUP_COMPLETO.md
```

Ou abra o arquivo `GUIA_BACKUP_COMPLETO.md` no seu editor favorito.

---

## 🆘 Suporte Rápido

### Ajuda dos Scripts
```bash
/home/deploy/chat360/backup/backup-manager.sh help
```

### Logs
- **Backup automático**: `/var/log/chat360-backup.log`
- **Sync S3**: `/var/log/chat360-s3-sync.log`
- **Aplicação**: `/home/deploy/chat360/backend/combined.log`

---

---

## ✅ Checklist Inicial

```bash
# 1. Configurar sistema
/home/deploy/chat360/backup/setup-backup.sh

# 2. Criar primeiro backup
/home/deploy/chat360/backup/backup-manager.sh backup

# 3. Verificar backup
/home/deploy/chat360/backup/backup-manager.sh list

# 4. Configurar cron (backup automático)
crontab -e
# Adicione: 0 3 * * * /home/deploy/chat360/backup/backup-manager.sh backup >> /var/log/chat360-backup.log 2>&1

# 5. [Opcional] Configurar backup externo S3
nano /home/deploy/chat360/backup/sync-backups-s3.sh
# Edite o bucket e configure cron
```

---

## 📖 Mais Informações

- **Documentação Completa**: `GUIA_BACKUP_COMPLETO.md`
- **Status**: ✅ Produção-Ready
- **Versão**: 1.1
- **Atualização**: 28/10/2025
- **Novidades**: Backups manuais em diretório separado, formato de data simplificado

---

**🎉 Sistema pronto para uso!** Para mais detalhes, consulte o `GUIA_BACKUP_COMPLETO.md`.

