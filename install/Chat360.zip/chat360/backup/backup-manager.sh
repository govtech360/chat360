#!/bin/bash
################################################################################
# Chat360 - Sistema Completo de Backup e Restore (Snapshot)
# 
# Este script gerencia backups completos da aplicação incluindo:
# - Código-fonte (frontend + backend)
# - Banco de dados PostgreSQL
# - Redis (dados em cache)
# - Arquivos de mídia/uploads
# - Configurações e certificados
# - Node_modules (opcional)
#
# Uso: ./backup-manager.sh [comando] [opções]
################################################################################

set -e  # Parar em caso de erro

# ============================================================================
# CONFIGURAÇÕES
# ============================================================================

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # Sem cor

# Diretórios do projeto
PROJECT_DIR="/home/deploy/chat360"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"

# Diretório de backups
BACKUP_ROOT="/home/backups/chat360-snapshots"
TEMP_DIR="/tmp/chat360-backup-$$"

# Credenciais do banco de dados
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="chat360"
DB_USER="chat360"
DB_PASS="Hl8760TyFBDkVUvN7069npanM4YEQ5fa"

# Redis
REDIS_CONTAINER="redis-chat360"

# Configurações de retenção
KEEP_DAILY=7      # Manter últimos 7 backups diários
KEEP_WEEKLY=4     # Manter últimos 4 backups semanais
KEEP_MONTHLY=3    # Manter últimos 3 backups mensais

# Arquivos/pastas a EXCLUIR do backup (para economizar espaço)
EXCLUDE_PATTERNS=(
    "node_modules"
    ".git"
    "*.log"
    "combined.log"
    "dist"
    "build"
    ".cache"
    "tmp"
    ".env.local"
)

# ============================================================================
# FUNÇÕES AUXILIARES
# ============================================================================

print_header() {
    echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║  Chat360 - Sistema Completo de Backup/Restore (Snapshot)      ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}\n"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ️  $1${NC}"
}

print_step() {
    echo -e "${MAGENTA}▶ $1${NC}"
}

check_dependencies() {
    local missing_deps=()
    
    command -v pg_dump >/dev/null 2>&1 || missing_deps+=("postgresql-client")
    command -v docker >/dev/null 2>&1 || missing_deps+=("docker")
    command -v tar >/dev/null 2>&1 || missing_deps+=("tar")
    command -v rsync >/dev/null 2>&1 || missing_deps+=("rsync")
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        print_error "Dependências faltando: ${missing_deps[*]}"
        echo "Instale com: apt-get install -y ${missing_deps[*]}"
        exit 1
    fi
}

create_backup_structure() {
    mkdir -p "$BACKUP_ROOT"/{daily,weekly,monthly,manual}
    mkdir -p "$TEMP_DIR"
}

cleanup_temp() {
    if [ -d "$TEMP_DIR" ]; then
        rm -rf "$TEMP_DIR"
    fi
}

get_timestamp() {
    date +"%Y%m%d"
}

get_backup_name() {
    local timestamp=$(get_timestamp)
    echo "chat360_snapshot_${timestamp}"
}

is_running_from_cron() {
    # Verifica se está sendo executado pelo cron
    # Cron geralmente não tem SSH_CONNECTION ou SSH_CLIENT definidos
    if [ -n "$SSH_CONNECTION" ] || [ -n "$SSH_CLIENT" ] || [ -n "$SSH_TTY" ]; then
        return 1  # É manual (via SSH)
    fi
    
    # Verifica se tem terminal interativo
    if [ -t 1 ]; then
        return 1  # É manual (tem terminal)
    fi
    
    # Verifica se o processo pai é o cron
    local parent_process=$(ps -o comm= -p $PPID 2>/dev/null)
    if [[ "$parent_process" =~ cron|CRON ]]; then
        return 0  # É cron
    fi
    
    # Se chegou aqui e não tem TERM definido, provavelmente é cron
    if [ -z "$TERM" ] || [ "$TERM" = "dumb" ]; then
        return 0  # É cron
    fi
    
    return 1  # É manual por padrão
}

# ============================================================================
# FUNÇÕES DE BACKUP
# ============================================================================

backup_database() {
    print_step "Fazendo backup do banco de dados PostgreSQL..."
    
    local db_backup_file="$TEMP_DIR/database.sql"
    
    PGPASSWORD="$DB_PASS" pg_dump \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -F p \
        -f "$db_backup_file" \
        2>&1 | grep -v "NOTICE:" || true
    
    if [ $? -eq 0 ]; then
        local size=$(du -h "$db_backup_file" | cut -f1)
        print_success "Banco de dados salvo ($size)"
        
        # Criar checksum
        md5sum "$db_backup_file" > "$db_backup_file.md5"
    else
        print_error "Falha ao fazer backup do banco de dados"
        return 1
    fi
}

backup_redis() {
    print_step "Fazendo backup do Redis..."
    
    # Verificar se container Redis existe
    if docker ps -a --format '{{.Names}}' | grep -q "^${REDIS_CONTAINER}$"; then
        # Forçar save do Redis
        docker exec "$REDIS_CONTAINER" redis-cli SAVE >/dev/null 2>&1 || true
        
        # Copiar dump.rdb
        docker cp "$REDIS_CONTAINER:/data/dump.rdb" "$TEMP_DIR/redis-dump.rdb" 2>/dev/null || {
            print_warning "Não foi possível fazer backup do Redis (pode estar vazio)"
            touch "$TEMP_DIR/redis-dump.rdb"
        }
        
        print_success "Redis salvo"
    else
        print_warning "Container Redis não encontrado, pulando..."
        touch "$TEMP_DIR/redis-dump.rdb"
    fi
}

backup_source_code() {
    print_step "Fazendo backup do código-fonte..."
    
    mkdir -p "$TEMP_DIR/source"
    
    # Construir exclude pattern para rsync
    local exclude_args=""
    for pattern in "${EXCLUDE_PATTERNS[@]}"; do
        exclude_args="$exclude_args --exclude=$pattern"
    done
    
    # Backend
    if [ -d "$BACKEND_DIR" ]; then
        rsync -a $exclude_args "$BACKEND_DIR/" "$TEMP_DIR/source/backend/" 2>/dev/null
        print_success "Backend copiado"
    fi
    
    # Frontend
    if [ -d "$FRONTEND_DIR" ]; then
        rsync -a $exclude_args "$FRONTEND_DIR/" "$TEMP_DIR/source/frontend/" 2>/dev/null
        print_success "Frontend copiado"
    fi
    
    # Arquivos raiz
    if [ -f "$PROJECT_DIR/docker-compose.yml" ]; then
        cp "$PROJECT_DIR/docker-compose.yml" "$TEMP_DIR/source/" 2>/dev/null || true
    fi
    
    if [ -f "$PROJECT_DIR/GUIA_FACEBOOK_INSTAGRAM.md" ]; then
        cp "$PROJECT_DIR/GUIA_FACEBOOK_INSTAGRAM.md" "$TEMP_DIR/source/" 2>/dev/null || true
    fi
}

backup_media_files() {
    print_step "Fazendo backup de arquivos de mídia..."
    
    mkdir -p "$TEMP_DIR/media"
    
    # Avatares e arquivos públicos do backend
    if [ -d "$BACKEND_DIR/public" ]; then
        rsync -a "$BACKEND_DIR/public/" "$TEMP_DIR/media/backend-public/" 2>/dev/null
        local size=$(du -sh "$TEMP_DIR/media/backend-public" | cut -f1)
        print_success "Arquivos públicos do backend salvos ($size)"
    fi
    
    # Arquivos privados
    if [ -d "$BACKEND_DIR/private" ]; then
        rsync -a "$BACKEND_DIR/private/" "$TEMP_DIR/media/backend-private/" 2>/dev/null
        local size=$(du -sh "$TEMP_DIR/media/backend-private" | cut -f1)
        print_success "Arquivos privados do backend salvos ($size)"
    fi
    
    # Certificados
    if [ -d "$BACKEND_DIR/certs" ]; then
        rsync -a "$BACKEND_DIR/certs/" "$TEMP_DIR/media/certs/" 2>/dev/null
        print_success "Certificados salvos"
    fi
}

backup_configurations() {
    print_step "Fazendo backup de configurações..."
    
    mkdir -p "$TEMP_DIR/config"
    
    # Backend .env
    if [ -f "$BACKEND_DIR/.env" ]; then
        cp "$BACKEND_DIR/.env" "$TEMP_DIR/config/backend.env"
    fi
    
    # Frontend .env
    if [ -f "$FRONTEND_DIR/.env" ]; then
        cp "$FRONTEND_DIR/.env" "$TEMP_DIR/config/frontend.env"
    fi
    
    # PM2 ecosystem
    if [ -f "$BACKEND_DIR/ecosystem.config.js" ]; then
        cp "$BACKEND_DIR/ecosystem.config.js" "$TEMP_DIR/config/"
    fi
    
    # Nginx configs (se existirem)
    if [ -d "/etc/nginx/sites-available" ]; then
        find /etc/nginx/sites-available -name "*chat360*" -exec cp {} "$TEMP_DIR/config/" \; 2>/dev/null || true
    fi
    
    print_success "Configurações salvas"
}

create_metadata() {
    print_step "Criando metadata do backup..."
    
    cat > "$TEMP_DIR/backup-info.json" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "hostname": "$(hostname)",
  "project_path": "$PROJECT_DIR",
  "backup_version": "1.0",
  "components": {
    "database": "PostgreSQL $DB_NAME",
    "redis": "Container $REDIS_CONTAINER",
    "backend": "$(cd $BACKEND_DIR 2>/dev/null && git rev-parse --short HEAD 2>/dev/null || echo 'N/A')",
    "frontend": "$(cd $FRONTEND_DIR 2>/dev/null && git rev-parse --short HEAD 2>/dev/null || echo 'N/A')"
  },
  "sizes": {
    "database": "$(du -sh $TEMP_DIR/database.sql 2>/dev/null | cut -f1 || echo '0')",
    "source": "$(du -sh $TEMP_DIR/source 2>/dev/null | cut -f1 || echo '0')",
    "media": "$(du -sh $TEMP_DIR/media 2>/dev/null | cut -f1 || echo '0')"
  },
  "node_versions": {
    "backend": "$(cat $BACKEND_DIR/package.json 2>/dev/null | grep '"node"' || echo 'N/A')",
    "frontend": "$(cat $FRONTEND_DIR/package.json 2>/dev/null | grep '"node"' || echo 'N/A')"
  }
}
EOF
    
    print_success "Metadata criada"
}

compress_backup() {
    local backup_name="$1"
    local backup_type="$2"  # daily, weekly, monthly
    local target_dir="$BACKUP_ROOT/$backup_type"
    local archive_path="$target_dir/${backup_name}.tar.gz"
    
    print_step "Comprimindo backup..."
    
    cd "$TEMP_DIR"
    tar -czf "$archive_path" . 2>/dev/null
    
    if [ $? -eq 0 ]; then
        local size=$(du -h "$archive_path" | cut -f1)
        print_success "Backup comprimido: $archive_path ($size)"
        
        # Criar checksum do arquivo completo
        md5sum "$archive_path" > "$archive_path.md5"
        
        echo "$archive_path"
    else
        print_error "Falha ao comprimir backup"
        return 1
    fi
}

# ============================================================================
# FUNÇÃO PRINCIPAL DE BACKUP
# ============================================================================

do_backup() {
    print_header
    print_info "Iniciando backup completo da aplicação Chat360..."
    echo
    
    local start_time=$(date +%s)
    
    # Preparação
    check_dependencies
    create_backup_structure
    trap cleanup_temp EXIT
    
    # Determinar tipo de backup (manual ou automático: daily, weekly, monthly)
    local backup_type="daily"
    local is_manual=false
    
    if ! is_running_from_cron; then
        # Backup executado manualmente
        backup_type="manual"
        is_manual=true
        print_info "Modo: ${CYAN}BACKUP MANUAL${NC}"
    else
        # Backup executado pelo cron
        local day_of_week=$(date +%u)  # 1-7 (segunda a domingo)
        local day_of_month=$(date +%d)
        
        if [ "$day_of_month" == "01" ]; then
            backup_type="monthly"
        elif [ "$day_of_week" == "7" ]; then  # Domingo
            backup_type="weekly"
        fi
        print_info "Modo: ${CYAN}BACKUP AUTOMÁTICO${NC}"
    fi
    
    print_info "Tipo de backup: ${YELLOW}$backup_type${NC}"
    echo
    
    # Executar backups
    backup_database || exit 1
    backup_redis
    backup_source_code
    backup_media_files
    backup_configurations
    create_metadata
    
    # Comprimir e finalizar
    local backup_name=$(get_backup_name)
    local archive_path=$(compress_backup "$backup_name" "$backup_type")
    
    # Limpar backups antigos (apenas para backups automáticos)
    if [ "$is_manual" = false ]; then
        rotate_backups "$backup_type"
    else
        print_info "Backups manuais não têm rotação automática"
    fi
    
    # Calcular tempo total
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    echo
    print_success "✨ Backup completo finalizado com sucesso!"
    echo
    print_info "Arquivo: ${GREEN}$archive_path${NC}"
    print_info "Tipo: ${YELLOW}$backup_type${NC}"
    print_info "Tempo: ${CYAN}${duration}s${NC}"
    print_info "Tamanho: ${CYAN}$(du -h "$archive_path" | cut -f1)${NC}"
    
    if [ "$is_manual" = true ]; then
        echo
        print_warning "💡 Dica: Backups manuais ficam em: $BACKUP_ROOT/manual/"
        print_warning "    Gerencie o espaço manualmente quando necessário"
    fi
    echo
}

# ============================================================================
# ROTAÇÃO DE BACKUPS
# ============================================================================

rotate_backups() {
    local backup_type="$1"
    local keep_count
    
    case "$backup_type" in
        daily)
            keep_count=$KEEP_DAILY
            ;;
        weekly)
            keep_count=$KEEP_WEEKLY
            ;;
        monthly)
            keep_count=$KEEP_MONTHLY
            ;;
    esac
    
    print_step "Rotacionando backups $backup_type (mantendo últimos $keep_count)..."
    
    local backup_dir="$BACKUP_ROOT/$backup_type"
    local count=$(ls -1 "$backup_dir"/chat360_snapshot_*.tar.gz 2>/dev/null | wc -l)
    
    if [ "$count" -gt "$keep_count" ]; then
        cd "$backup_dir"
        ls -t chat360_snapshot_*.tar.gz | tail -n +$((keep_count + 1)) | while read file; do
            rm -f "$file" "${file}.md5"
            print_info "Removido backup antigo: $file"
        done
    fi
}

# ============================================================================
# FUNÇÕES DE LISTAGEM
# ============================================================================

list_backups() {
    print_header
    
    for backup_type in manual daily weekly monthly; do
        echo -e "${BLUE}═══ Backups ${backup_type^^} ═══${NC}"
        local backup_dir="$BACKUP_ROOT/$backup_type"
        
        if [ -d "$backup_dir" ] && [ "$(ls -A $backup_dir/*.tar.gz 2>/dev/null)" ]; then
            ls -lh "$backup_dir"/*.tar.gz 2>/dev/null | awk '{
                printf "  📦 %s  (%s)  %s %s %s\n", $9, $5, $6, $7, $8
            }' | sed "s|$backup_dir/||g"
        else
            echo "  (Nenhum backup encontrado)"
        fi
        echo
    done
    
    # Estatísticas
    local total_size=$(du -sh "$BACKUP_ROOT" 2>/dev/null | cut -f1 || echo "0")
    local total_count=$(find "$BACKUP_ROOT" -name "*.tar.gz" 2>/dev/null | wc -l)
    
    echo -e "${CYAN}Total: $total_count backups | Espaço usado: $total_size${NC}"
    echo
}

# ============================================================================
# FUNÇÕES DE RESTORE
# ============================================================================

restore_backup() {
    local backup_file="$1"
    
    if [ -z "$backup_file" ]; then
        print_error "Especifique o arquivo de backup"
        echo "Uso: $0 restore /caminho/para/chat360_snapshot_YYYYMMDD_HHMMSS.tar.gz"
        exit 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        print_error "Arquivo não encontrado: $backup_file"
        exit 1
    fi
    
    print_header
    print_warning "═══════════════════════════════════════════════════════════════"
    print_warning "  ATENÇÃO: Esta operação irá SUBSTITUIR a aplicação atual!"
    print_warning "  - Código-fonte (frontend e backend)"
    print_warning "  - Banco de dados completo"
    print_warning "  - Todos os arquivos de mídia"
    print_warning "  - Configurações"
    print_warning "═══════════════════════════════════════════════════════════════"
    echo
    
    read -p "Digite 'RESTAURAR' em letras maiúsculas para confirmar: " confirmacao
    
    if [ "$confirmacao" != "RESTAURAR" ]; then
        print_info "Operação cancelada."
        exit 0
    fi
    
    echo
    print_info "Iniciando processo de restauração..."
    
    local start_time=$(date +%s)
    local restore_temp="/tmp/chat360-restore-$$"
    
    # Criar diretório temporário
    mkdir -p "$restore_temp"
    trap "rm -rf $restore_temp" EXIT
    
    # Verificar checksum
    if [ -f "${backup_file}.md5" ]; then
        print_step "Verificando integridade do backup..."
        cd "$(dirname "$backup_file")"
        if md5sum -c "${backup_file}.md5" >/dev/null 2>&1; then
            print_success "Integridade verificada"
        else
            print_warning "Falha na verificação de integridade, mas continuando..."
        fi
    fi
    
    # Descomprimir
    print_step "Descomprimindo backup..."
    tar -xzf "$backup_file" -C "$restore_temp"
    print_success "Backup descomprimido"
    
    # Parar serviços
    print_step "Parando serviços..."
    systemctl stop nginx 2>/dev/null || true
    pm2 stop all 2>/dev/null || true
    print_success "Serviços parados"
    
    # Fazer backup de segurança antes de restaurar
    print_step "Criando backup de segurança pré-restore..."
    local safety_backup="$BACKUP_ROOT/pre-restore-$(date +%Y%m%d_%H%M%S).tar.gz"
    tar -czf "$safety_backup" -C "$PROJECT_DIR" . 2>/dev/null || true
    print_success "Backup de segurança criado: $safety_backup"
    
    # Restaurar código-fonte
    print_step "Restaurando código-fonte..."
    if [ -d "$restore_temp/source/backend" ]; then
        rsync -a --delete "$restore_temp/source/backend/" "$BACKEND_DIR/"
        print_success "Backend restaurado"
    fi
    
    if [ -d "$restore_temp/source/frontend" ]; then
        rsync -a --delete "$restore_temp/source/frontend/" "$FRONTEND_DIR/"
        print_success "Frontend restaurado"
    fi
    
    # Restaurar configurações
    print_step "Restaurando configurações..."
    if [ -f "$restore_temp/config/backend.env" ]; then
        cp "$restore_temp/config/backend.env" "$BACKEND_DIR/.env"
    fi
    if [ -f "$restore_temp/config/frontend.env" ]; then
        cp "$restore_temp/config/frontend.env" "$FRONTEND_DIR/.env"
    fi
    print_success "Configurações restauradas"
    
    # Restaurar arquivos de mídia
    print_step "Restaurando arquivos de mídia..."
    if [ -d "$restore_temp/media/backend-public" ]; then
        rsync -a "$restore_temp/media/backend-public/" "$BACKEND_DIR/public/"
    fi
    if [ -d "$restore_temp/media/backend-private" ]; then
        rsync -a "$restore_temp/media/backend-private/" "$BACKEND_DIR/private/"
    fi
    if [ -d "$restore_temp/media/certs" ]; then
        rsync -a "$restore_temp/media/certs/" "$BACKEND_DIR/certs/"
    fi
    print_success "Arquivos de mídia restaurados"
    
    # Restaurar banco de dados
    print_step "Restaurando banco de dados..."
    if [ -f "$restore_temp/database.sql" ]; then
        print_info "Limpando banco de dados existente..."
        
        # Garantir que serviços estejam REALMENTE parados
        sleep 2
        
        # Tentar DROP DATABASE WITH FORCE (PostgreSQL 13+) ou método antigo
        local dropped=0
        local max_attempts=10
        
        for attempt in $(seq 1 $max_attempts); do
            # Matar TODAS as conexões ao banco
            PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres << 'EOSQL' >/dev/null 2>&1
UPDATE pg_database SET datallowconn = false WHERE datname = 'chat360';
SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'chat360' AND pid <> pg_backend_pid();
EOSQL
            
            sleep 1
            
            # Tentar DROP com FORCE primeiro (PostgreSQL 13+)
            if PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c \
                "DROP DATABASE IF EXISTS \"$DB_NAME\" WITH (FORCE);" 2>/dev/null; then
                dropped=1
                break
            fi
            
            # Se falhou, tentar método tradicional
            if PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c \
                "DROP DATABASE IF EXISTS \"$DB_NAME\";" 2>/dev/null; then
                dropped=1
                break
            fi
            
            # Se ainda falhou e não é a última tentativa, aguardar mais
            if [ $attempt -lt $max_attempts ]; then
                sleep 2
            fi
        done
        
        if [ $dropped -eq 0 ]; then
            print_error "Não foi possível dropar o banco após $max_attempts tentativas"
            print_info "Tentando limpeza manual das tabelas..."
            
            # Fallback: Limpar todas as tabelas se não conseguir dropar
            PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" << 'EOSQL' 2>/dev/null || true
DO $$ DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public') LOOP
        EXECUTE 'DROP TABLE IF EXISTS ' || quote_ident(r.tablename) || ' CASCADE';
    END LOOP;
END $$;
EOSQL
        fi
        
        # Criar banco novo (se foi dropado)
        if [ $dropped -eq 1 ]; then
            PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres << 'EOSQL' >/dev/null 2>&1
CREATE DATABASE "chat360" OWNER "chat360";
UPDATE pg_database SET datallowconn = true WHERE datname = 'chat360';
EOSQL
        fi
        
        print_info "Restaurando dados do backup..."
        
        # Restaurar dados
        PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" < "$restore_temp/database.sql" 2>&1 | grep -v "NOTICE:" >/dev/null || true
        
        print_success "Banco de dados restaurado completamente"
    fi
    
    # Restaurar Redis
    print_step "Restaurando Redis..."
    if [ -f "$restore_temp/redis-dump.rdb" ] && docker ps -a --format '{{.Names}}' | grep -q "^${REDIS_CONTAINER}$"; then
        docker stop "$REDIS_CONTAINER" >/dev/null 2>&1 || true
        docker cp "$restore_temp/redis-dump.rdb" "$REDIS_CONTAINER:/data/dump.rdb" 2>/dev/null || true
        docker start "$REDIS_CONTAINER" >/dev/null 2>&1 || true
        print_success "Redis restaurado"
    fi
    
    # Reinstalar dependências e rebuild
    print_step "Reinstalando dependências do backend..."
    cd "$BACKEND_DIR"
    if [ -f "package.json" ]; then
        npm install >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            print_success "Dependências do backend instaladas"
        else
            print_warning "Aviso ao instalar dependências do backend"
        fi
    fi
    
    print_step "Rebuilding backend..."
    cd "$BACKEND_DIR"
    if [ -f "package.json" ] && [ -f "tsconfig.json" ]; then
        npm run build >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            print_success "Backend compilado com sucesso"
        else
            print_warning "Aviso ao compilar backend (usando versão existente)"
        fi
    fi
    
    print_step "Reinstalando dependências do frontend..."
    cd "$FRONTEND_DIR"
    if [ -f "package.json" ]; then
        npm install --legacy-peer-deps >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            print_success "Dependências do frontend instaladas"
        else
            print_warning "Aviso ao instalar dependências do frontend"
        fi
    fi
    
    print_step "Rebuilding frontend..."
    cd "$FRONTEND_DIR"
    if [ -f "package.json" ]; then
        npm run build >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            print_success "Frontend compilado com sucesso"
        else
            print_warning "Aviso ao compilar frontend"
        fi
    fi
    
    # Reiniciar serviços
    print_step "Reiniciando serviços..."
    cd "$BACKEND_DIR"
    pm2 restart all 2>/dev/null || pm2 start ecosystem.config.js 2>/dev/null || true
    systemctl start nginx 2>/dev/null || true
    print_success "Serviços reiniciados"
    
    # Calcular tempo total
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    echo
    print_success "✨ Restauração completa finalizada com sucesso!"
    echo
    print_info "Tempo: ${CYAN}${duration}s${NC}"
    print_info "Backup de segurança: ${GREEN}$safety_backup${NC}"
    echo
    print_warning "Recomendações pós-restore:"
    print_info "1. Verifique os logs: tail -f $BACKEND_DIR/combined.log"
    print_info "2. Teste a aplicação no navegador"
    print_info "3. Verifique status: pm2 status"
    echo
}

# ============================================================================
# FUNÇÕES DE INFORMAÇÃO
# ============================================================================

show_info() {
    local backup_file="$1"
    
    if [ -z "$backup_file" ] || [ ! -f "$backup_file" ]; then
        print_error "Especifique um arquivo de backup válido"
        exit 1
    fi
    
    print_header
    print_info "Informações do backup: $backup_file"
    echo
    
    # Extrair metadata
    local temp_meta="/tmp/backup-meta-$$"
    tar -xzf "$backup_file" -C /tmp backup-info.json 2>/dev/null && mv /tmp/backup-info.json "$temp_meta" || {
        print_error "Não foi possível extrair metadata do backup"
        exit 1
    }
    
    # Mostrar informações formatadas
    echo -e "${YELLOW}Timestamp:${NC} $(jq -r '.timestamp' "$temp_meta")"
    echo -e "${YELLOW}Hostname:${NC} $(jq -r '.hostname' "$temp_meta")"
    echo -e "${YELLOW}Caminho:${NC} $(jq -r '.project_path' "$temp_meta")"
    echo
    
    echo -e "${BLUE}Componentes:${NC}"
    jq -r '.components | to_entries[] | "  - \(.key): \(.value)"' "$temp_meta"
    echo
    
    echo -e "${BLUE}Tamanhos:${NC}"
    jq -r '.sizes | to_entries[] | "  - \(.key): \(.value)"' "$temp_meta"
    echo
    
    rm "$temp_meta"
}

# ============================================================================
# MENU DE AJUDA
# ============================================================================

show_help() {
    print_header
    
    cat << EOF
${GREEN}COMANDOS DISPONÍVEIS:${NC}

  ${YELLOW}backup${NC}
    Cria um backup completo (snapshot) da aplicação
    Inclui: código-fonte, banco de dados, Redis, arquivos de mídia, configs
    
    ${CYAN}Backup Manual:${NC} Quando executado manualmente, vai para diretório manual/
    ${CYAN}Backup Automático (cron):${NC} Vai para daily/weekly/monthly conforme agendamento
    
    Exemplo:
      ./backup-manager.sh backup

  ${YELLOW}list${NC}
    Lista todos os backups disponíveis por tipo (manual, daily, weekly, monthly)
    
    Exemplo:
      ./backup-manager.sh list

  ${YELLOW}restore <arquivo>${NC}
    Restaura um backup completo
    ⚠️  ATENÇÃO: Substitui TUDO na aplicação atual
    
    Exemplo:
      ./backup-manager.sh restore /home/backups/chat360-snapshots/daily/chat360_snapshot_20251026.tar.gz

  ${YELLOW}info <arquivo>${NC}
    Mostra informações detalhadas sobre um backup
    
    Exemplo:
      ./backup-manager.sh info /home/backups/chat360-snapshots/daily/chat360_snapshot_20251026.tar.gz

  ${YELLOW}help${NC}
    Mostra esta mensagem de ajuda

${GREEN}ESTRUTURA DE DIRETÓRIOS:${NC}

  $BACKUP_ROOT/
    ├── manual/     (backups manuais - SEM rotação automática)
    ├── daily/      (últimos 7 dias - COM rotação automática)
    ├── weekly/     (últimos 4 semanais - COM rotação automática)
    └── monthly/    (últimos 3 mensais - COM rotação automática)

${GREEN}CONTEÚDO DO BACKUP:${NC}

  • Código-fonte (frontend + backend) - SEM node_modules
  • Banco de dados PostgreSQL completo
  • Cache Redis
  • Arquivos de mídia (avatares, uploads, etc)
  • Certificados SSL
  • Configurações (.env, ecosystem.config.js)
  • Metadata (versões, checksums, timestamps)

${GREEN}AGENDAMENTO AUTOMÁTICO:${NC}

  Para backup diário às 3h da manhã:
  
  ${CYAN}crontab -e${NC}
  
  Adicione:
  ${CYAN}0 3 * * * /home/deploy/chat360/backup-manager.sh backup >> /var/log/chat360-backup.log 2>&1${NC}

${GREEN}BOAS PRÁTICAS:${NC}

  1. Faça backups antes de atualizações importantes
  2. Teste restaurações periodicamente
  3. Mantenha backups em local externo (AWS S3, Google Drive, etc)
  4. Monitore o espaço em disco disponível
  5. Documente mudanças críticas na aplicação

${GREEN}LOCALIZAÇÃO DOS BACKUPS:${NC}

  Diretório: ${CYAN}$BACKUP_ROOT${NC}
  
EOF
}

# ============================================================================
# MENU PRINCIPAL
# ============================================================================

case "${1:-}" in
    backup)
        do_backup
        ;;
    list|listar)
        list_backups
        ;;
    restore|restaurar)
        restore_backup "$2"
        ;;
    info)
        show_info "$2"
        ;;
    help|ajuda|--help|-h|"")
        show_help
        ;;
    *)
        print_error "Comando desconhecido: $1"
        echo
        show_help
        exit 1
        ;;
esac

