#!/bin/bash
################################################################################
# Chat360 - Script de Backup Externo para AWS S3
# 
# Este script sincroniza backups locais com AWS S3 para segurança adicional
# Requer: AWS CLI configurado
################################################################################

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
LOCAL_BACKUP_DIR="/home/backups/chat360-snapshots"
S3_BUCKET="s3://seu-bucket-aqui/chat360-backups"  # ALTERAR PARA SEU BUCKET
S3_STORAGE_CLASS="STANDARD_IA"  # Infrequent Access (mais barato)
LOG_FILE="/var/log/chat360-s3-sync.log"

# Função de log
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Verificar se AWS CLI está instalado
if ! command -v aws &> /dev/null; then
    log "❌ ERRO: AWS CLI não está instalado"
    log "Instale com: apt-get install -y awscli"
    exit 1
fi

# Verificar se AWS está configurado
if ! aws sts get-caller-identity &> /dev/null; then
    log "❌ ERRO: AWS CLI não está configurado"
    log "Configure com: aws configure"
    exit 1
fi

log "🚀 Iniciando sincronização de backups para S3..."

# Sincronizar backups
log "📤 Enviando backups para: $S3_BUCKET"

aws s3 sync "$LOCAL_BACKUP_DIR/" "$S3_BUCKET/" \
    --storage-class "$S3_STORAGE_CLASS" \
    --exclude "*" \
    --include "*.tar.gz" \
    --include "*.md5" \
    2>&1 | tee -a "$LOG_FILE"

if [ $? -eq 0 ]; then
    log "✅ Sincronização concluída com sucesso!"
    
    # Estatísticas
    TOTAL_FILES=$(aws s3 ls "$S3_BUCKET/" --recursive | wc -l)
    TOTAL_SIZE=$(aws s3 ls "$S3_BUCKET/" --recursive --human-readable --summarize | grep "Total Size" | awk '{print $3, $4}')
    
    log "📊 Total de arquivos no S3: $TOTAL_FILES"
    log "📦 Tamanho total no S3: $TOTAL_SIZE"
else
    log "❌ Erro na sincronização!"
    exit 1
fi

# Opcional: Remover backups muito antigos do S3 (>180 dias)
log "🧹 Verificando backups antigos no S3..."
aws s3 ls "$S3_BUCKET/" --recursive | while read -r line; do
    FILE_DATE=$(echo "$line" | awk '{print $1}')
    FILE_NAME=$(echo "$line" | awk '{print $4}')
    FILE_TIMESTAMP=$(date -d "$FILE_DATE" +%s)
    CURRENT_TIMESTAMP=$(date +%s)
    AGE_DAYS=$(( (CURRENT_TIMESTAMP - FILE_TIMESTAMP) / 86400 ))
    
    if [ $AGE_DAYS -gt 180 ]; then
        log "🗑️  Removendo backup antigo (${AGE_DAYS} dias): $FILE_NAME"
        aws s3 rm "$S3_BUCKET/$FILE_NAME"
    fi
done

log "✨ Processo finalizado!"

