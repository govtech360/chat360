# 📦 Guia Completo de Backup e Restore - Chat360

## 🎯 Visão Geral

Este sistema implementa **backups completos tipo snapshot** da aplicação Chat360, seguindo as **melhores práticas de mercado**.

### O que é incluído no backup:

✅ **Código-fonte completo** (frontend + backend)  
✅ **Banco de dados PostgreSQL** (dump completo)  
✅ **Redis** (cache e dados em memória)  
✅ **Arquivos de mídia** (avatares, uploads, certificados)  
✅ **Configurações** (.env, ecosystem.config.js, nginx)  
✅ **Metadata** (versões, checksums, timestamps)  

### O que NÃO é incluído (para economizar espaço):

❌ `node_modules` (reinstalado no restore)  
❌ `.git` (histórico não necessário)  
❌ `logs` (arquivos de log)  
❌ `dist/build` (gerado no restore)  

---

## 🚀 Instalação e Configuração

### 1. Script Principal

O script está localizado em:
```bash
/home/deploy/chat360/backup/backup-manager.sh
```

### 2. Verificar Dependências

```bash
# O script verificará automaticamente, mas você pode instalar manualmente:
apt-get update
apt-get install -y postgresql-client docker.io rsync tar jq
```

### 3. Estrutura de Diretórios

Os backups são organizados por tipo:

```
/home/backups/chat360-snapshots/
├── daily/      → Backups diários (mantém últimos 7)
├── weekly/     → Backups semanais (mantém últimos 4)
└── monthly/    → Backups mensais (mantém últimos 3)
```

---

## 📋 Comandos Disponíveis

### 1. Criar Backup Completo

```bash
/home/deploy/chat360/backup/backup-manager.sh backup
```

**O que acontece:**
- Verifica dependências
- Faz backup do PostgreSQL
- Salva dados do Redis
- Copia código-fonte (sem node_modules)
- Copia arquivos de mídia
- Salva todas as configurações
- Cria metadata com checksums
- Comprime tudo em um arquivo `.tar.gz`
- Remove backups antigos automaticamente

**Tipos de backup:**
- **Daily**: Executado em dias normais
- **Weekly**: Executado aos domingos
- **Monthly**: Executado no dia 1 de cada mês

**Tempo estimado:** 2-5 minutos (depende do tamanho)

---

### 2. Listar Backups

```bash
/home/deploy/chat360/backup/backup-manager.sh list
```

**Exemplo de saída:**
```
═══ Backups DAILY ═══
  📦 chat360_snapshot_20251026_120000.tar.gz  (450M)  Oct 26 12:00
  📦 chat360_snapshot_20251025_120000.tar.gz  (448M)  Oct 25 12:00
  📦 chat360_snapshot_20251024_120000.tar.gz  (445M)  Oct 24 12:00

═══ Backups WEEKLY ═══
  📦 chat360_snapshot_20251020_030000.tar.gz  (440M)  Oct 20 03:00
  📦 chat360_snapshot_20251013_030000.tar.gz  (435M)  Oct 13 03:00

═══ Backups MONTHLY ═══
  📦 chat360_snapshot_20251001_030000.tar.gz  (425M)  Oct 01 03:00

Total: 6 backups | Espaço usado: 2.6G
```

---

### 3. Ver Informações de um Backup

```bash
/home/deploy/chat360/backup/backup-manager.sh info /home/backups/chat360-snapshots/daily/chat360_snapshot_20251026_120000.tar.gz
```

**Mostra:**
- Timestamp de criação
- Hostname do servidor
- Versões do código (commits Git)
- Tamanhos dos componentes
- Versões do Node.js

---

### 4. Restaurar Backup Completo

```bash
/home/deploy/chat360/backup/backup-manager.sh restore /home/backups/chat360-snapshots/daily/chat360_snapshot_20251026_120000.tar.gz
```

**⚠️ ATENÇÃO:** Este comando substitui **TUDO** na aplicação atual!

**O que acontece:**
1. Solicita confirmação (digite "RESTAURAR")
2. Verifica integridade do arquivo
3. Para todos os serviços (nginx, PM2)
4. Cria backup de segurança antes de restaurar
5. Restaura código-fonte
6. Restaura configurações
7. Restaura arquivos de mídia
8. Restaura banco de dados
9. Restaura Redis
10. Reinstala dependências (`npm install`)
11. Recompila aplicação (`npm run build`)
12. Reinicia serviços

**Tempo estimado:** 5-15 minutos

---

## ⏰ Agendamento Automático

### Configurar Backup Diário

```bash
# Editar crontab
crontab -e

# Adicionar linha para backup às 3h da manhã
0 3 * * * /home/deploy/chat360/backup/backup-manager.sh backup >> /var/log/chat360-backup.log 2>&1
```

### Verificar Logs de Backup Automático

```bash
tail -f /var/log/chat360-backup.log
```

### Testar Agendamento

```bash
# Ver crontab atual
crontab -l

# Executar manualmente
/home/deploy/chat360/backup-manager.sh backup
```

---

## 💡 Casos de Uso Práticos

### Caso 1: Antes de Atualização Importante

```bash
# 1. Fazer backup manual
/home/deploy/chat360/backup/backup-manager.sh backup

# 2. Verificar que foi criado
/home/deploy/chat360/backup/backup-manager.sh list

# 3. Fazer a atualização...
cd /home/deploy/chat360/backend
git pull
npm install
npm run build
pm2 restart all

# 4. Se algo der errado, restaurar:
/home/deploy/chat360/backup/backup-manager.sh restore /home/backups/chat360-snapshots/daily/chat360_snapshot_[TIMESTAMP].tar.gz
```

---

### Caso 2: Migração para Novo Servidor

```bash
# NO SERVIDOR ANTIGO:
# 1. Criar backup
/home/deploy/chat360/backup/backup-manager.sh backup

# 2. Copiar backup para novo servidor
scp /home/backups/chat360-snapshots/daily/chat360_snapshot_*.tar.gz usuario@novo-servidor:/tmp/

# NO SERVIDOR NOVO:
# 1. Copiar script de backup
scp -r usuario@servidor-antigo:/home/deploy/chat360/backup /home/deploy/chat360/

# 2. Tornar executáveis
chmod +x /home/deploy/chat360/backup/*.sh

# 3. Instalar dependências
apt-get install -y postgresql-client docker.io rsync tar jq

# 4. Criar estrutura de diretórios
mkdir -p /home/deploy/chat360

# 5. Restaurar
/home/deploy/chat360/backup/backup-manager.sh restore /tmp/chat360_snapshot_*.tar.gz
```

---

### Caso 3: Teste de Recuperação de Desastre

```bash
# 1. Fazer backup atual
/home/deploy/chat360/backup/backup-manager.sh backup

# 2. Anotar o nome do arquivo
BACKUP_FILE=$(ls -t /home/backups/chat360-snapshots/daily/chat360_snapshot_*.tar.gz | head -1)
echo $BACKUP_FILE

# 3. Fazer alguma mudança de teste
echo "TESTE" > /home/deploy/chat360/backend/test.txt

# 4. Restaurar
/home/deploy/chat360/backup/backup-manager.sh restore $BACKUP_FILE

# 5. Verificar que o arquivo test.txt não existe mais
ls /home/deploy/chat360/backend/test.txt  # Deve dar erro
```

---

### Caso 4: Desenvolvimento/Staging com Dados de Produção

```bash
# 1. Em produção, fazer backup
ssh producao "/home/deploy/chat360/backup/backup-manager.sh backup"

# 2. Copiar para staging
scp producao:/home/backups/chat360-snapshots/daily/chat360_snapshot_*.tar.gz staging:/tmp/

# 3. Em staging, restaurar
ssh staging "/home/deploy/chat360/backup/backup-manager.sh restore /tmp/chat360_snapshot_*.tar.gz"
```

---

## 🔐 Backup Externo (Recomendado)

Para segurança adicional, copie backups para armazenamento externo:

### Opção 1: AWS S3

```bash
# Instalar AWS CLI
apt-get install -y awscli

# Configurar credenciais
aws configure

# Script para sincronizar backups
cat > /home/deploy/sync-backups-s3.sh << 'EOF'
#!/bin/bash
aws s3 sync /home/backups/chat360-snapshots/ s3://seu-bucket/chat360-backups/ \
    --exclude "*" \
    --include "*.tar.gz" \
    --storage-class STANDARD_IA
EOF

chmod +x /home/deploy/sync-backups-s3.sh

# Adicionar ao cron (às 4h da manhã)
echo "0 4 * * * /home/deploy/sync-backups-s3.sh >> /var/log/s3-sync.log 2>&1" | crontab -
```

### Opção 2: Google Drive (rclone)

```bash
# Instalar rclone
curl https://rclone.org/install.sh | bash

# Configurar Google Drive
rclone config

# Script para sincronizar
cat > /home/deploy/sync-backups-gdrive.sh << 'EOF'
#!/bin/bash
rclone sync /home/backups/chat360-snapshots/ gdrive:chat360-backups/ \
    --include "*.tar.gz" \
    --progress
EOF

chmod +x /home/deploy/sync-backups-gdrive.sh

# Adicionar ao cron
echo "0 4 * * * /home/deploy/sync-backups-gdrive.sh >> /var/log/gdrive-sync.log 2>&1" | crontab -
```

### Opção 3: Servidor Remoto via rsync

```bash
# Configurar SSH sem senha
ssh-keygen -t rsa -b 4096
ssh-copy-id usuario@servidor-backup.com

# Script para sincronizar
cat > /home/deploy/sync-backups-remote.sh << 'EOF'
#!/bin/bash
rsync -avz --progress \
    /home/backups/chat360-snapshots/ \
    usuario@servidor-backup.com:/backups/chat360/
EOF

chmod +x /home/deploy/sync-backups-remote.sh

# Adicionar ao cron
echo "0 4 * * * /home/deploy/sync-backups-remote.sh >> /var/log/remote-sync.log 2>&1" | crontab -
```

---

## 🔍 Monitoramento de Backups

### Script de Verificação

```bash
cat > /home/deploy/check-backups.sh << 'EOF'
#!/bin/bash

echo "=== Status dos Backups Chat360 ==="
echo ""

# Último backup
LAST_BACKUP=$(find /home/backups/chat360-snapshots/ -name "*.tar.gz" -type f -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2)
LAST_DATE=$(stat -c %y "$LAST_BACKUP" | cut -d'.' -f1)

echo "Último backup: $LAST_DATE"
echo "Arquivo: $LAST_BACKUP"
echo ""

# Contagem por tipo
DAILY=$(ls /home/backups/chat360-snapshots/daily/*.tar.gz 2>/dev/null | wc -l)
WEEKLY=$(ls /home/backups/chat360-snapshots/weekly/*.tar.gz 2>/dev/null | wc -l)
MONTHLY=$(ls /home/backups/chat360-snapshots/monthly/*.tar.gz 2>/dev/null | wc -l)

echo "Backups disponíveis:"
echo "  - Diários: $DAILY"
echo "  - Semanais: $WEEKLY"
echo "  - Mensais: $MONTHLY"
echo ""

# Espaço usado
TOTAL_SIZE=$(du -sh /home/backups/chat360-snapshots/ | cut -f1)
echo "Espaço total usado: $TOTAL_SIZE"
echo ""

# Verificar idade do último backup
LAST_TIMESTAMP=$(stat -c %Y "$LAST_BACKUP")
NOW=$(date +%s)
HOURS_AGO=$(( (NOW - LAST_TIMESTAMP) / 3600 ))

if [ $HOURS_AGO -gt 48 ]; then
    echo "⚠️  ALERTA: Último backup tem mais de 48 horas!"
else
    echo "✅ Backups em dia"
fi
EOF

chmod +x /home/deploy/check-backups.sh
```

### Executar Verificação

```bash
/home/deploy/check-backups.sh
```

### Alerta via Email (opcional)

```bash
# Instalar mailutils
apt-get install -y mailutils

# Adicionar ao cron para alertas
echo "0 9 * * * /home/deploy/check-backups.sh | mail -s 'Status Backups Chat360' admin@seudominio.com" | crontab -
```

---

## 📊 Estimativa de Espaço

### Cálculo Aproximado

| Componente | Tamanho Típico |
|-----------|----------------|
| Código-fonte (sem node_modules) | 50-100 MB |
| Banco de dados PostgreSQL | 100-500 MB |
| Redis | 10-50 MB |
| Arquivos de mídia | 200-1000 MB |
| Configurações | 1-5 MB |
| **Total comprimido** | **250-700 MB** |

### Espaço Necessário (com rotação)

- **Diários** (7): ~5 GB
- **Semanais** (4): ~3 GB
- **Mensais** (3): ~2 GB
- **Total**: ~10 GB

**Recomendação:** Reserve pelo menos **20 GB** para backups.

---

## 🛠️ Manutenção

### Limpar Backups Manualmente

```bash
# Listar backups antigos
find /home/backups/chat360-snapshots/ -name "*.tar.gz" -mtime +90

# Remover backups com mais de 90 dias
find /home/backups/chat360-snapshots/ -name "*.tar.gz" -mtime +90 -delete
```

### Verificar Integridade

```bash
# Verificar checksum de um backup
cd /home/backups/chat360-snapshots/daily/
md5sum -c chat360_snapshot_20251026_120000.tar.gz.md5
```

### Compactar Backups Antigos

```bash
# Mover backups mensais antigos para arquivo
mkdir -p /archive/chat360-backups
find /home/backups/chat360-snapshots/monthly/ -name "*.tar.gz" -mtime +180 -exec mv {} /archive/chat360-backups/ \;
```

---

## 🆘 Resolução de Problemas

### Problema: "Espaço insuficiente"

```bash
# Verificar espaço
df -h /home/backups/

# Limpar backups antigos
/home/deploy/chat360/backup-manager.sh list
rm /home/backups/chat360-snapshots/daily/[backup-antigo].tar.gz

# Ou aumentar espaço no volume
```

### Problema: "Falha ao fazer backup do banco"

```bash
# Verificar se PostgreSQL está respondendo
psql -h localhost -U chat360 -d chat360 -c "SELECT version();"

# Verificar logs
tail -f /var/log/postgresql/postgresql-*.log

# Reiniciar PostgreSQL
systemctl restart postgresql
```

### Problema: "Restore falhou"

```bash
# Verificar logs durante restore
tail -f /home/deploy/chat360/backend/combined.log

# Verificar serviços
pm2 status
systemctl status nginx

# Tentar novamente com backup anterior
/home/deploy/chat360/backup-manager.sh list
/home/deploy/chat360/backup-manager.sh restore [backup-anterior]
```

### Problema: "Container Redis não encontrado"

```bash
# Verificar containers
docker ps -a

# Recriar container Redis se necessário
docker run -d --name redis-chat360 -p 5000:6379 redis
```

---

## ✅ Checklist de Boas Práticas

- [ ] Backup automático configurado (cron)
- [ ] Testes de restore realizados mensalmente
- [ ] Backups copiados para armazenamento externo
- [ ] Monitoramento de espaço em disco
- [ ] Alertas configurados para falhas
- [ ] Documentação atualizada
- [ ] Equipe treinada no processo de restore
- [ ] Backup antes de cada deploy importante
- [ ] Verificação de integridade regular
- [ ] Plano de recuperação de desastres documentado

---

## 📚 Comparação: Backup Antigo vs Novo

| Aspecto | Backup Antigo (db-manager.sh) | Backup Novo (backup-manager.sh) |
|---------|-------------------------------|----------------------------------|
| **Escopo** | ❌ Apenas PostgreSQL | ✅ Aplicação completa |
| **Código-fonte** | ❌ Não incluído | ✅ Frontend + Backend |
| **Arquivos de mídia** | ❌ Não incluído | ✅ Uploads, avatares, certs |
| **Configurações** | ❌ Não incluído | ✅ .env, ecosystem, nginx |
| **Redis** | ❌ Não incluído | ✅ Incluído |
| **Restore** | 🟡 Apenas banco | ✅ Restore completo automático |
| **Rotação** | ✅ Mantém 7 | ✅ Daily/Weekly/Monthly |
| **Metadata** | ❌ Não | ✅ Checksums, versões |
| **Recuperação** | 🟡 Parcial | ✅ 100% funcional |

---

## 🎓 Recursos Adicionais

### Arquivos do Sistema

**Scripts:**
- **Backup completo**: `/home/deploy/chat360/backup/backup-manager.sh`
- **Sincronização S3**: `/home/deploy/chat360/backup/sync-backups-s3.sh`
- **Configuração inicial**: `/home/deploy/chat360/backup/setup-backup.sh`

**Documentação:**
- **Quick Start**: `/home/deploy/chat360/backup/README.md`
- **Guia Completo**: `/home/deploy/chat360/backup/GUIA_BACKUP_COMPLETO.md` (este arquivo)

**Logs:**
- **Backup automático**: `/var/log/chat360-backup.log`
- **Sync S3**: `/var/log/chat360-s3-sync.log`
- **Aplicação**: `/home/deploy/chat360/backend/combined.log`

**Diretórios:**
- **Backups**: `/home/backups/chat360-snapshots/`
- **Scripts**: `/home/deploy/chat360/backup/`
- **Projeto**: `/home/deploy/chat360/`

---

## 📞 Suporte

Em caso de dúvidas ou problemas:

1. Verificar este guia
2. Executar `/home/deploy/chat360/backup/backup-manager.sh help`
3. Verificar logs de backup
4. Testar em ambiente de staging primeiro
5. Contatar equipe de infraestrutura

---

**Última atualização:** 26/10/2025  
**Versão do script:** 1.0  
**Autor:** Sistema Chat360

