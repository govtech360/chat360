import { toast } from "react-toastify";

/**
 * Configuração padrão para todos os toasts
 */
const defaultConfig = {
  autoClose: 3000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true,
  progress: undefined,
};

/**
 * Exibe uma mensagem de sucesso
 * @param {string} message - Mensagem a ser exibida
 * @param {object} options - Opções adicionais do toast
 */
export const toastSuccess = (message, options = {}) => {
  toast.success(message, {
    ...defaultConfig,
    ...options,
    toastId: options.toastId || `success-${Date.now()}`,
  });
};

/**
 * Exibe uma mensagem de erro
 * @param {string} message - Mensagem a ser exibida
 * @param {object} options - Opções adicionais do toast
 */
export const toastError = (message, options = {}) => {
  toast.error(message, {
    ...defaultConfig,
    autoClose: 4000, // Erros ficam um pouco mais tempo
    ...options,
    toastId: options.toastId || `error-${Date.now()}`,
  });
};

/**
 * Exibe uma mensagem de aviso
 * @param {string} message - Mensagem a ser exibida
 * @param {object} options - Opções adicionais do toast
 */
export const toastWarning = (message, options = {}) => {
  toast.warning(message, {
    ...defaultConfig,
    ...options,
    toastId: options.toastId || `warning-${Date.now()}`,
  });
};

/**
 * Exibe uma mensagem informativa
 * @param {string} message - Mensagem a ser exibida
 * @param {object} options - Opções adicionais do toast
 */
export const toastInfo = (message, options = {}) => {
  toast.info(message, {
    ...defaultConfig,
    ...options,
    toastId: options.toastId || `info-${Date.now()}`,
  });
};

/**
 * Exibe uma promessa com estados de loading, sucesso e erro
 * @param {Promise} promise - Promise a ser executada
 * @param {object} messages - Mensagens para cada estado { pending, success, error }
 * @param {object} options - Opções adicionais do toast
 */
export const toastPromise = (promise, messages = {}, options = {}) => {
  return toast.promise(
    promise,
    {
      pending: messages.pending || "Processando...",
      success: messages.success || "Operação realizada com sucesso!",
      error: messages.error || "Erro ao processar operação",
    },
    {
      ...defaultConfig,
      ...options,
    }
  );
};

/**
 * Fecha todos os toasts ativos
 */
export const dismissAllToasts = () => {
  toast.dismiss();
};

/**
 * Fecha um toast específico
 * @param {string} toastId - ID do toast a ser fechado
 */
export const dismissToast = (toastId) => {
  toast.dismiss(toastId);
};

/**
 * Verifica se um toast específico está ativo
 * @param {string} toastId - ID do toast a ser verificado
 * @returns {boolean}
 */
export const isToastActive = (toastId) => {
  return toast.isActive(toastId);
};

// Mensagens padrão para operações comuns
export const commonMessages = {
  // Mensagens de sucesso
  success: {
    created: "Registro criado com sucesso!",
    updated: "Registro atualizado com sucesso!",
    deleted: "Registro excluído com sucesso!",
    saved: "Salvo com sucesso!",
    sent: "Enviado com sucesso!",
    copied: "Copiado para a área de transferência!",
    imported: "Importação realizada com sucesso!",
    exported: "Exportação realizada com sucesso!",
    connected: "Conectado com sucesso!",
    disconnected: "Desconectado com sucesso!",
  },
  // Mensagens de erro
  error: {
    generic: "Ocorreu um erro. Tente novamente.",
    network: "Erro de conexão. Verifique sua internet.",
    notFound: "Registro não encontrado.",
    unauthorized: "Você não tem permissão para esta ação.",
    validation: "Verifique os campos e tente novamente.",
    timeout: "A operação demorou muito tempo.",
    serverError: "Erro no servidor. Tente novamente mais tarde.",
  },
  // Mensagens de aviso
  warning: {
    unsavedChanges: "Você tem alterações não salvas!",
    sessionExpiring: "Sua sessão está expirando.",
    limitReached: "Limite atingido.",
    deprecated: "Este recurso será removido em breve.",
  },
  // Mensagens informativas
  info: {
    loading: "Carregando...",
    processing: "Processando...",
    syncing: "Sincronizando...",
    noData: "Nenhum registro encontrado.",
  },
};

export default {
  success: toastSuccess,
  error: toastError,
  warning: toastWarning,
  info: toastInfo,
  promise: toastPromise,
  dismiss: dismissToast,
  dismissAll: dismissAllToasts,
  isActive: isToastActive,
  messages: commonMessages,
};

