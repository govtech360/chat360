import React, { useState, useEffect, useRef } from "react";

import * as Yup from "yup";
import { Formik, FieldArray, Form, Field } from "formik";
import { toast } from "react-toastify";

import { makeStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import CircularProgress from "@material-ui/core/CircularProgress";
import Box from "@material-ui/core/Box";
import MenuIcon from "@material-ui/icons/Menu";

import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack
} from "@mui/material";
import { AddCircle, Delete } from "@mui/icons-material";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap"
  },
  dialogPaper: {
    borderRadius: 12,
    boxShadow: theme.palette.mode === "dark"
      ? "0 8px 32px rgba(0, 0, 0, 0.6)"
      : "0 8px 32px rgba(0, 0, 0, 0.15)",
    "&::-webkit-scrollbar": {
      display: "none",
    },
    scrollbarWidth: "none",
    msOverflowStyle: "none",
  },
  dialogTitleStyled: {
    padding: theme.spacing(3, 4, 2),
    backgroundColor: theme.palette.background.default,
  },
  titleContent: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1.5),
    "& svg": {
      fontSize: "1.5rem",
      color: theme.palette.primary.main,
    },
  },
  dialogContentStyled: {
    padding: theme.spacing(3, 4),
    backgroundColor: theme.palette.background.paper,
  },
  dialogActionsStyled: {
    padding: theme.spacing(2, 3),
    backgroundColor: theme.palette.background.default,
    borderTop: `1px solid ${theme.palette.divider}`,
    gap: theme.spacing(1.5),
  },
  textField: {
    flex: 1,
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
      transition: "all 0.3s ease",
      "&:hover": {
        boxShadow: theme.palette.mode === "dark"
          ? "0 0 0 1px rgba(255, 255, 255, 0.1)"
          : "0 0 0 1px rgba(0, 0, 0, 0.1)",
      },
      "&.Mui-focused": {
        boxShadow: `0 0 0 2px ${theme.palette.primary.main}25`,
      },
    },
  },
  primaryButton: {
    borderRadius: 8,
    padding: theme.spacing(1, 3),
    textTransform: "none",
    fontWeight: 500,
  },
  secondaryButton: {
    borderRadius: 8,
    padding: theme.spacing(1, 3),
    textTransform: "none",
    fontWeight: 500,
  },
  addButton: {
    borderRadius: 8,
    padding: theme.spacing(0.75, 2),
    textTransform: "none",
    minWidth: "auto",
  },
  optionContainer: {
    marginTop: theme.spacing(2),
  },
  optionHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: theme.spacing(2),
  },
  optionItem: {
    marginBottom: theme.spacing(2),
  },
  optionLabel: {
    fontSize: "0.9rem",
    fontWeight: 500,
    marginBottom: theme.spacing(0.5),
    color: theme.palette.text.secondary,
  },
  optionInputRow: {
    display: "flex",
    gap: theme.spacing(1.5),
    alignItems: "center",
  },
  extraAttr: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },
  btnWrapper: {
    position: "relative"
  },
  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12
  }
}));

const selectFieldStyles = {
  ".MuiOutlinedInput-notchedOutline": {
    borderColor: "#909090"
  },
  "&:hover .MuiOutlinedInput-notchedOutline": {
    borderColor: "#000000",
    borderWidth: "thin"
  },
  "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
    borderColor: "#0000FF",
    borderWidth: "thin"
  }
};


const ContactSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Digite um nome!"),
  text: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Digite uma mensagem!")
});

const FlowBuilderMenuModal = ({ open, onSave, onUpdate, data, close }) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const [activeModal, setActiveModal] = useState(false);

  const [rule, setRule] = useState();

  const [textDig, setTextDig] = useState();

  const [arrayOption, setArrayOption] = useState([]);

  const [labels, setLabels] = useState({
    title: "Adicionar menu ao fluxo",
    btn: "Adicionar"
  });

  useEffect(() => {
    if (open === "edit") {
      setLabels({
        title: "Editar menu",
        btn: "Salvar"
      });
      setTextDig(data.data.message);
      setArrayOption(data.data.arrayOption);
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({
        title: "Adicionar menu ao fluxo",
        btn: "Adicionar"
      });
      setTextDig();
      setArrayOption([]);
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open]);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  const handleClose = () => {
    close(null);
    setActiveModal(false);
  };

  const handleSaveContact = async () => {
    if (open === "edit") {
      handleClose();
      onUpdate({
        ...data,
        data: { message: textDig, arrayOption: arrayOption }
      });
      return;
    } else if (open === "create") {
      handleClose();
      onSave({
        message: textDig,
        arrayOption: arrayOption
      });
    }
  };

  const removeOption = number => {
    setArrayOption(old => old.filter(item => item.number !== number));
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={activeModal}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        scroll="paper"
        PaperProps={{ className: classes.dialogPaper }}
      >
        <DialogTitle className={classes.dialogTitleStyled}>
          <Box className={classes.titleContent}>
            <MenuIcon />
            <Typography variant="h6">{labels.title}</Typography>
          </Box>
        </DialogTitle>
        <DialogContent dividers className={classes.dialogContentStyled}>
          <TextField
            label="Mensagem de explicação do menu"
            rows={4}
            name="text"
            multiline
            variant="outlined"
            value={textDig}
            onChange={e => setTextDig(e.target.value)}
            className={classes.textField}
            fullWidth
          />
          
          <Box className={classes.optionContainer}>
            <Box className={classes.optionHeader}>
              <Typography variant="subtitle1" style={{ fontWeight: 600 }}>
                Opções do Menu
              </Typography>
              <Button
                onClick={() =>
                  setArrayOption(old => [
                    ...old,
                    { number: old.length + 1, value: "" }
                  ])
                }
                color="primary"
                variant="contained"
                className={classes.addButton}
                startIcon={<AddCircle />}
              >
                Adicionar
              </Button>
            </Box>
            
            {arrayOption.map((item, index) => (
              <Box key={item.number} className={classes.optionItem}>
                <Typography className={classes.optionLabel}>
                  Opção {item.number}
                </Typography>
                <Box className={classes.optionInputRow}>
                  <TextField
                    placeholder="Digite o texto da opção"
                    variant="outlined"
                    defaultValue={item.value}
                    fullWidth
                    className={classes.textField}
                    onChange={event =>
                      setArrayOption(old => {
                        let newArr = old;
                        newArr[index].value = event.target.value;
                        return newArr;
                      })
                    }
                  />
                  {arrayOption.length === item.number && (
                    <IconButton 
                      onClick={() => removeOption(item.number)}
                      title="Remover opção"
                    >
                      <Delete />
                    </IconButton>
                  )}
                </Box>
              </Box>
            ))}
          </Box>
        </DialogContent>
        <DialogActions className={classes.dialogActionsStyled}>
          <Button 
            onClick={handleClose} 
            variant="outlined" 
            className={classes.secondaryButton}
          >
            {i18n.t("contactModal.buttons.cancel")}
          </Button>
          <Button
            type="submit"
            color="primary"
            variant="contained"
            className={classes.primaryButton}
            onClick={() => handleSaveContact()}
          >
            {labels.btn}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default FlowBuilderMenuModal;
