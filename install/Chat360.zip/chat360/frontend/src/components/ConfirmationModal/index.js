import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";

import { i18n } from "../../translate/i18n";

const useStyles = makeStyles((theme) => ({
	dialogPaper: {
		borderRadius: 12,
		minWidth: 400,
	},
	dialogTitleStyled: {
		backgroundColor: theme.palette.background.default,
		borderBottom: `1px solid ${theme.palette.divider}`,
		padding: theme.spacing(2, 3),
		fontWeight: 600,
		fontSize: "1.1rem",
	},
	dialogContentStyled: {
		backgroundColor: theme.palette.background.paper,
		padding: theme.spacing(3),
	},
	dialogActionsStyled: {
		backgroundColor: theme.palette.background.default,
		borderTop: `1px solid ${theme.palette.divider}`,
		padding: theme.spacing(2, 3),
		gap: theme.spacing(1),
	},
	primaryButton: {
		borderRadius: 8,
		padding: "8px 24px",
		textTransform: "none",
		fontWeight: 600,
	},
	secondaryButton: {
		borderRadius: 8,
		padding: "8px 24px",
		textTransform: "none",
		fontWeight: 600,
	},
}));

const ConfirmationModal = ({ title, children, open, onClose, onConfirm }) => {
	const classes = useStyles();

	return (
		<Dialog
			open={open}
			onClose={() => onClose(false)}
			aria-labelledby="confirm-dialog"
			PaperProps={{ className: classes.dialogPaper }}
		>
			<DialogTitle id="confirm-dialog" className={classes.dialogTitleStyled}>
				{title}
			</DialogTitle>
			<DialogContent className={classes.dialogContentStyled}>
				<Typography>{children}</Typography>
			</DialogContent>
			<DialogActions className={classes.dialogActionsStyled}>
				<Button
					variant="outlined"
					onClick={() => onClose(false)}
					className={classes.secondaryButton}
				>
					{i18n.t("confirmationModal.buttons.cancel")}
				</Button>
				<Button
					variant="contained"
					onClick={() => {
						onClose(false);
						onConfirm();
					}}
					color="primary"
					className={classes.primaryButton}
				>
					{i18n.t("confirmationModal.buttons.confirm")}
				</Button>
			</DialogActions>
		</Dialog>
	);
};

export default ConfirmationModal;
