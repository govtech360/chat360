import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import { Avatar, Typography } from '@material-ui/core';
import { format, parseISO } from 'date-fns';
import { blue } from '@material-ui/core/colors';
import { DoneAll, Done } from '@material-ui/icons';
import MarkdownWrapper from '../MarkdownWrapper';

const useStyles = makeStyles((theme) => ({
  messageBubble: {
    padding: theme.spacing(1),
    borderRadius: theme.shape.borderRadius,
    marginBottom: theme.spacing(1),
    maxWidth: '70%',
    position: 'relative',
    boxShadow: '0 1px 1px rgba(0, 0, 0, 0.1)',
  },
  messageLeft: {
    alignSelf: 'flex-start',
    backgroundColor: theme.palette.background.paper,
    color: theme.palette.text.primary,
    borderTopLeftRadius: 0,
  },
  messageRight: {
    alignSelf: 'flex-end',
    backgroundColor: theme.palette.sentMessage,
    color: theme.palette.text.primary,
    borderTopRightRadius: 0,
  },
  messageContent: {
    paddingBottom: theme.spacing(2.5),
  },
  timestamp: {
    fontSize: '0.7rem',
    color: theme.palette.text.secondary,
    position: 'absolute',
    bottom: theme.spacing(0.5),
    right: theme.spacing(1),
  },
  ackIcons: {
    fontSize: 16,
    verticalAlign: 'middle',
    marginLeft: 4,
  },
  ackDoneAllIcon: {
    color: blue[500],
  },
}));

const NewMessageBubble = ({ message, isGroup }) => {
  const classes = useStyles();

  const renderMessageAck = (msg) => {
    if (msg.ack === 1) {
      return <Done fontSize="small" className={classes.ackIcons} />;
    }
    if (msg.ack === 2) {
      return <DoneAll fontSize="small" className={classes.ackIcons} />;
    }
    if (msg.ack === 3) {
      return <DoneAll fontSize="small" className={clsx(classes.ackIcons, classes.ackDoneAllIcon)} />;
    }
    return null;
  };

  return (
    <div
      className={clsx(classes.messageBubble, {
        [classes.messageRight]: message.fromMe,
        [classes.messageLeft]: !message.fromMe,
      })}
    >
      {isGroup && !message.fromMe && (
        <Typography variant="caption" style={{ color: '#6bcbef' }}>
          {message.contact?.name}
        </Typography>
      )}
      <div className={classes.messageContent}>
        <MarkdownWrapper>{message.body}</MarkdownWrapper>
        <span className={classes.timestamp}>
          {format(parseISO(message.createdAt), 'HH:mm')}
          {message.fromMe && renderMessageAck(message)}
        </span>
      </div>
    </div>
  );
};

export default NewMessageBubble;
