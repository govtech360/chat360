import React, { useState, useEffect } from "react";
import {
  makeStyles,
  useTheme,
  Paper,
  Grid,
  FormControl,
  InputLabel,
  MenuItem,
  TextField,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableRow,
  IconButton,
  Select,
} from "@material-ui/core";
import { Formik, Form, Field } from "formik";
import ButtonWithSpinner from "../ButtonWithSpinner";
import ConfirmationModal from "../ConfirmationModal";

import { Edit as EditIcon } from "@material-ui/icons";

import { toast } from "react-toastify";
import useCompanies from "../../hooks/useCompanies";
import usePlans from "../../hooks/usePlans";
import ModalUsers from "../ModalUsers";
import api from "../../services/api";
import { head, isArray, has } from "lodash";
import { useDate } from "../../hooks/useDate";

import moment from "moment";
import { i18n } from "../../translate/i18n";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: "100%",
    padding: "2px",
    boxSizing: "border-box",
  },
  mainPaper: {
    width: "100%",
    maxWidth: "100%",
    flex: 1,
    boxSizing: "border-box",
  },
  fullWidth: {
    width: "100%",
    "& .MuiOutlinedInput-root": {
        borderRadius: "8px",
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.02)",
        transition: "all 0.3s ease",
        "&:hover": {
            backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.08)" : "rgba(0, 0, 0, 0.04)",
            "& fieldset": {
                borderColor: theme.palette.primary.light,
            },
        },
        "&.Mui-focused": {
            backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.03)",
            "& fieldset": {
                borderColor: theme.palette.primary.main,
                borderWidth: "2px",
            },
        },
    },
    "& .MuiInputLabel-outlined": {
        fontSize: "0.9rem",
        color: theme.palette.text.secondary,
        "&.Mui-focused": {
            color: theme.palette.primary.main,
        },
        [theme.breakpoints.down('sm')]: {
            fontSize: "0.85rem",
        },
    },
    "& .MuiOutlinedInput-input": {
        padding: "12px 14px",
        fontSize: "0.9rem",
        color: theme.palette.text.primary,
        [theme.breakpoints.down('sm')]: {
            padding: "10px 12px",
            fontSize: "0.85rem",
        },
    },
    "& .MuiOutlinedInput-notchedOutline": {
        borderColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.12)",
    },
    "& .MuiSelect-select": {
        color: theme.palette.text.primary,
    },
    "& .MuiButton-root": {
        [theme.breakpoints.down('sm')]: {
            fontSize: "0.8rem",
            padding: "6px 12px",
        },
    },
  },
  tableContainer: {
    width: "100%",
    maxWidth: "100%",
    borderRadius: 20,
    overflow: "hidden",
    boxSizing: "border-box",
    padding: theme.spacing(0, 2, 2, 2), // Espaçamento lateral e inferior
    [theme.breakpoints.down('sm')]: {
      borderRadius: 12,
      padding: theme.spacing(0, 1, 1, 1),
    },
  },
  tableScrollWrapper: {
    width: "100%",
    maxWidth: "100%",
    overflowX: "auto",
    overflowY: "visible",
    boxSizing: "border-box",
    borderRadius: 12,
    backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.02)" : "rgba(0, 0, 0, 0.02)",
    ...theme.scrollbarStyles,
    WebkitOverflowScrolling: "touch",
    "& .MuiTable-root": {
        minWidth: "900px",
        width: "100%",
        tableLayout: "auto",
        "& .MuiTableHead-root": {
            backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.03)",
        },
        "& .MuiTableCell-head": {
            fontWeight: 700,
            fontSize: "0.8rem",
            color: theme.palette.text.primary,
            borderBottom: `2px solid ${theme.palette.divider}`,
            padding: "10px 8px",
            whiteSpace: "nowrap",
        },
        "& .MuiTableRow-root": {
            transition: "all 0.2s ease",
            "&:nth-of-type(odd)": {
                backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.015)" : "rgba(0, 0, 0, 0.015)",
            },
            "&:hover": {
                backgroundColor: theme.palette.action.hover,
            },
        },
        "& .MuiTableCell-body": {
            fontSize: "0.75rem",
            color: theme.palette.text.secondary,
            borderBottom: `1px solid ${theme.palette.divider}`,
            padding: "8px 8px",
            whiteSpace: "nowrap",
        },
    },
    [theme.breakpoints.down('sm')]: {
        "& .MuiTable-root": {
            minWidth: "800px",
            "& .MuiTableCell-head": {
                fontSize: "0.7rem",
                padding: "8px 6px",
            },
            "& .MuiTableCell-body": {
                fontSize: "0.65rem",
                padding: "6px 6px",
            },
        },
    },
    [theme.breakpoints.up('md')]: {
        "& .MuiTable-root": {
            minWidth: "1100px",
            "& .MuiTableCell-head": {
                fontSize: "0.82rem",
                padding: "10px 8px",
            },
            "& .MuiTableCell-body": {
                fontSize: "0.77rem",
                padding: "8px 8px",
            },
        },
    },
    [theme.breakpoints.up('lg')]: {
        "& .MuiTable-root": {
            minWidth: "1300px",
            "& .MuiTableCell-head": {
                fontSize: "0.88rem",
                padding: "12px 10px",
            },
            "& .MuiTableCell-body": {
                fontSize: "0.82rem",
                padding: "10px 10px",
            },
        },
    },
    [theme.breakpoints.up('xl')]: {
        "& .MuiTable-root": {
            minWidth: "1500px",
            "& .MuiTableCell-head": {
                fontSize: "0.94rem",
                padding: "14px 12px",
            },
            "& .MuiTableCell-body": {
                fontSize: "0.88rem",
                padding: "12px 12px",
            },
        },
    },
  },
  textfield: {
    width: "100%",
  },
  textRight: {
    textAlign: "right",
  },
  iconButton: {
    padding: "8px",
    [theme.breakpoints.down('sm')]: {
      padding: "4px",
      "& .MuiSvgIcon-root": {
        fontSize: "1.2rem",
      },
    },
  },
  row: {
  },
  control: {
  },
  buttonContainer: {
    textAlign: "right",
  },
  submitButton: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    fontWeight: 600,
    padding: "8px 24px",
    fontSize: "0.9rem",
    borderRadius: "8px",
    textTransform: "none",
    minWidth: "100px",
    boxShadow: "none",
    transition: "all 0.2s ease",
    "&:hover": {
        backgroundColor: theme.palette.primary.dark,
        boxShadow: `0 2px 8px ${theme.palette.primary.main}4D`,
    },
  },
  deleteButton: {
    backgroundColor: theme.palette.error.main,
    color: theme.palette.error.contrastText,
    fontWeight: 600,
    padding: "8px 24px",
    fontSize: "0.9rem",
    borderRadius: "8px",
    textTransform: "none",
    minWidth: "100px",
    boxShadow: "none",
    transition: "all 0.2s ease",
    "&:hover": {
        backgroundColor: theme.palette.error.dark,
        boxShadow: `0 2px 8px ${theme.palette.error.main}4D`,
    },
  },
  cancelButton: {
    fontWeight: 600,
    padding: "8px 24px",
    fontSize: "0.9rem",
    borderRadius: "8px",
    textTransform: "none",
    minWidth: "100px",
    "&:hover": {
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.08)",
        borderColor: theme.palette.text.secondary,
    },
  },
}));

export function CompanyForm(props) {
  const { onSubmit, onDelete, onCancel, initialValue, loading } = props;
  const classes = useStyles();
  const [plans, setPlans] = useState([]);
  const [modalUser, setModalUser] = useState(false);
  const [firstUser, setFirstUser] = useState({});

  const [record, setRecord] = useState({
    name: "",
    email: "",
    phone: "",
    planId: "",
    status: true,
    // campaignsEnabled: false,
    dueDate: "",
    recurrence: "",
    password: "",
    ...initialValue,
  });

  const { list: listPlans } = usePlans();

  useEffect(() => {
    async function fetchData() {
      const list = await listPlans();
      setPlans(list);
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setRecord((prev) => {
      if (moment(initialValue).isValid()) {
        initialValue.dueDate = moment(initialValue.dueDate).format(
          "YYYY-MM-DD"
        );
      }
      return {
        ...prev,
        ...initialValue,
      };
    });
  }, [initialValue]);

  const handleSubmit = async (data) => {
    if (data.dueDate === "" || moment(data.dueDate).isValid() === false) {
      data.dueDate = null;
    }
    onSubmit(data);
    setRecord({ ...initialValue, dueDate: "" });
  };

  const handleOpenModalUsers = async () => {
    try {
      const { data } = await api.get("/users/list", {
        params: {
          companyId: initialValue.id,
        },
      });
      if (isArray(data) && data.length) {
        setFirstUser(head(data));
      }
      setModalUser(true);
    } catch (e) {
      toast.error(e);
    }
  };

  const handleCloseModalUsers = () => {
    setFirstUser({});
    setModalUser(false);
  };

  const incrementDueDate = () => {
    const data = { ...record };
    if (data.dueDate !== "" && data.dueDate !== null) {
      switch (data.recurrence) {
        case "MENSAL":
          data.dueDate = moment(data.dueDate)
            .add(1, "month")
            .format("YYYY-MM-DD");
          break;
        case "BIMESTRAL":
          data.dueDate = moment(data.dueDate)
            .add(2, "month")
            .format("YYYY-MM-DD");
          break;
        case "TRIMESTRAL":
          data.dueDate = moment(data.dueDate)
            .add(3, "month")
            .format("YYYY-MM-DD");
          break;
        case "SEMESTRAL":
          data.dueDate = moment(data.dueDate)
            .add(6, "month")
            .format("YYYY-MM-DD");
          break;
        case "ANUAL":
          data.dueDate = moment(data.dueDate)
            .add(12, "month")
            .format("YYYY-MM-DD");
          break;
        default:
          break;
      }
    }
    setRecord(data);
  };

  return (
    <>
      <ModalUsers
        userId={firstUser.id}
        companyId={initialValue.id}
        open={modalUser}
        onClose={handleCloseModalUsers}
      />
      <Formik
        enableReinitialize
        className={classes.fullWidth}
        initialValues={record}
        onSubmit={(values, { resetForm }) =>
          setTimeout(() => {
            handleSubmit(values);
            resetForm();
          }, 500)
        }
      >
        {(values, setValues) => (
          <Form className={classes.fullWidth}>
            <Grid spacing={1} justifyContent="center" container>
              <Grid xs={12} sm={6} md={3} item>
                <Field
                  as={TextField}
                  label={i18n.t("compaies.table.name")}
                  name="name"
                  variant="outlined"
                  className={classes.fullWidth}
                  margin="dense"
                />
              </Grid>
              <Grid xs={12} sm={6} md={2} item>
                <Field
                  as={TextField}
                  label={i18n.t("compaies.table.email")}
                  name="email"
                  variant="outlined"
                  className={classes.fullWidth}
                  margin="dense"
                  required
                />
              </Grid>
              <Grid xs={12} sm={6} md={2} item>
                <Field
                  as={TextField}
                  label={i18n.t("compaies.table.password")}
                  name="password"
                  variant="outlined"
                  className={classes.fullWidth}
                  margin="dense"
                />
              </Grid>
              <Grid xs={12} sm={6} md={2} item>
                <Field
                  as={TextField}
                  label={i18n.t("compaies.table.phone")}
                  name="phone"
                  variant="outlined"
                  className={classes.fullWidth}
                  margin="dense"
                />
              </Grid>
              <Grid xs={12} sm={6} md={2} item>
                <FormControl margin="dense" variant="outlined" fullWidth>
                  <InputLabel htmlFor="plan-selection">{i18n.t("compaies.table.plan")}</InputLabel>
                  <Field
                    as={Select}
                    id="plan-selection"
                    label={i18n.t("compaies.table.plan")}
                    labelId="plan-selection-label"
                    name="planId"
                    margin="dense"
                    required
                  >
                    {plans.map((plan, key) => (
                      <MenuItem key={key} value={plan.id}>
                        {plan.name}
                      </MenuItem>
                    ))}
                  </Field>
                </FormControl>
              </Grid>
              <Grid xs={12} sm={6} md={1} item>
                <FormControl margin="dense" variant="outlined" fullWidth>
                  <InputLabel htmlFor="status-selection">{i18n.t("compaies.table.active")}</InputLabel>
                  <Field
                    as={Select}
                    id="status-selection"
                    label={i18n.t("compaies.table.active")}
                    labelId="status-selection-label"
                    name="status"
                    margin="dense"
                  >
                    <MenuItem value={true}>{i18n.t("compaies.table.yes")}</MenuItem>
                    <MenuItem value={false}>{i18n.t("compaies.table.no")}</MenuItem>
                  </Field>
                </FormControl>
              </Grid>
              {/* <Grid xs={12} sm={6} md={3} item>
                <FormControl margin="dense" variant="outlined" fullWidth>
                  <InputLabel htmlFor="payment-method-selection">
                    Método de Pagamento
                  </InputLabel>
                  <Field
                    as={Select}
                    id="payment-method-selection"
                    label="Método de Pagamento"
                    labelId="payment-method-selection-label"
                    name="paymentMethod"
                    margin="dense"
                  >
                    <MenuItem value={"pix"}>PIX</MenuItem>
                  </Field>
                </FormControl>
              </Grid> */}
              <Grid xs={12} sm={6} md={2} item>
                <Field
                  as={TextField}
                  label={i18n.t("compaies.table.document")}
                  name="document"
                  variant="outlined"
                  className={classes.fullWidth}
                  margin="dense"
                />
              </Grid>
              {/* <Grid xs={12} sm={6} md={2} item>
                <FormControl margin="dense" variant="outlined" fullWidth>
                  <InputLabel htmlFor="status-selection">Campanhas</InputLabel>
                  <Field
                    as={Select}
                    id="campaigns-selection"
                    label="Campanhas"
                    labelId="campaigns-selection-label"
                    name="campaignsEnabled"
                    margin="dense"
                  >
                    <MenuItem value={true}>Habilitadas</MenuItem>
                    <MenuItem value={false}>Desabilitadas</MenuItem>
                  </Field>
                </FormControl>
              </Grid> */}
              <Grid xs={12} sm={6} md={2} item>
                <FormControl variant="outlined" fullWidth>
                  <Field
                    as={TextField}
                    label={i18n.t("compaies.table.dueDate")}
                    type="date"
                    name="dueDate"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    variant="outlined"
                    fullWidth
                    margin="dense"
                  />
                </FormControl>
              </Grid>
              <Grid xs={12} sm={6} md={2} item>
                <FormControl margin="dense" variant="outlined" fullWidth>
                  <InputLabel htmlFor="recorrencia-selection">
                  {i18n.t("compaies.table.recurrence")}
                  </InputLabel>
                  <Field
                    as={Select}
                    label="Recorrência"
                    labelId="recorrencia-selection-label"
                    id="recurrence"
                    name="recurrence"
                    margin="dense"
                  >
                    <MenuItem value="MENSAL">{i18n.t("compaies.table.monthly")}</MenuItem>
                    <MenuItem value="BIMESTRAL">{i18n.t("compaies.table.bimonthly")}</MenuItem>
                    <MenuItem value="TRIMESTRAL">{i18n.t("compaies.table.quarterly")}</MenuItem>
                    <MenuItem value="SEMESTRAL">{i18n.t("compaies.table.semester")}</MenuItem>
                    <MenuItem value="ANUAL">{i18n.t("compaies.table.yearly")}</MenuItem>
                  </Field>
                </FormControl>
              </Grid>
              <Grid xs={12} item>
                <Grid justifyContent="flex-end" spacing={2} alignItems="center" container style={{ marginTop: "8px" }}>
                  <Grid item>
                    <ButtonWithSpinner
                      className={classes.cancelButton}
                      loading={loading}
                      onClick={() => onCancel()}
                      variant="outlined"
                    >
                      {i18n.t("compaies.table.clear")}
                    </ButtonWithSpinner>
                  </Grid>
                  {record.id !== undefined ? (
                    <>
                      <Grid item>
                        <ButtonWithSpinner
                          className={classes.deleteButton}
                          loading={loading}
                          onClick={() => onDelete(record)}
                          variant="contained"
                        >
                          {i18n.t("compaies.table.delete")}
                        </ButtonWithSpinner>
                      </Grid>
                      <Grid item>
                        <ButtonWithSpinner
                          className={classes.submitButton}
                          loading={loading}
                          onClick={() => incrementDueDate()}
                          variant="contained"
                        >
                          {i18n.t("compaies.table.dueDate")}
                        </ButtonWithSpinner>
                      </Grid>
                    </>
                  ) : null}
                  <Grid item>
                    <ButtonWithSpinner
                      className={classes.submitButton}
                      loading={loading}
                      type="submit"
                      variant="contained"
                    >
                      {i18n.t("compaies.table.save")}
                    </ButtonWithSpinner>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    </>
  );
}

export function CompaniesManagerGrid(props) {
  const { records, onSelect } = props;
  const classes = useStyles();
  const theme = useTheme();
  const { dateToClient, datetimeToClient } = useDate();

  const renderStatus = (row) => {
    return row.status === false ? "Não" : "Sim";
  };

  const renderPlan = (row) => {
    return row.planId !== null ? row.plan.name : "-";
  };

  const renderPlanValue = (row) => {
    return row.planId !== null ? row.plan.amount ? row.plan.amount.toLocaleString('pt-br', { minimumFractionDigits: 2 }) : '00.00' : "-";
  };

  // const renderCampaignsStatus = (row) => {
  //   if (
  //     has(row, "settings") &&
  //     isArray(row.settings) &&
  //     row.settings.length > 0
  //   ) {
  //     const setting = row.settings.find((s) => s.key === "campaignsEnabled");
  //     if (setting) {
  //       return setting.value === "true" ? "Habilitadas" : "Desabilitadas";
  //     }
  //   }
  //   return "Desabilitadas";
  // };

  const rowStyle = (record) => {
    if (moment(record.dueDate).isValid()) {
      const now = moment();
      const dueDate = moment(record.dueDate);
      const diff = dueDate.diff(now, "days");
      const isDark = theme.palette.mode === "dark";
      
      // Vencimento próximo (1-5 dias) - Amarelo suave
      if (diff >= 1 && diff <= 5) {
        return { 
          backgroundColor: isDark ? "rgba(255, 193, 7, 0.15)" : "rgba(255, 193, 7, 0.15)",
          color: isDark ? "rgba(255, 255, 255, 0.95)" : "rgba(0, 0, 0, 0.87)"
        };
      }
      
      // Vencido - Vermelho suave
      if (diff <= 0) {
        return { 
          backgroundColor: isDark ? "rgba(244, 67, 54, 0.2)" : "rgba(244, 67, 54, 0.15)",
          color: isDark ? "rgba(255, 255, 255, 0.95)" : "rgba(0, 0, 0, 0.87)"
        };
      }
      // else {
      //   return { backgroundColor: "#affa8c" };
      // }
    }
    return {};
  };

  return (
    <div className={classes.tableContainer}>
      <div className={classes.tableScrollWrapper}>
        <Table
          className={classes.fullWidth}
          // size="small"
          padding="none"
          aria-label="a dense table"
        >
          <TableHead>
            <TableRow>
              <TableCell align="center" style={{ width: "1%" }}>#</TableCell>
              <TableCell align="center">ID</TableCell>
              <TableCell align="left">{i18n.t("compaies.table.name")}</TableCell>
              <TableCell align="left">{i18n.t("compaies.table.email")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.phone")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.plan")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.value")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.active")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.createdAt")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.dueDate")}</TableCell>
              <TableCell align="center">{i18n.t("compaies.table.lastLogin")}</TableCell>
              <TableCell align="center">Tamanho da pasta</TableCell>
              <TableCell align="center">Total de arquivos</TableCell>
              <TableCell align="center">Último update</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {records.map((row, key) => (
              <TableRow style={rowStyle(row)} key={key}>
                <TableCell align="center" style={{ width: "1%" }}>
                  <IconButton onClick={() => onSelect(row)} aria-label="edit">
                    <EditIcon />
                  </IconButton>
                </TableCell>
                <TableCell align="center">{row.id}</TableCell>
                <TableCell align="left">{row.name || "-"}</TableCell>
                <TableCell align="left" size="small">{row.email || "-"}</TableCell>
                <TableCell align="center">{row.phone || "-"}</TableCell>
                <TableCell align="center">{renderPlan(row)}</TableCell>
                <TableCell align="center">{i18n.t("compaies.table.money")} {renderPlanValue(row)}</TableCell>
                <TableCell align="center">{renderStatus(row)}</TableCell>
                <TableCell align="center">{dateToClient(row.createdAt)}</TableCell>
                <TableCell align="center">{dateToClient(row.dueDate)}<br /><span style={{ fontSize: "0.7em", opacity: 0.7 }}>{row.recurrence}</span></TableCell>
                <TableCell align="center">{datetimeToClient(row.lastLogin)}</TableCell>
                <TableCell align="center">{row.folderSize || "-"}</TableCell>
                <TableCell align="center">{row.numberFileFolder || "-"}</TableCell>
                <TableCell align="center">{dateToClient(row.updatedAtFolder)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

export default function CompaniesManager() {
  const classes = useStyles();
  const { list, save, update, remove } = useCompanies();

  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [records, setRecords] = useState([]);
  const [record, setRecord] = useState({
    name: "",
    email: "",
    phone: "",
    planId: "",
    status: true,
    // campaignsEnabled: false,
    dueDate: "",
    recurrence: "",
    password: "",
    document: "",
    paymentMethod: ""
  });

  useEffect(() => {
    loadPlans();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadPlans = async () => {
    setLoading(true);
    try {
      const companyList = await list();
      setRecords(companyList);
    } catch (e) {
      toast.error("Não foi possível carregar a lista de registros");
    }
    setLoading(false);
  };

  const handleSubmit = async (data) => {
    setLoading(true);
    try {
      if (data.id !== undefined) {
        await update(data);
      } else {
        await save(data);
      }
      await loadPlans();
      handleCancel();
      toast.success("Operação realizada com sucesso!");
    } catch (e) {
      toast.error(
        "Não foi possível realizar a operação. Verifique se já existe uma empresa com o mesmo nome ou se os campos foram preenchidos corretamente"
      );
    }
    setLoading(false);
  };

  const handleDelete = async () => {
    setLoading(true);
    try {
      await remove(record.id);
      await loadPlans();
      handleCancel();
      toast.success("Operação realizada com sucesso!");
    } catch (e) {
      toast.error("Não foi possível realizar a operação");
    }
    setLoading(false);
  };

  const handleOpenDeleteDialog = () => {
    setShowConfirmDialog(true);
  };

  const handleCancel = () => {
    setRecord((prev) => ({
      ...prev,
      name: "",
      email: "",
      phone: "",
      planId: "",
      status: true,
      // campaignsEnabled: false,
      dueDate: "",
      recurrence: "",
      password: "",
      document: "",
      paymentMethod: ""
    }));
  };

  const handleSelect = (data) => {
    // let campaignsEnabled = false;

    // const setting = data.settings.find(
    //   (s) => s.key.indexOf("campaignsEnabled") > -1
    // );
    // if (setting) {
    //   campaignsEnabled = setting.value === "true" || setting.value === "enabled";
    // }

    setRecord((prev) => ({
      ...prev,
      id: data.id,
      name: data.name || "",
      phone: data.phone || "",
      email: data.email || "",
      planId: data.planId || "",
      status: data.status === false ? false : true,
      // campaignsEnabled,
      dueDate: data.dueDate || "",
      recurrence: data.recurrence || "",
      password: "",
      document: data.document || "",
      paymentMethod: data.paymentMethod || "",
    }));
  };

  return (
    <Paper className={classes.mainPaper} elevation={0}>
      <Grid spacing={2} container>
        <Grid xs={12} item>
          <CompanyForm
            initialValue={record}
            onDelete={handleOpenDeleteDialog}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
            loading={loading}
          />
        </Grid>
        <Grid xs={12} item>
          <CompaniesManagerGrid records={records} onSelect={handleSelect} />
        </Grid>
      </Grid>
      <ConfirmationModal
        title="Exclusão de Registro"
        open={showConfirmDialog}
        onClose={() => setShowConfirmDialog(false)}
        onConfirm={() => handleDelete()}
      >
        Deseja realmente excluir esse registro?
      </ConfirmationModal>
    </Paper>
  );
}
