import React, { useState, useEffect, useContext } from "react";

import * as Yup from "yup";
import {
    Formik,
    Form,
    Field,
    FieldArray
} from "formik";
import { toast } from "react-toastify";

import {
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Grid,
    makeStyles,
    TextField,
    Box,
    Divider
} from "@material-ui/core";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import AttachFileIcon from "@material-ui/icons/AttachFile";
import DescriptionIcon from "@material-ui/icons/Description";
import AddIcon from "@material-ui/icons/Add";

import { green } from "@material-ui/core/colors";

import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";
import { AuthContext } from "../../context/Auth/AuthContext";

const useStyles = makeStyles(theme => ({
    root: {
        display: "flex",
        flexWrap: "wrap",
        gap: 4
    },
    dialogPaper: {
        borderRadius: 20,
        boxShadow: theme.palette.mode === "dark" 
          ? "0 8px 32px rgba(0, 0, 0, 0.6)" 
          : "0 8px 32px rgba(0, 0, 0, 0.15)",
    },
    dialogTitle: {
        backgroundColor: theme.palette.background.default,
        borderBottom: `2px solid ${theme.palette.divider}`,
        padding: theme.spacing(2.5, 3),
    },
    titleContent: {
        display: "flex",
        alignItems: "center",
        gap: theme.spacing(1.5),
        "& svg": {
            fontSize: "1.75rem",
            color: theme.palette.primary.main,
        },
    },
    dialogContent: {
        padding: theme.spacing(3),
        backgroundColor: theme.palette.background.paper,
    },
    dialogActions: {
        padding: theme.spacing(2, 3),
        backgroundColor: theme.palette.background.default,
        borderTop: `1px solid ${theme.palette.divider}`,
        gap: theme.spacing(1.5),
    },
    multFieldLine: {
        display: "flex",
        marginBottom: theme.spacing(2),
        "& > *:not(:last-child)": {
            marginRight: theme.spacing(1),
        },
    },
    textField: {
        marginRight: theme.spacing(1),
        flex: 1,
        "& .MuiOutlinedInput-root": {
            borderRadius: 12,
            transition: "all 0.3s ease",
            "&:hover": {
                boxShadow: theme.palette.mode === "dark" 
                  ? "0 0 0 1px rgba(255, 255, 255, 0.1)" 
                  : "0 0 0 1px rgba(0, 0, 0, 0.1)",
            },
            "&.Mui-focused": {
                boxShadow: `0 0 0 2px ${theme.palette.primary.main}25`,
            },
        },
    },
    extraAttr: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: theme.spacing(2),
    },
    fileOptionCard: {
        padding: theme.spacing(2),
        borderRadius: 12,
        backgroundColor: theme.palette.mode === "dark" 
          ? "rgba(255, 255, 255, 0.03)" 
          : "rgba(0, 0, 0, 0.02)",
        marginBottom: theme.spacing(2),
        border: `1px solid ${theme.palette.divider}`,
        transition: "all 0.2s ease",
        "&:hover": {
            backgroundColor: theme.palette.mode === "dark" 
              ? "rgba(255, 255, 255, 0.05)" 
              : "rgba(0, 0, 0, 0.04)",
        },
    },
    sectionTitle: {
        fontWeight: 600,
        color: theme.palette.text.primary,
        marginBottom: theme.spacing(2),
        marginTop: theme.spacing(3),
        display: "flex",
        alignItems: "center",
        gap: theme.spacing(1),
    },
    btnWrapper: {
        position: "relative",
        borderRadius: 8,
    },
    buttonProgress: {
        color: green[500],
        position: "absolute",
        top: "50%",
        left: "50%",
        marginTop: -12,
        marginLeft: -12,
    },
    primaryButton: {
        borderRadius: 8,
        padding: "8px 24px",
        textTransform: "none",
        fontWeight: 600,
        boxShadow: "none",
        "&:hover": {
            boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
        },
    },
    secondaryButton: {
        borderRadius: 8,
        padding: "8px 24px",
        textTransform: "none",
        fontWeight: 600,
    },
    addOptionButton: {
        borderRadius: 8,
        padding: "10px 20px",
        textTransform: "none",
        fontWeight: 600,
        marginTop: theme.spacing(1),
        borderStyle: "dashed",
        borderWidth: 2,
        "&:hover": {
            borderStyle: "dashed",
            borderWidth: 2,
        },
    },
    fileNameDisplay: {
        fontSize: "0.85rem",
        color: theme.palette.text.secondary,
        marginTop: theme.spacing(1),
        padding: theme.spacing(1),
        backgroundColor: theme.palette.mode === "dark" 
          ? "rgba(255, 255, 255, 0.05)" 
          : "rgba(0, 0, 0, 0.03)",
        borderRadius: 8,
        wordBreak: "break-all",
    },
    iconButton: {
        transition: "all 0.2s ease",
        "&:hover": {
            transform: "scale(1.1)",
        },
    },
}));

const FileListSchema = Yup.object().shape({
    name: Yup.string()
        .min(3, "nome muito curto")
        .required("Obrigatório"),
    message: Yup.string()
        .required("Obrigatório")
});

const FilesModal = ({ open, onClose, fileListId, reload }) => {
    const classes = useStyles();
    const { user } = useContext(AuthContext);

    const [files, setFiles] = useState([]);
    const [selectedFileNames, setSelectedFileNames] = useState([]);


    const initialState = {
        name: "",
        message: "",
        options: [{ name: "", path: "", mediaType: "" }],
    };

    const [fileList, setFileList] = useState(initialState);

    useEffect(() => {
        try {
            (async () => {
                if (!fileListId) return;

                const { data } = await api.get(`/files/${fileListId}`);
                setFileList(data);
            })()
        } catch (err) {
            toastError(err);
        }
    }, [fileListId, open]);

    const handleClose = () => {
        setFileList(initialState);
        setFiles([]);
        onClose();
    };

    const handleSaveFileList = async (values) => {

        const uploadFiles = async (options, filesOptions, id) => {
            const formData = new FormData();
            formData.append("fileId", id);
            formData.append("typeArch", "fileList")
            filesOptions.forEach((fileOption, index) => {
                if (fileOption.file) {
                    formData.append("files", fileOption.file);
                    formData.append("mediaType", fileOption.file.type)
                    formData.append("name", options[index].name);
                    formData.append("id", options[index].id);
                }
            });

            try {
                const { data } = await api.post(`/files/uploadList/${id}`, formData);
                setFiles([]);
                return data;
            } catch (err) {
                toastError(err);
            }
            return null;
        }

        const fileData = { ...values, userId: user.id };

        try {
            if (fileListId) {
                const { data } = await api.put(`/files/${fileListId}`, fileData)
                if (data.options.length > 0)
                    // console.log(values.options)
                    uploadFiles(data.options, values.options, fileListId)
            } else {
                const { data } = await api.post("/files", fileData);
                if (data.options.length > 0)
                    uploadFiles(data.options, values.options, data.id)
            }
            toast.success(i18n.t("fileModal.success"));
            if (typeof reload == 'function') {
                reload();
            }
        } catch (err) {
            toastError(err);
        }
        handleClose();
    };

    return (
        <div className={classes.root}>
            <Dialog
                open={open}
                onClose={handleClose}
                maxWidth="md"
                fullWidth
                scroll="paper"
                PaperProps={{
                    className: classes.dialogPaper
                }}
            >
                <DialogTitle id="form-dialog-title" className={classes.dialogTitle}>
                    <Box className={classes.titleContent}>
                        <DescriptionIcon />
                        <Typography variant="h6" style={{ fontWeight: 600 }}>
                            {(fileListId ? `${i18n.t("fileModal.title.edit")}` : `${i18n.t("fileModal.title.add")}`)}
                        </Typography>
                    </Box>
                </DialogTitle>
                <Formik
                    initialValues={fileList}
                    enableReinitialize={true}
                    validationSchema={FileListSchema}
                    onSubmit={(values, actions) => {
                        setTimeout(() => {
                            handleSaveFileList(values);
                            actions.setSubmitting(false);
                        }, 400);
                    }}
                >
                    {({ touched, errors, isSubmitting, values }) => (
                        <Form>
                            <DialogContent className={classes.dialogContent}>
                                <div className={classes.multFieldLine}>
                                    <Field
                                        as={TextField}
                                        label={i18n.t("fileModal.form.name")}
                                        name="name"
                                        error={touched.name && Boolean(errors.name)}
                                        helperText={touched.name && errors.name}
                                        variant="outlined"
                                        margin="dense"
                                        fullWidth
                                        className={classes.textField}
                                    />
                                </div>
                                <div className={classes.multFieldLine}>
                                    <Field
                                        as={TextField}
                                        label={i18n.t("fileModal.form.message")}
                                        type="message"
                                        multiline
                                        minRows={5}
                                        fullWidth
                                        name="message"
                                        error={
                                            touched.message && Boolean(errors.message)
                                        }
                                        helperText={
                                            touched.message && errors.message
                                        }
                                        variant="outlined"
                                        margin="dense"
                                        className={classes.textField}
                                    />
                                </div>
                                <Divider style={{ margin: "24px 0 16px 0" }} />
                                <Typography
                                    className={classes.sectionTitle}
                                    variant="subtitle1"
                                >
                                    <AttachFileIcon fontSize="small" />
                                    {i18n.t("fileModal.form.fileOptions")}
                                </Typography>

                                <FieldArray name="options">
                                    {({ push, remove }) => (
                                        <>
                                            {values.options &&
                                                values.options.length > 0 &&
                                                values.options.map((info, index) => (
                                                    <Box
                                                        className={classes.fileOptionCard}
                                                        key={`${index}-info`}
                                                    >
                                                        <Grid container spacing={2}>
                                                            <Grid xs={12} md={10} item>
                                                                <Field
                                                                    as={TextField}
                                                                    label={i18n.t("fileModal.form.extraName")}
                                                                    name={`options[${index}].name`}
                                                                    variant="outlined"
                                                                    margin="dense"
                                                                    multiline
                                                                    fullWidth
                                                                    minRows={2}
                                                                    className={classes.textField}
                                                                />
                                                            </Grid>
                                                            <Grid xs={12} md={2} item style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                                                                <input
                                                                    type="file"
                                                                    onChange={(e) => {
                                                                        const selectedFile = e.target.files[0];
                                                                        const updatedOptions = [...values.options];
                                                                        updatedOptions[index].file = selectedFile;
                                                                        setFiles('options', updatedOptions);

                                                                        // Atualize a lista selectedFileNames para o campo específico
                                                                        const updatedFileNames = [...selectedFileNames];
                                                                        updatedFileNames[index] = selectedFile ? selectedFile.name : '';
                                                                        setSelectedFileNames(updatedFileNames);
                                                                    }}
                                                                    style={{ display: 'none' }}
                                                                    name={`options[${index}].file`}
                                                                    id={`file-upload-${index}`}
                                                                />
                                                                <label htmlFor={`file-upload-${index}`}>
                                                                    <IconButton 
                                                                        component="span"
                                                                        className={classes.iconButton}
                                                                        color="primary"
                                                                    >
                                                                        <AttachFileIcon />
                                                                    </IconButton>
                                                                </label>
                                                                <IconButton
                                                                    size="small"
                                                                    onClick={() => remove(index)}
                                                                    className={classes.iconButton}
                                                                    color="secondary"
                                                                >
                                                                    <DeleteOutlineIcon />
                                                                </IconButton>
                                                            </Grid>
                                                            {(info.path || selectedFileNames[index]) && (
                                                                <Grid xs={12} md={12} item>
                                                                    <Box className={classes.fileNameDisplay}>
                                                                        📎 {info.path ? info.path : selectedFileNames[index]}
                                                                    </Box>
                                                                </Grid>
                                                            )}
                                                        </Grid>
                                                    </Box>
                                                ))}
                                            <Box style={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
                                                <Button
                                                    className={classes.addOptionButton}
                                                    variant="outlined"
                                                    color="primary"
                                                    fullWidth
                                                    startIcon={<AddIcon />}
                                                    onClick={() => {
                                                        push({ name: "", path: "" });
                                                        setSelectedFileNames([...selectedFileNames, ""]);
                                                    }}
                                                >
                                                    {i18n.t("fileModal.buttons.fileOptions")}
                                                </Button>
                                            </Box>
                                        </>
                                    )}
                                </FieldArray>
                            </DialogContent>
                            <DialogActions className={classes.dialogActions}>
                                <Button
                                    onClick={handleClose}
                                    disabled={isSubmitting}
                                    variant="outlined"
                                    className={classes.secondaryButton}
                                >
                                    {i18n.t("fileModal.buttons.cancel")}
                                </Button>
                                <Button
                                    type="submit"
                                    color="primary"
                                    disabled={isSubmitting}
                                    variant="contained"
                                    className={`${classes.primaryButton} ${classes.btnWrapper}`}
                                >
                                    {fileListId
                                        ? `${i18n.t("fileModal.buttons.okEdit")}`
                                        : `${i18n.t("fileModal.buttons.okAdd")}`}
                                    {isSubmitting && (
                                        <CircularProgress
                                            size={24}
                                            className={classes.buttonProgress}
                                        />
                                    )}
                                </Button>
                            </DialogActions>
                        </Form>
                    )}
                </Formik>
            </Dialog>
        </div>
    );
};

export default FilesModal;
