import React from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import { AppBar, Toolbar, IconButton, Typography, Avatar } from '@material-ui/core';
import { ArrowBack, MoreVert, Search, Videocam, Call } from '@material-ui/icons';
import { i18n } from '../../translate/i18n';

const useStyles = makeStyles((theme) => ({
  appBar: {
    backgroundColor: theme.palette.primary.main,
    boxShadow: 'none',
  },
  toolbar: {
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1),
  },
  title: {
    flexGrow: 1,
    marginLeft: theme.spacing(1),
  },
  contactInfo: {
    display: 'flex',
    alignItems: 'center',
    flexGrow: 1,
  },
}));

const MobileHeader = ({ contact }) => {
  const classes = useStyles();
  const history = useHistory();
  const { ticketId } = useParams();

  const handleBack = () => {
    history.push('/tickets');
  };

  return (
    <AppBar position="static" className={classes.appBar}>
      <Toolbar className={classes.toolbar}>
        {ticketId ? (
          <>
            <IconButton color="inherit" onClick={handleBack}>
              <ArrowBack />
            </IconButton>
            <div className={classes.contactInfo}>
              <Avatar src={contact?.urlPicture} />
              <Typography variant="h6" className={classes.title}>
                {contact?.name}
              </Typography>
            </div>
            <IconButton color="inherit">
              <Videocam />
            </IconButton>
            <IconButton color="inherit">
              <Call />
            </IconButton>
            <IconButton color="inherit">
              <MoreVert />
            </IconButton>
          </>
        ) : (
          <>
            <Typography variant="h6" className={classes.title}>
              {i18n.t("mainDrawer.appBar.message")}
            </Typography>
            <IconButton color="inherit">
              <Search />
            </IconButton>
            <IconButton color="inherit">
              <MoreVert />
            </IconButton>
          </>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default MobileHeader;
