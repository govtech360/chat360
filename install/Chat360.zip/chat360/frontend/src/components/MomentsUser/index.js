import React, { Fragment, useContext, useEffect, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import api from "../../services/api";
import { i18n } from "../../translate/i18n";
import toastError from "../../errors/toastError";

import { AuthContext } from "../../context/Auth/AuthContext";
import { ReportProblem, VisibilityOutlined } from "@mui/icons-material";
import { toast } from "react-toastify";
import {
  Avatar,
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Paper,
  Typography,
  Card,
  makeStyles,
  Container,
  Badge,
  Grid,
  Tooltip,
  CardContent,
  useTheme,
  Box,
  IconButton
} from "@material-ui/core";
import { format, isSameDay, parseISO } from "date-fns";
import { getBackendUrl } from "../../config";

const backendUrl = getBackendUrl();

const useStyles = makeStyles((theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
    overflowY: "auto",
    ...theme.scrollbarStyles,
    maxHeight: 'calc(100vh - 200px)',
  },
  card: {
    height: "420px",
    display: 'flex',
    flexDirection: 'column',
    margin: theme.spacing(1),
    borderRadius: 16,
    flex: 1,
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 16px rgba(0, 0, 0, 0.4)"
      : "0 4px 16px rgba(0, 0, 0, 0.08)",
    transition: "all 0.3s ease",
    "&:hover": {
      boxShadow: theme.palette.mode === "dark"
        ? "0 8px 24px rgba(0, 0, 0, 0.6)"
        : "0 8px 24px rgba(0, 0, 0, 0.12)",
      transform: "translateY(-4px)",
    },
  },
  cardHeader: {
    backgroundColor: theme.palette.mode === "dark" 
      ? theme.palette.background.paper
      : theme.palette.background.default,
    borderBottom: `1px solid ${theme.palette.divider}`,
    padding: theme.spacing(2),
    "& .MuiCardHeader-title": {
      fontWeight: 600,
      fontSize: "1rem",
    },
    "& .MuiCardHeader-subheader": {
      fontSize: "0.85rem",
      marginTop: theme.spacing(0.5),
    },
  },
  cardContent: {
    maxHeight: "100%",
    overflowY: "auto",
    ...theme.scrollbarStyles,
    padding: 0,
    flex: 1,
    "&:last-child": {
      paddingBottom: 0,
    },
  },
  listItem: {
    padding: theme.spacing(1.5, 2),
    transition: "all 0.2s ease",
    borderBottom: `1px solid ${theme.palette.divider}`,
    "&:hover": {
      backgroundColor: theme.palette.mode === "dark"
        ? "rgba(255, 255, 255, 0.05)"
        : "rgba(0, 0, 0, 0.02)",
    },
    "&:last-child": {
      borderBottom: "none",
    },
  },
  pending: {
    color: theme.palette.warning.main,
    fontSize: '20px',
    verticalAlign: 'middle',
  },
  connectionTag: {
    background: theme.palette.success.main,
    color: "#FFF",
    marginTop: theme.spacing(0.5),
    padding: theme.spacing(0.5, 1),
    fontWeight: 600,
    borderRadius: 6,
    fontSize: "0.65rem",
    display: "inline-block",
  },
  lastMessageTime: {
    justifySelf: "flex-end",
    textAlign: "right",
    position: "relative",
    marginRight: "1px",
    color: theme.palette.text.secondary,
    fontSize: "0.75rem",
  },
  lastMessageTimeUnread: {
    justifySelf: "flex-end",
    textAlign: "right",
    position: "relative",
    color: theme.palette.success.main,
    fontWeight: 700,
    marginRight: "1px",
    fontSize: "0.75rem",
  },
  avatar: {
    width: 48,
    height: 48,
    border: `2px solid ${theme.palette.divider}`,
  },
  iconButton: {
    padding: theme.spacing(0.5),
    transition: "all 0.2s ease",
    "&:hover": {
      backgroundColor: theme.palette.primary.main,
      color: "#fff",
    },
  },
}));

const DashboardManage = () => {
  const classes = useStyles();
  const history = useHistory();
  const theme = useTheme();
  const { user, socket } = useContext(AuthContext);

  const [tickets, setTickets] = useState([]);
  const [update, setUpdate] = useState(false);
  const companyId = user.companyId;

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get("/usersMoments");
        setTickets(data);
        setUpdate(!update);
      } catch (err) {
        if (err.response?.status !== 500) {
          toastError(err);
        } else {
          toast.error(`${i18n.t("frontEndErrors.getUsers")}`);
        }
      }
    })();
  }, []);

  useEffect(() => {
    const onAppMessage = (data) => {
      if (data.action === "create" || data.action === "update" || data.action === "delete") {
        (async () => {
          try {
            const { data } = await api.get("/usersMoments");
            setTickets(data);
            setUpdate(!update);
          } catch (err) {
            if (err.response?.status !== 500) {
              toastError(err);
            } else {
              toast.error(`${i18n.t("frontEndErrors.getUsers")}`);
            }
          }
        })();
      }
    }

    socket.on(`company-${companyId}-ticket`, onAppMessage)
    socket.on(`company-${companyId}-appMessage`, onAppMessage);

    return () => {
      socket.off(`company-${companyId}-ticket`, onAppMessage)
      socket.off(`company-${companyId}-appMessage`, onAppMessage);
    };
  }, [socket, companyId, update]);

  const Moments = useMemo(() => {
    if (tickets && tickets.length > 0) {
      const ticketsByUser = tickets.reduce((userTickets, ticket) => {
        const user = ticket.user;

        if (user) {
          const userIndex = userTickets.findIndex((group) => group.user.id === user.id);
          if (userIndex === -1) {
            userTickets.push({
              user,
              userTickets: [ticket],
            });
          } else {
            userTickets[userIndex].userTickets.push(ticket);
          }
        }
        return userTickets;
      }, []);

      return ticketsByUser.map((group, index) => (
        <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
          <Card className={classes.card} elevation={0}>
            <CardHeader
              className={classes.cardHeader}
              avatar={
                <Avatar 
                  alt={`${group.user.profileImage}`} 
                  src={group.user.profileImage ? `${backendUrl}/public/company${companyId}/user/${group.user.profileImage}` : null}
                  className={classes.avatar}
                />
              }
              title={`${group?.user?.name || "Pendentes"}`}
              subheader={`Atendimentos: ${group.userTickets?.length}`}
            />
            <CardContent className={classes.cardContent}>
              <List style={{ paddingTop: 0 }}>
                {group.userTickets.map((ticket) => (
                  <Fragment key={ticket.id}>
                    <ListItem dense button className={classes.listItem}>
                      <ListItemAvatar>
                        <Avatar 
                          alt={`${ticket.contact.urlPicture}`} 
                          src={`${ticket.contact.urlPicture}`}
                          className={classes.avatar}
                        />
                      </ListItemAvatar>
                      <ListItemText
                        disableTypography
                        primary={
                          <Typography variant="body1" noWrap color="textPrimary" style={{ fontWeight: 600 }}>
                            {ticket?.contact?.name}
                          </Typography>
                        }
                        secondary={
                          <Fragment>
                            <Typography noWrap variant="body2" color="textSecondary" style={{ marginTop: 4 }}>
                              {ticket.lastMessage || "..."}
                            </Typography>
                            <Badge className={classes.connectionTag}>
                              {ticket.queue?.name.toUpperCase() || "SEM FILA"}
                            </Badge>
                          </Fragment>
                        }
                      />
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 0.5 }}>
                        <Typography
                          className={Number(ticket.unreadMessages) > 0 ? classes.lastMessageTimeUnread : classes.lastMessageTime}
                          component="span"
                          variant="body2"
                        >
                          {isSameDay(parseISO(ticket.updatedAt), new Date()) ? (
                            <>{format(parseISO(ticket.updatedAt), "HH:mm")}</>
                          ) : (
                            <>{format(parseISO(ticket.updatedAt), "dd/MM/yyyy")}</>
                          )}
                        </Typography>
                        {(user.profile === "admin" || ticket.userId === user.id) && (
                          <Tooltip title="Acessar Ticket" arrow>
                            <IconButton 
                              size="small" 
                              onClick={() => history.push(`/tickets/${ticket.uuid}`)}
                              className={classes.iconButton}
                            >
                              <VisibilityOutlined fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Box>
                    </ListItem>
                  </Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      ));
    } else {
      return null;
    }
  }, [tickets, update, classes, companyId, history, user]);

  const MomentsPending = useMemo(() => {
    if (tickets && tickets.length > 0) {
      const pendingTickets = tickets.filter((ticket) => !ticket.user);

      return (
        <Grid item xs={12} sm={6} md={4} lg={3}>
          <Card className={classes.card} elevation={0}>
            <CardHeader
              className={classes.cardHeader}
              avatar={<Avatar className={classes.avatar} />}
              title={
                <Box display="flex" alignItems="center">
                  {"Pendentes"}
                  <ReportProblem className={classes.pending} style={{ marginLeft: theme.spacing(1) }} />
                </Box>
              }
              subheader={`Atendimentos: ${pendingTickets?.length}`}
            />
            <CardContent className={classes.cardContent}>
              <List style={{ paddingTop: 0 }}>
                {pendingTickets.map((ticket) => (
                  <Fragment key={ticket.id}>
                    <ListItem dense button className={classes.listItem}>
                      <ListItemAvatar>
                        <Avatar 
                          alt={`${ticket.contact.urlPicture}`} 
                          src={`${ticket.contact.urlPicture}`}
                          className={classes.avatar}
                        />
                      </ListItemAvatar>
                      <ListItemText
                        disableTypography
                        primary={
                          <Typography variant="body1" noWrap color="textPrimary" style={{ fontWeight: 600 }}>
                            {ticket?.contact?.name}
                          </Typography>
                        }
                        secondary={
                          <Fragment>
                            <Typography noWrap variant="body2" color="textSecondary" style={{ marginTop: 4 }}>
                              {ticket.lastMessage || "..."}
                            </Typography>
                            <Badge className={classes.connectionTag}>
                              {ticket.queue?.name.toUpperCase() || "SEM FILA"}
                            </Badge>
                          </Fragment>
                        }
                      />
                      <Typography
                        className={Number(ticket.unreadMessages) > 0 ? classes.lastMessageTimeUnread : classes.lastMessageTime}
                        component="span"
                        variant="body2"
                      >
                        {isSameDay(parseISO(ticket.updatedAt), new Date()) ? (
                          <>{format(parseISO(ticket.updatedAt), "HH:mm")}</>
                        ) : (
                          <>{format(parseISO(ticket.updatedAt), "dd/MM/yyyy")}</>
                        )}
                      </Typography>
                    </ListItem>
                  </Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      );
    } else {
      return null;
    }
  }, [tickets, update, classes, theme]);

  return (
    <Fragment>
      <Grid container spacing={2}>
        {Moments}
        {MomentsPending}
      </Grid>
    </Fragment>
  );
};

export default DashboardManage;
