import React, { useState, useEffect, useRef, useContext } from "react";

import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import { toast } from "react-toastify";
import { head } from "lodash";

import { makeStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import CircularProgress from "@material-ui/core/CircularProgress";
import AttachFileIcon from "@material-ui/icons/AttachFile";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import SendIcon from "@material-ui/icons/Send";

import { i18n } from "../../translate/i18n";
import moment from "moment";

import api from "../../services/api";
import toastError from "../../errors/toastError";
import {
  Box,
  FormControl,
  Grid,
  InputLabel,
  ListItemText,
  MenuItem,
  Select,
  Typography
} from "@material-ui/core";
import { AuthContext } from "../../context/Auth/AuthContext";
import ConfirmationModal from "../ConfirmationModal";
import { Autocomplete, Checkbox, Chip, Stack } from "@mui/material";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap"
  },
  dialogPaper: {
    borderRadius: 12,
    boxShadow: theme.palette.mode === "dark"
      ? "0 8px 32px rgba(0, 0, 0, 0.6)"
      : "0 8px 32px rgba(0, 0, 0, 0.15)",
    overflowX: "hidden",
  },
  dialogTitleStyled: {
    padding: theme.spacing(3, 4, 2),
    backgroundColor: theme.palette.background.default,
  },
  dialogContentStyled: {
    padding: theme.spacing(3, 4),
    backgroundColor: theme.palette.background.paper,
  },
  dialogActionsStyled: {
    padding: theme.spacing(2, 3),
    backgroundColor: theme.palette.background.default,
    borderTop: `1px solid ${theme.palette.divider}`,
  },
  textField: {
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
    },
  },
  selectField: {
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
    },
  },
  autocompleteField: {
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
    },
  },
  primaryButton: {
    borderRadius: 8,
    padding: "8px 24px",
    textTransform: "none",
    fontWeight: 600,
  },
  secondaryButton: {
    borderRadius: 8,
    padding: "8px 24px",
    textTransform: "none",
    fontWeight: 600,
  },
  titleIcon: {
    color: theme.palette.primary.main,
  },
  extraAttr: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },
  btnWrapper: {
    position: "relative"
  },
  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12
  },
  online: {
    color: "#4caf50",
  },
  offline: {
    color: "#f44336",
  }
}));

const CampaignModalPhrase = ({ open, onClose, FlowCampaignId, onSave, defaultWhatsappId }) => {
  const classes = useStyles();
  const isMounted = useRef(true);
  const { user } = useContext(AuthContext);
  const { companyId } = user;

  const [campaignEditable, setCampaignEditable] = useState(true);
  const attachmentFile = useRef(null);

  const [dataItem, setDataItem] = useState({
    name: "",
    phrase: ""
  });

  const [dataItemError, setDataItemError] = useState({
    name: false,
    flowId: false,
    phrase: false
  });

  const [flowSelected, setFlowSelected] = useState();
  const [flowsData, setFlowsData] = useState([]);
  const [flowsDataComplete, setFlowsDataComplete] = useState([]);

  const [selectedWhatsapp, setSelectedWhatsapp] = useState("");

  // ✅ Aplica valor inicial da conexão
  useEffect(() => {
  if (!FlowCampaignId) {
    const stored = localStorage.getItem("selectedWhatsappId");
    if (stored) {
      console.log("Forçando selectedWhatsapp via localStorage:", stored);
      setSelectedWhatsapp(parseInt(stored));
    }
  }
}, [FlowCampaignId]);


  const [whatsAppNames, setWhatsAppNames] = useState([]);
  const [whatsApps, setWhatsApps] = useState([]);
  const [whatsAppSelected, setWhatsAppSelected] = useState({});

  const [active, setActive] = useState(true);
  const [loading, setLoading] = useState(true);

  const getFlows = async () => {
    const flows = await api.get("/flowbuilder");
    setFlowsDataComplete(flows.data.flows);
    setFlowsData(flows.data.flows.map(flow => flow.name));
    return flows.data.flows;
  };

  const detailsPhrase = async flows => {
    setLoading(true);
    await api.get(`/flowcampaign/${FlowCampaignId}`).then(res => {
      console.log("dete", res.data);
      setDataItem({
        name: res.data.details.name,
        phrase: res.data.details.phrase
      });
      setActive(res.data.details.status)
      const nameFlow = flows.filter(
        itemFlows => itemFlows.id === res.data.details.flowId
      );
      if (nameFlow.length > 0) {
        setFlowSelected(nameFlow[0].name);
        if (res.data.details.whatsappId) {
        console.log("Aplicando whatsappId do banco:", res.data.details.whatsappId);
        setSelectedWhatsapp(res.data.details.whatsappId);
     }

      }
      setLoading(false);
    });
  };

  const handleClose = () => {
    onClose();
  };

  const openModal = async () => {
    const flows = await getFlows();
    if (FlowCampaignId) {
      await detailsPhrase(flows);
    } else {
      clearData();
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true)
    const delayDebounceFn = setTimeout(() => {
      const fetchContacts = async () => {
        api
          .get(`/whatsapp`, { params: { companyId, session: 0 } })
          .then(({ data }) => {
            setWhatsApps(data)
          })
      }
      fetchContacts();
      setLoading(false)
    }, 500)
    return () => clearTimeout(delayDebounceFn)
  }, [])


  useEffect(() => {
    setLoading(true)
    if (open === true) {
      openModal();
    }
  }, [open]);

  const clearErrors = () => {
    setDataItemError({
      name: false,
      flowId: false,
      whatsappId: false,
      phrase: false
    });
  };

  const clearData = () => {
    setFlowSelected();
    setDataItem({
      name: "",
      phrase: ""
    });
  };

  const applicationSaveAndEdit = () => {
    let error = 0;
    if (dataItem.name === "" || dataItem.name.length === 0) {
      setDataItemError(old => ({ ...old, name: true }));
      error++;
    }
    if (!flowSelected) {
      setDataItemError(old => ({ ...old, flowId: true }));
      error++;
    }
    if (dataItem.phrase === "" || dataItem.phrase.length === 0) {
      setDataItemError(old => ({ ...old, phrase: true }));
      error++;
    }
    if(!selectedWhatsapp){
      setDataItemError(old => ({ ...old, whatsappId: true }))
    }

    if (error !== 0) {
      return;
    }

    const idFlow = flowsDataComplete.filter(
      item => item.name === flowSelected
    )[0].id;

    const whatsappId = selectedWhatsapp !== "" ? selectedWhatsapp : null

    if (FlowCampaignId) {
      api.put("/flowcampaign", {
        id: FlowCampaignId,
        name: dataItem.name,
        flowId: idFlow,
        whatsappId: whatsappId,
        phrase: dataItem.phrase,
        status: active
      })
      onClose();
      onSave('ok');
      toast.success("Frase alterada com sucesso!");
      clearData();
    } else {
      api.post("/flowcampaign", {
        name: dataItem.name,
        flowId: idFlow,
        whatsappId: whatsappId,
        phrase: dataItem.phrase
      });
      onClose();
      onSave('ok');
      toast.success("Frase criada com sucesso!");
      clearData();
    }
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        PaperProps={{ className: classes.dialogPaper }}
      >
        <DialogTitle id="form-dialog-title" className={classes.dialogTitleStyled}>
          <Box display="flex" alignItems="center">
            <SendIcon className={classes.titleIcon} style={{ marginRight: 8 }} />
            {campaignEditable ? (
              <>
                {FlowCampaignId
                  ? `Editar campanha com fluxo por frase`
                  : `Nova campanha com fluxo por frase`}
              </>
            ) : (
              <>{`${i18n.t("campaigns.dialog.readonly")}`}</>
            )}
          </Box>
        </DialogTitle>
        <div style={{ display: "none" }}>
          <input type="file" ref={attachmentFile} />
        </div>
        {!loading && (
          <>
            <DialogContent className={classes.dialogContentStyled}>
              <TextField
                label="Nome do disparo por frase"
                name="text"
                variant="outlined"
                margin="dense"
                error={dataItemError.name}
                defaultValue={dataItem.name}
                onChange={e => {
                  setDataItem(old => {
                    let newValue = old;
                    newValue.name = e.target.value;
                    return newValue;
                  });
                }}
                className={classes.textField}
                fullWidth
                required
              />
              <Box mt={2}>
                <Autocomplete
                  disablePortal
                  id="combo-box-demo"
                  value={flowSelected}
                  error={dataItemError.flowId}
                  defaultValue={flowSelected}
                  options={flowsData}
                  onChange={(event, newValue) => {
                    setFlowSelected(newValue);
                  }}
                  fullWidth
                  className={classes.autocompleteField}
                  renderInput={params => (
                    <TextField
                      {...params}
                      label="Escolha um fluxo"
                      error={dataItemError.flowId}
                      variant="outlined"
                      margin="dense"
                      placeholder="Escolha um fluxo"
                      className={classes.textField}
                      required
                    />
                  )}
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => (
                      <Chip
                        variant="outlined"
                        label={option}
                        {...getTagProps({ index })}
                        style={{ borderRadius: 8 }}
                      />
                    ))
                  }
                />
              </Box>
              <Box mt={2}>
                <FormControl fullWidth className={classes.selectField} margin="dense" variant="outlined">
                  <InputLabel>Selecione uma Conexão *</InputLabel>
                  <Select
                    required
                    value={selectedWhatsapp}
                    onChange={(e) => {
                      setSelectedWhatsapp(e.target.value)
                    }}
                    label="Selecione uma Conexão *"
                    MenuProps={{
                      anchorOrigin: {
                        vertical: "bottom",
                        horizontal: "left"
                      },
                      transformOrigin: {
                        vertical: "top",
                        horizontal: "left"
                      },
                      getContentAnchorEl: null,
                    }}
                  >

                  {whatsApps?.length > 0 &&
                    whatsApps.map((whatsapp, key) => (
                      <MenuItem dense key={key} value={whatsapp.id}>
                        <ListItemText
                          primary={
                            <>
                              <Typography component="span" style={{ fontSize: 14, marginLeft: "10px", display: "inline-flex", alignItems: "center", lineHeight: "2" }}>
                                {whatsapp.name} &nbsp; <span className={(whatsapp.status) === 'CONNECTED' ? classes.online : classes.offline} >({whatsapp.status})</span>
                              </Typography>
                            </>
                          }
                        />
                      </MenuItem>
                    ))
                  }
                  </Select>
                </FormControl>
              </Box>
              <TextField
                label="Qual frase dispara o fluxo?"
                name="phrase"
                variant="outlined"
                margin="dense"
                error={dataItemError.phrase}
                defaultValue={dataItem.phrase}
                onChange={e => {
                  setDataItem(old => {
                    let newValue = old;
                    newValue.phrase = e.target.value;
                    return newValue;
                  });
                }}
                className={classes.textField}
                fullWidth
                required
              />
              <Box mt={2} display="flex" alignItems="center" gap={1}>
                <Typography>Status:</Typography>
                <Checkbox checked={active} onChange={() => setActive(old => !old)} />
                <Typography variant="body2">{active ? "Ativo" : "Desativado"}</Typography>
              </Box>
            </DialogContent>
            <DialogActions className={classes.dialogActionsStyled}>
              <Button
                variant="outlined"
                onClick={() => {
                  onClose();
                  clearErrors();
                }}
                className={classes.secondaryButton}
              >
                Cancelar
              </Button>
              {FlowCampaignId ? (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => applicationSaveAndEdit()}
                  className={classes.primaryButton}
                >
                  Salvar campanha
                </Button>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => applicationSaveAndEdit()}
                  className={classes.primaryButton}
                >
                  Criar campanha
                </Button>
              )}
            </DialogActions>
          </>
        )}
        {loading && (
          <DialogContent className={classes.dialogContentStyled}>
            <Stack
              justifyContent={"center"}
              alignItems={"center"}
              minHeight={"20vh"}
            >
              <CircularProgress />
            </Stack>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
};

export default CampaignModalPhrase;
