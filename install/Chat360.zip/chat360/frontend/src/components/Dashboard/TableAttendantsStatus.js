import React from "react";

import Paper from "@material-ui/core/Paper";
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Tooltip from '@material-ui/core/Tooltip';
import Skeleton from "@material-ui/lab/Skeleton";
import { Box } from "@material-ui/core";

import { makeStyles } from "@material-ui/core/styles";
import { green, grey } from '@material-ui/core/colors';

import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import ErrorIcon from '@material-ui/icons/Error';
import {
    Person as PersonIcon,
    Star as StarIcon,
    RateReview as RateReviewIcon,
    CallEnd as CallEndIcon,
    HourglassEmpty as HourglassEmptyIcon,
    Timer as TimerIcon,
    VerifiedUser as VerifiedUserIcon,
} from '@material-ui/icons';
import moment from 'moment';

import Rating from '@material-ui/lab/Rating';
import { i18n } from "../../translate/i18n";

const useStyles = makeStyles(theme => ({
    on: {
        color: green[600],
        fontSize: '20px'
    },
    off: {
        color: grey[600],
        fontSize: '20px'
    },
    pointer: {
        cursor: "pointer"
    },
    tableContainer: {
        borderRadius: 16,
        overflow: "hidden",
        boxShadow: theme.palette.mode === "dark"
            ? "0 4px 20px rgba(0, 0, 0, 0.5)"
            : "0 4px 20px rgba(0, 0, 0, 0.08)",
    },
    table: {
        minWidth: 800,
        "& .MuiTableHead-root": {
            backgroundColor: theme.palette.background.default,
        },
        "& .MuiTableCell-head": {
            fontWeight: 700,
            fontSize: "0.85rem",
            color: theme.palette.text.primary,
            backgroundColor: theme.palette.background.default,
            borderBottom: `2px solid ${theme.palette.divider}`,
            padding: theme.spacing(2),
            whiteSpace: "nowrap",
        },
        "& tbody tr": {
            borderBottom: `1px solid ${theme.palette.divider}`,
            transition: "background-color 0.2s ease",
            "&:hover": {
                backgroundColor: theme.palette.mode === "dark"
                    ? "rgba(255, 255, 255, 0.05)"
                    : "rgba(0, 0, 0, 0.02)",
            },
        },
        "& tbody td": {
            padding: theme.spacing(2),
            borderBottom: "none",
            color: theme.palette.text.primary,
        },
    },
    headerIcon: {
        display: "flex",
        alignItems: "center",
        gap: theme.spacing(1),
        justifyContent: "center",
        "& svg": {
            fontSize: "1rem",
        },
    },
}));

export function RatingBox({ rating }) {
    const ratingTrunc = rating === null ? 0 : Math.trunc(rating);
    return <Rating
        defaultValue={ratingTrunc}
        max={3}
        readOnly
    />
}

export default function TableAttendantsStatus(props) {
    const { loading, attendants } = props
    const classes = useStyles();

    function renderList() {
        return attendants.map((a, k) => (
            <TableRow key={k}>
                <TableCell>{a.name}</TableCell>
                {/* <TableCell align="center" title="1 - Insatisfeito, 2 - Satisfeito, 3 - Muito Satisfeito" className={classes.pointer}>
                    <RatingBox rating={a.rating} />
                </TableCell> */}
                <TableCell align="center">{a.rating}</TableCell>
                <TableCell align="center">{a.countRating}</TableCell>
                <TableCell align="center">{a.tickets}</TableCell>
                <TableCell align="center">{formatTime(a.avgWaitTime, 2)}</TableCell>
                <TableCell align="center">{formatTime(a.avgSupportTime, 2)}</TableCell>
                <TableCell align="center">
                    {a.online ?
                        <Tooltip title="Online">
                            <CheckCircleIcon className={classes.on} />
                        </Tooltip>
                        :
                        <Tooltip title="Offline">
                            <ErrorIcon className={classes.off} />
                        </Tooltip>
                    }
                </TableCell>
            </TableRow>
        ))
    }

    function formatTime(minutes) {
        return moment().startOf('day').add(minutes, 'minutes').format('HH[h] mm[m]');
    }

    return (!loading ?
        <TableContainer component={Paper} className={classes.tableContainer}>
            <Table className={classes.table}>
                <TableHead>
                    <TableRow>
                        <TableCell align="center">
                            <Tooltip title="Nome do atendente">
                                <Box className={classes.headerIcon}>
                                    <PersonIcon />
                                    <span>{i18n.t("dashboard.users.name")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                        <TableCell align="center">
                            <Tooltip title="Score de avaliação">
                                <Box className={classes.headerIcon}>
                                    <StarIcon />
                                    <span>{i18n.t("dashboard.assessments.score")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                        <TableCell align="center">
                            <Tooltip title="Quantidade de atendimentos avaliados">
                                <Box className={classes.headerIcon}>
                                    <RateReviewIcon />
                                    <span>{i18n.t("dashboard.assessments.ratedCalls")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                        <TableCell align="center">
                            <Tooltip title="Total de atendimentos">
                                <Box className={classes.headerIcon}>
                                    <CallEndIcon />
                                    <span>{i18n.t("dashboard.assessments.totalCalls")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                        <TableCell align="center">
                            <Tooltip title="Tempo médio de espera">
                                <Box className={classes.headerIcon}>
                                    <HourglassEmptyIcon />
                                    <span>{i18n.t("dashboard.cards.averageWaitingTime")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                        <TableCell align="center">
                            <Tooltip title="Tempo médio de atendimento">
                                <Box className={classes.headerIcon}>
                                    <TimerIcon />
                                    <span>{i18n.t("dashboard.cards.averageServiceTime")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                        <TableCell align="center">
                            <Tooltip title="Status do atendente">
                                <Box className={classes.headerIcon}>
                                    <VerifiedUserIcon />
                                    <span>{i18n.t("dashboard.cards.status")}</span>
                                </Box>
                            </Tooltip>
                        </TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {renderList()}
                </TableBody>
            </Table>
        </TableContainer>
        : <Skeleton variant="rect" height={150} />
    )
}