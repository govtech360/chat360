import React, { useState, useEffect, useRef } from "react";

import * as Yup from "yup";
import { Formik, FieldArray, Form, Field } from "formik";
import { toast } from "react-toastify";

import { makeStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import CircularProgress from "@material-ui/core/CircularProgress";
import Box from "@material-ui/core/Box";
import TextFieldsIcon from "@material-ui/icons/TextFields";

import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";
import { Stack } from "@mui/material";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap"
  },
  dialogPaper: {
    borderRadius: 12,
    boxShadow: theme.palette.mode === "dark"
      ? "0 8px 32px rgba(0, 0, 0, 0.6)"
      : "0 8px 32px rgba(0, 0, 0, 0.15)",
  },
  dialogTitleStyled: {
    padding: theme.spacing(3, 4, 2),
    backgroundColor: theme.palette.background.default,
  },
  titleContent: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1.5),
    "& svg": {
      fontSize: "1.5rem",
      color: theme.palette.primary.main,
    },
  },
  dialogContentStyled: {
    padding: theme.spacing(3, 4),
    backgroundColor: theme.palette.background.paper,
  },
  dialogActionsStyled: {
    padding: theme.spacing(2, 3),
    backgroundColor: theme.palette.background.default,
    borderTop: `1px solid ${theme.palette.divider}`,
    gap: theme.spacing(1.5),
  },
  textField: {
    flex: 1,
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
      transition: "all 0.3s ease",
      "&:hover": {
        boxShadow: theme.palette.mode === "dark"
          ? "0 0 0 1px rgba(255, 255, 255, 0.1)"
          : "0 0 0 1px rgba(0, 0, 0, 0.1)",
      },
      "&.Mui-focused": {
        boxShadow: `0 0 0 2px ${theme.palette.primary.main}25`,
      },
    },
  },
  primaryButton: {
    borderRadius: 8,
    padding: theme.spacing(1, 3),
    textTransform: "none",
    fontWeight: 500,
  },
  secondaryButton: {
    borderRadius: 8,
    padding: theme.spacing(1, 3),
    textTransform: "none",
    fontWeight: 500,
  },
  extraAttr: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },
  btnWrapper: {
    position: "relative"
  },
  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12
  }
}));

const ContactSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Digite um nome!"),
  text: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Digite uma mensagem!")
});

const FlowBuilderAddTextModal = ({ open, onSave, onUpdate, data, close }) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const [activeModal, setActiveModal] = useState(false);

  const [labels, setLabels] = useState({
    title: "Adicionar mensagem ao fluxo",
    btn: "Adicionar"
  });

  const [textDig, setTextDig] = useState();

  useEffect(() => {
    if (open === "edit") {
      setLabels({
        title: "Editar mensagem ao fluxo",
        btn: "Salvar"
      });
      setTextDig(data.data.label);
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({
        title: "Adicionar mensagem ao fluxo",
        btn: "Adicionar"
      });
      setTextDig("");
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open]);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  const handleClose = () => {
    close(null)
    setActiveModal(false);
  };

  const handleSaveContact = async () => {
    if (open === "edit") {
      handleClose();
      onUpdate({
        ...data,
        data: { label: textDig }
      });
      return;
    } else if (open === "create") {
      handleClose();
      onSave({
        text: textDig
      });
    }
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={activeModal}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        scroll="paper"
        PaperProps={{ className: classes.dialogPaper }}
      >
        <DialogTitle className={classes.dialogTitleStyled}>
          <Box className={classes.titleContent}>
            <TextFieldsIcon />
            <Typography variant="h6">{labels.title}</Typography>
          </Box>
        </DialogTitle>
        <DialogContent dividers className={classes.dialogContentStyled}>
          <TextField
            label="Mensagem"
            multiline
            rows={7}
            name="text"
            variant="outlined"
            value={textDig}
            onChange={e => setTextDig(e.target.value)}
            className={classes.textField}
            fullWidth
          />
        </DialogContent>
        <DialogActions className={classes.dialogActionsStyled}>
          <Button 
            onClick={handleClose} 
            variant="outlined" 
            className={classes.secondaryButton}
          >
            {i18n.t("contactModal.buttons.cancel")}
          </Button>
          <Button
            type="submit"
            color="primary"
            variant="contained"
            className={classes.primaryButton}
            onClick={() => handleSaveContact()}
          >
            {labels.btn}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default FlowBuilderAddTextModal;
