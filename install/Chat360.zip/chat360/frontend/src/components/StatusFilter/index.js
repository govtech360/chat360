import { Box, Chip, TextField, makeStyles } from "@material-ui/core";
import Autocomplete from "@material-ui/lab/Autocomplete";
import React, { useEffect, useState } from "react";
import { i18n } from "../../translate/i18n";

const useStyles = makeStyles((theme) => ({
  autocompleteField: {
    "& .MuiOutlinedInput-root": {
      borderRadius: 10,
      backgroundColor: theme.palette.background.paper,
      transition: "all 0.2s ease",
      "&:hover": {
        borderColor: theme.palette.primary.main,
        boxShadow: theme.palette.mode === "dark"
          ? "0 2px 8px rgba(0, 0, 0, 0.3)"
          : "0 2px 8px rgba(0, 0, 0, 0.1)",
      },
      "&.Mui-focused": {
        boxShadow: theme.palette.mode === "dark"
          ? "0 2px 12px rgba(0, 0, 0, 0.4)"
          : "0 2px 12px rgba(0, 0, 0, 0.15)",
      },
    },
  },
}));

export function StatusFilter({ onFiltered }) {
  const classes = useStyles();
  const [selecteds, setSelecteds] = useState([]);

  useEffect(() => {
    async function fetchData() {
      
    }
    fetchData();
  }, []);

  const onChange = async (value) => {
    setSelecteds(value);
    onFiltered(value);
  };

  const status = [
    { status: 'open', name: `${i18n.t("tickets.search.filterConectionsOptions.open")}` },
    { status: 'closed', name: `${i18n.t("tickets.search.filterConectionsOptions.closed")}` },
    { status: 'pending', name: `${i18n.t("tickets.search.filterConectionsOptions.pending")}` },
    { status: 'group', name: 'Grupos' },

  ]

  return (
    <Box style={{ padding: "0px 10px 10px" }}>
      <Autocomplete 
       multiple      
       size="small"
       options={status}
       value={selecteds}
       onChange={(e, v, r) => onChange(v)}
       getOptionLabel={(option) => option.name}
       renderTags={(value, getTagProps) =>
         value.map((option, index) => (
           <Chip
             variant="outlined"
             style={{
               backgroundColor: option.color || "#eee",
               textShadow: "1px 1px 1px #000",
               color: "white",
             }}
             label={option.name}
             {...getTagProps({ index })}
             size="small"
           />
         ))
       }
       renderInput={(params) => (
         <TextField
           {...params}
           variant="outlined"
           placeholder="Filtro por Status"
           className={classes.autocompleteField}
         />
       )}
      />
    </Box>
  );
}
