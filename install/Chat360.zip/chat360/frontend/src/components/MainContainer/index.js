import React from "react";

import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";

const useStyles = makeStyles(theme => ({
	mainContainer: {
		flex: 1,
		minHeight: `calc(100vh - 48px)`,
		height: "auto",
		maxWidth: "100%",
		paddingLeft: `${24}px !important`,
		paddingRight: `${24}px !important`,
		paddingTop: `${24}px !important`,
		paddingBottom: `${24}px !important`,
		[theme.breakpoints.up("xl")]: {
			maxWidth: 1600,
		},
		[theme.breakpoints.down("sm")]: {
			paddingLeft: `${16}px !important`,
			paddingRight: `${16}px !important`,
			paddingTop: `${16}px !important`,
			paddingBottom: `${16}px !important`,
		},
		[theme.breakpoints.down("xs")]: {
			paddingLeft: `${12}px !important`,
			paddingRight: `${12}px !important`,
			paddingTop: `${12}px !important`,
			paddingBottom: `${12}px !important`,
		},
	},

	contentWrapper: {
		height: "100%",
		overflowY: "visible",
		display: "flex",
		flexDirection: "column",
	},
}));

const MainContainer = ({ children, className }) => {
	const classes = useStyles();

	return (
		<Container className={`${classes.mainContainer} ${className || ''}`} maxWidth={false}>
			<div className={classes.contentWrapper}>{children}</div>
		</Container>
	);
};

export default MainContainer;
