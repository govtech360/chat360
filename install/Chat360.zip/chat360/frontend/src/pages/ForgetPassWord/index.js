import React, { useState } from "react";
import { Link as RouterLink } from "react-router-dom";
import { Button, TextField, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Fade } from "@mui/material";
import { Helmet } from "react-helmet";
import { toast } from "react-toastify";
import SecurityIcon from "@material-ui/icons/Security";
import EmailIcon from "@material-ui/icons/Email";
import { InputAdornment } from "@mui/material";
import toastError from "../../errors/toastError";
import api from "../../services/api";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100vw",
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    overflow: "hidden",
    background: "linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%)",
    padding: "40px 20px",
    "&::before": {
      content: '""',
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 
        "radial-gradient(circle at 20% 50%, rgba(62, 58, 242, 0.12) 0%, transparent 50%)," +
        "radial-gradient(circle at 80% 80%, rgba(107, 95, 255, 0.12) 0%, transparent 50%)",
      animation: "$gradientShift 15s ease infinite",
    },
  },
  "@keyframes gradientShift": {
    "0%, 100%": { opacity: 1 },
    "50%": { opacity: 0.8 },
  },
  "@keyframes fadeInUp": {
    "0%": { opacity: 0, transform: "translateY(30px)" },
    "100%": { opacity: 1, transform: "translateY(0)" },
  },
  formSection: {
    width: "100%",
    maxWidth: "440px",
    margin: "0 auto",
    position: "relative",
    zIndex: 1,
    animation: "$fadeInUp 0.8s cubic-bezier(0.4, 0, 0.2, 1)",
  },
  formContainer: {
    background: "rgba(26, 26, 26, 0.95)",
    backdropFilter: "blur(30px)",
    borderRadius: "20px",
    padding: "36px 40px",
    boxShadow: 
      "0 25px 70px rgba(0, 0, 0, 0.5)," +
      "0 0 0 1px rgba(62, 58, 242, 0.2)," +
      "inset 0 1px 0 rgba(255, 255, 255, 0.05)",
    position: "relative",
    transition: "all 0.4s ease",
    "&:hover": {
      boxShadow: 
        "0 30px 80px rgba(0, 0, 0, 0.6)," +
        "0 0 0 1px rgba(62, 58, 242, 0.4)," +
        "inset 0 1px 0 rgba(255, 255, 255, 0.08)",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "32px 28px",
    },
    [theme.breakpoints.down("xs")]: {
      padding: "28px 20px",
    },
  },
  formLogo: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "20px",
    "& img": {
      maxWidth: "200px",
      height: "auto",
      filter: "drop-shadow(0 0 20px rgba(62, 58, 242, 0.4))",
      transition: "all 0.3s ease",
      "&:hover": {
        transform: "scale(1.05)",
        filter: "drop-shadow(0 0 30px rgba(107, 95, 255, 0.6))",
      },
    },
  },
  formTitle: {
    fontSize: "clamp(1.5rem, 4vw, 1.75rem)",
    fontWeight: 800,
    color: "#ffffff",
    marginBottom: "8px",
    textAlign: "center",
    background: "linear-gradient(135deg, #3E3AF2 0%, #6B5FFF 100%)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text",
    letterSpacing: "-0.01em",
  },
  formSubtitle: {
    fontSize: "0.88rem",
    color: "#94a3b8",
    marginBottom: "24px",
    textAlign: "center",
    lineHeight: 1.4,
  },
  inputField: {
    marginBottom: "16px",
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
      backgroundColor: "#0f172a",
      transition: "all 0.3s ease",
      border: "1px solid rgba(62, 58, 242, 0.2)",
      minHeight: "48px",
      [theme.breakpoints.down("sm")]: {
        minHeight: "46px",
      },
      "&:hover": {
        backgroundColor: "#1a2332",
        borderColor: "rgba(62, 58, 242, 0.4)",
        "& fieldset": {
          borderColor: "rgba(62, 58, 242, 0.4)",
        },
      },
      "&.Mui-focused": {
        backgroundColor: "#1a2332",
        borderColor: "#3E3AF2",
        boxShadow: "0 0 0 3px rgba(62, 58, 242, 0.12)",
        "& fieldset": {
          borderColor: "#3E3AF2 !important",
          borderWidth: "2px",
        },
      },
    },
    "& .MuiOutlinedInput-input": {
      padding: "14px 14px",
      fontSize: "0.93rem",
      color: "#e2e8f0",
      fontWeight: 500,
      [theme.breakpoints.down("sm")]: {
        padding: "13px 13px",
        fontSize: "0.91rem",
      },
    },
    "& .MuiInputLabel-outlined": {
      fontSize: "0.93rem",
      fontWeight: 500,
      color: "#94a3b8",
      transform: "translate(14px, 15px) scale(1)",
      [theme.breakpoints.down("sm")]: {
        fontSize: "0.91rem",
        transform: "translate(14px, 14px) scale(1)",
      },
      "&.MuiInputLabel-shrink": {
        transform: "translate(14px, -9px) scale(0.75)",
        backgroundColor: "#0f172a",
        padding: "0 4px",
      },
      "&.Mui-focused": {
        color: "#3E3AF2",
        fontWeight: 600,
        backgroundColor: "#0f172a",
        padding: "0 4px",
      },
    },
    "& fieldset": {
      borderColor: "rgba(62, 58, 242, 0.2)",
      borderWidth: "1px",
    },
    "& .MuiInputAdornment-root": {
      "& svg": {
        color: "#3E3AF2",
        fontSize: "1.3rem",
      },
    },
  },
  submitBtn: {
    marginBottom: "12px",
    background: "linear-gradient(135deg, #3E3AF2 0%, #6B5FFF 100%)",
    color: "#fff",
    padding: "10px 28px",
    fontSize: "0.98rem",
    fontWeight: 600,
    width: "100%",
    height: "48px",
    borderRadius: "8px",
    textTransform: "none",
    boxShadow: "0 4px 15px rgba(62, 58, 242, 0.4)",
    transition: "all 0.3s ease",
    cursor: "pointer",
    border: "2px solid transparent",
    position: "relative",
    overflow: "visible",
    [theme.breakpoints.down("sm")]: {
      height: "46px",
      fontSize: "0.95rem",
      padding: "10px 24px",
    },
    "&:hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 10px 20px rgba(62, 58, 242, 0.3)",
    },
    "&:active": {
      transform: "translateY(0)",
    },
    "&:disabled": {
      background: "#334155",
      color: "#64748b",
      cursor: "not-allowed",
      transform: "none",
      boxShadow: "none",
    },
  },
  backToLogin: {
    marginTop: "16px",
    textAlign: "center",
  },
  backToLoginLink: {
    color: "#3E3AF2",
    textDecoration: "none",
    fontSize: "0.9rem",
    fontWeight: 600,
    transition: "all 0.2s ease",
    position: "relative",
    "&::after": {
      content: '""',
      position: "absolute",
      bottom: -2,
      left: 0,
      width: "0%",
      height: "2px",
      background: "linear-gradient(90deg, #3E3AF2, #6B5FFF)",
      transition: "width 0.3s ease",
    },
    "&:hover": {
      color: "#6B5FFF",
      "&::after": {
        width: "100%",
      },
    },
  },
  securityBadge: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "20px",
    padding: "10px 16px",
    backgroundColor: "rgba(59, 130, 246, 0.1)",
    borderRadius: "10px",
    border: "1px solid rgba(59, 130, 246, 0.3)",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: "rgba(59, 130, 246, 0.15)",
      transform: "scale(1.02)",
    },
  },
  securityText: {
    display: "flex",
    alignItems: "center",
    fontSize: "0.82rem",
    color: "#60a5fa",
    fontWeight: 600,
    "& svg": {
      marginRight: "8px",
      fontSize: "1.2rem",
      color: "#3b82f6",
    },
  },
  successMessage: {
    backgroundColor: "rgba(16, 185, 129, 0.1)",
    color: "#10b981",
    padding: "12px 16px",
    borderRadius: "10px",
    marginBottom: "20px",
    fontSize: "0.88rem",
    border: "1px solid rgba(16, 185, 129, 0.3)",
    textAlign: "center",
    fontWeight: 600,
  },
}));

const ForgotPassword = () => {
  const classes = useStyles();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post("/auth/forgot-password", { email });
      toast.success("Link de redefinição de senha enviado com sucesso!");
      setSent(true);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      toastError(err);
    }
  };

  return (
    <>
      <Helmet>
        <title>Redefinir Senha - Chat360</title>
        <meta name="description" content="Recupere sua senha da plataforma Chat360" />
        <link rel="icon" type="image/png" href="/favicon.png" />
      </Helmet>

      <div className={classes.root}>
        <div className={classes.formSection}>
          <Fade in={true} timeout={800}>
            <form className={classes.formContainer} onSubmit={handleSubmit}>
              {/* Logo do Chat360 */}
              <div className={classes.formLogo}>
                <img 
                  src="/logo-horizontal-branco.png" 
                  alt="Chat360 Logo" 
                />
              </div>

              <Typography className={classes.formTitle}>
                Redefinir Senha
              </Typography>
              <Typography className={classes.formSubtitle}>
                Digite seu email e enviaremos as instruções
              </Typography>

              {sent && (
                <Fade in={true}>
                  <div className={classes.successMessage}>
                    Email enviado!
                    <br />
                    Verifique sua caixa de entrada.
                  </div>
                </Fade>
              )}

              <TextField
                label="Email"
                variant="outlined"
                fullWidth
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={classes.inputField}
                disabled={loading || sent}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <EmailIcon />
                    </InputAdornment>
                  ),
                }}
              />

              <Button
                type="submit"
                variant="contained"
                className={classes.submitBtn}
                disabled={loading || sent}
                disableElevation
              >
                {loading ? "Enviando..." : sent ? "Email enviado!" : "Enviar link de redefinição"}
              </Button>

              <div className={classes.backToLogin}>
                <RouterLink
                  to="/login"
                  className={classes.backToLoginLink}
                >
                  ← Voltar ao login
                </RouterLink>
              </div>

              <div className={classes.securityBadge}>
                <div className={classes.securityText}>
                  <SecurityIcon />
                  <span>Suas informações estão protegidas</span>
                </div>
              </div>
            </form>
          </Fade>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;
