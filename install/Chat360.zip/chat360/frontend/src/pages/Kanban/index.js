import React, { useState, useEffect, useContext } from "react";
import { makeStyles, useTheme } from "@material-ui/core/styles";
import api from "../../services/api";
import { AuthContext } from "../../context/Auth/AuthContext";
import Board from 'react-trello';
import { toast } from "react-toastify";
import { i18n } from "../../translate/i18n";
import { useHistory } from 'react-router-dom';
import { Facebook, Instagram, WhatsApp, ViewColumn, CalendarToday, Add } from "@material-ui/icons";
import { Badge, Tooltip, Typography, Button, TextField, Box, Paper } from "@material-ui/core";
import { format, isSameDay, parseISO } from "date-fns";
import { Can } from "../../components/Can";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(2),
  },
  mainPaper: {
    width: '100%',
    borderRadius: 20,
    overflow: "visible",
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
    padding: theme.spacing(3),
  },
  kanbanContainer: {
    width: "100%",
    marginTop: theme.spacing(2),
    maxHeight: 'calc(100vh - 220px)',
    overflowX: "auto",
    overflowY: "visible",
    "&::-webkit-scrollbar": {
      width: "0px",
      height: "8px",
    },
    "&::-webkit-scrollbar-thumb": {
      boxShadow: "inset 0 0 6px rgba(0, 0, 0, 0.3)",
      backgroundColor: theme.palette.mode === "dark" ? theme.palette.primary.main : theme.palette.primary.main,
      borderRadius: "4px",
    },
    "&::-webkit-scrollbar-track": {
      backgroundColor: "transparent",
    },
    "&::-webkit-scrollbar-track-piece": {
      backgroundColor: "transparent",
    },
    scrollbarWidth: "thin",
    scrollbarColor: theme.palette.mode === "dark" 
      ? `${theme.palette.primary.main} transparent`
      : `${theme.palette.primary.main} transparent`,
  },
  filterContainer: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(2),
    marginBottom: theme.spacing(3),
  },
  connectionTag: {
    backgroundColor: theme.palette.success.main,
    color: theme.palette.common.white,
    marginRight: theme.spacing(1),
    padding: theme.spacing(0.5, 1),
    fontWeight: 600,
    borderRadius: 6,
    fontSize: "0.65em",
  },
  lastMessageTime: {
    justifySelf: "flex-end",
    textAlign: "right",
    position: "relative",
    marginLeft: "auto",
    color: theme.palette.text.secondary,
    fontSize: "0.75rem",
  },
  lastMessageTimeUnread: {
    justifySelf: "flex-end",
    textAlign: "right",
    position: "relative",
    color: theme.palette.success.main,
    fontWeight: 600,
    marginLeft: "auto",
    fontSize: "0.75rem",
  },
  cardButton: {
    borderRadius: 8,
    padding: "6px 16px",
    textTransform: "none",
    fontWeight: 600,
    fontSize: "0.75rem",
    marginRight: theme.spacing(1),
    color: theme.palette.common.white,
    backgroundColor: theme.palette.primary.main,
    transition: "all 0.2s ease",
    "&:hover": {
      backgroundColor: theme.palette.primary.dark,
      boxShadow: theme.palette.mode === "dark"
        ? "0 4px 12px rgba(0, 0, 0, 0.5)"
        : "0 4px 12px rgba(0, 0, 0, 0.15)",
    },
  },
  dateInput: {
    width: 180,
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
    },
  },
  searchButton: {
    borderRadius: 8,
    padding: "8px 20px",
    textTransform: "none",
    fontWeight: 600,
    transition: "all 0.2s ease",
    "&:hover": {
      boxShadow: theme.palette.mode === "dark"
        ? "0 4px 12px rgba(0, 0, 0, 0.5)"
        : "0 4px 12px rgba(0, 0, 0, 0.15)",
    },
  },
  addColumnButton: {
    borderRadius: 8,
    padding: "8px 20px",
    textTransform: "none",
    fontWeight: 600,
    transition: "all 0.2s ease",
    "&:hover": {
      boxShadow: theme.palette.mode === "dark"
        ? "0 4px 12px rgba(0, 0, 0, 0.5)"
        : "0 4px 12px rgba(0, 0, 0, 0.15)",
    },
  },
}));

const Kanban = () => {
  const classes = useStyles();
  const theme = useTheme(); // Obter o tema atual
  const history = useHistory();
  const { user, socket } = useContext(AuthContext);
  const [tags, setTags] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [ticketNot, setTicketNot] = useState(0);
  const [file, setFile] = useState({ lanes: [] });
  const [startDate, setStartDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));

  const jsonString = user.queues.map(queue => queue.UserQueue.queueId);

  useEffect(() => {
    fetchTags();
  }, [user]);

  const fetchTags = async () => {
    try {
      const response = await api.get("/tag/kanban/");
      const fetchedTags = response.data.lista || [];
      setTags(fetchedTags);
      fetchTickets();
    } catch (error) {
      console.log(error);
    }
  };

  const fetchTickets = async () => {
    try {
      const { data } = await api.get("/ticket/kanban", {
        params: {
          queueIds: JSON.stringify(jsonString),
          startDate: startDate,
          endDate: endDate,
        }
      });
      setTickets(data.tickets);
    } catch (err) {
      console.log(err);
      setTickets([]);
    }
  };

  useEffect(() => {
    const companyId = user.companyId;
    const onAppMessage = (data) => {
      if (data.action === "create" || data.action === "update" || data.action === "delete") {
        fetchTickets();
      }
    };
    socket.on(`company-${companyId}-ticket`, onAppMessage);
    socket.on(`company-${companyId}-appMessage`, onAppMessage);

    return () => {
      socket.off(`company-${companyId}-ticket`, onAppMessage);
      socket.off(`company-${companyId}-appMessage`, onAppMessage);
    };
  }, [socket, startDate, endDate]);

  const handleSearchClick = () => {
    fetchTickets();
  };

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  const IconChannel = (channel) => {
    switch (channel) {
      case "facebook":
        return <Facebook style={{ color: "#3b5998", verticalAlign: "middle", fontSize: "16px" }} />;
      case "instagram":
        return <Instagram style={{ color: "#e1306c", verticalAlign: "middle", fontSize: "16px" }} />;
      case "whatsapp":
        return <WhatsApp style={{ color: "#25d366", verticalAlign: "middle", fontSize: "16px" }} />
      default:
        return "error";
    }
  };

  const popularCards = (jsonString) => {
    const filteredTickets = tickets.filter(ticket => ticket.tags.length === 0);

    const lanes = [
      {
        id: "lane0",
        title: i18n.t("tagsKanban.laneDefault"),
        label: filteredTickets.length.toString(),
        style: { 
          borderRadius: 12,
          backgroundColor: theme.palette.background.paper,
          border: `1px solid ${theme.palette.divider}`,
          color: theme.palette.text.primary,
        },
        labelStyle: {
          color: theme.palette.text.primary,
        },
        titleStyle: {
          color: theme.palette.text.primary,
          fontWeight: 600,
        },
        cards: filteredTickets.map(ticket => ({
          id: ticket.id.toString(),
          label: "Ticket nº " + ticket.id.toString(),
          description: (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{ticket.contact.number}</span>
                <Typography
                  className={Number(ticket.unreadMessages) > 0 ? classes.lastMessageTimeUnread : classes.lastMessageTime}
                  component="span"
                  variant="body2"
                >
                  {isSameDay(parseISO(ticket.updatedAt), new Date()) ? (
                    <>{format(parseISO(ticket.updatedAt), "HH:mm")}</>
                  ) : (
                    <>{format(parseISO(ticket.updatedAt), "dd/MM/yyyy")}</>
                  )}
                </Typography>
              </div>
              <div style={{ textAlign: 'left' }}>{ticket.lastMessage || " "}</div>
              <Button
                className={`${classes.button} ${classes.cardButton}`}
                onClick={() => {
                  handleCardClick(ticket.uuid)
                }}>
                Ver Ticket
              </Button>
              <span style={{ marginRight: '8px' }} />
              {ticket?.user && (<Badge style={{ backgroundColor: "#000000" }} className={classes.connectionTag}>{ticket.user?.name.toUpperCase()}</Badge>)}
            </div>
          ),
          title: <>
            <Tooltip title={ticket.whatsapp?.name}>
              {IconChannel(ticket.channel)}
            </Tooltip> {ticket.contact.name}</>,
          draggable: true,
          href: "/tickets/" + ticket.uuid,
        })),
      },
      ...tags.map(tag => {
        const filteredTickets = tickets.filter(ticket => {
          const tagIds = ticket.tags.map(tag => tag.id);
          return tagIds.includes(tag.id);
        });

        return {
          id: tag.id.toString(),
          title: tag.name,
          label: filteredTickets?.length.toString(),
          style: { 
            backgroundColor: tag.color,
            color: "white",
            borderRadius: 12,
            border: `2px solid ${tag.color}`,
          },
          labelStyle: {
            color: "white",
          },
          titleStyle: {
            color: "white",
            fontWeight: 600,
          },
          cards: filteredTickets.map(ticket => ({
            id: ticket.id.toString(),
            label: "Ticket nº " + ticket.id.toString(),
            description: (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ color: theme.palette.text.primary }}>{ticket.contact.number}</span>
                  <Typography
                    className={Number(ticket.unreadMessages) > 0 ? classes.lastMessageTimeUnread : classes.lastMessageTime}
                    component="span"
                    variant="body2"
                  >
                    {isSameDay(parseISO(ticket.updatedAt), new Date()) ? (
                      <>{format(parseISO(ticket.updatedAt), "HH:mm")}</>
                    ) : (
                      <>{format(parseISO(ticket.updatedAt), "dd/MM/yyyy")}</>
                    )}
                  </Typography>
                </div>
                <div style={{ 
                  textAlign: 'left', 
                  marginBottom: 12,
                  color: theme.palette.text.primary,
                  fontSize: '0.85rem',
                }}>
                  {ticket.lastMessage || " "}
                </div>
                <Button
                  className={classes.cardButton}
                  onClick={() => {
                    handleCardClick(ticket.uuid)
                  }}>
                  Ver Ticket
                </Button>
                {ticket?.user && (
                  <Badge className={classes.connectionTag}>
                    {ticket.user?.name.toUpperCase()}
                  </Badge>
                )}
              </div>
            ),
            title: <>
              <Tooltip title={ticket.whatsapp?.name}>
                {IconChannel(ticket.channel)}
              </Tooltip> {ticket.contact.name}
            </>,
            draggable: true,
            href: "/tickets/" + ticket.uuid,
          })),
        };
      }),
    ];

    setFile({ lanes });
  };

  const handleCardClick = (uuid) => {
    history.push('/tickets/' + uuid);
  };

  useEffect(() => {
    popularCards(jsonString);
  }, [tags, tickets]);

  const handleCardMove = async (cardId, sourceLaneId, targetLaneId) => {
    try {
      await api.delete(`/ticket-tags/${targetLaneId}`);
      toast.success('Ticket Tag Removido!');
      await api.put(`/ticket-tags/${targetLaneId}/${sourceLaneId}`);
      toast.success('Ticket Tag Adicionado com Sucesso!');
      await fetchTickets(jsonString);
      popularCards(jsonString);
    } catch (err) {
      console.log(err);
    }
  };

  const handleAddConnectionClick = () => {
    history.push('/tagsKanban');
  };

  return (
    <MainContainer className={classes.root}>
      <MainHeader>
        <Title>{i18n.t("mainDrawer.listItems.kanban")}</Title>
        <MainHeaderButtonsWrapper>
          <TextField
            label="Data de início"
            type="date"
            value={startDate}
            onChange={handleStartDateChange}
            InputLabelProps={{
              shrink: true,
            }}
            variant="outlined"
            size="small"
            className={classes.dateInput}
          />
          <TextField
            label="Data de fim"
            type="date"
            value={endDate}
            onChange={handleEndDateChange}
            InputLabelProps={{
              shrink: true,
            }}
            variant="outlined"
            size="small"
            className={classes.dateInput}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={handleSearchClick}
            className={classes.searchButton}
            startIcon={<CalendarToday />}
          >
            Buscar
          </Button>
          <Can role={user.profile} perform="dashboard:view" yes={() => (
            <Button
              variant="contained"
              color="primary"
              onClick={handleAddConnectionClick}
              className={classes.addColumnButton}
              startIcon={<Add />}
            >
              Adicionar colunas
            </Button>
          )} />
        </MainHeaderButtonsWrapper>
      </MainHeader>
      <Paper className={classes.mainPaper} elevation={0}>
        <div className={classes.kanbanContainer}>
          <Board
            data={file}
            onCardMoveAcrossLanes={handleCardMove}
            style={{ 
              backgroundColor: theme.palette.background.paper,
              borderRadius: 12,
              height: 'auto',
              maxHeight: 'calc(100vh - 250px)',
            }}
            laneStyle={{ 
              borderRadius: 12,
              backgroundColor: theme.palette.background.paper,
              border: `1px solid ${theme.palette.divider}`,
              maxHeight: 'calc(100vh - 300px)',
            }}
            cardStyle={{ 
              borderRadius: 12,
              backgroundColor: theme.palette.background.default,
              border: `1px solid ${theme.palette.divider}`,
              color: theme.palette.text.primary,
            }}
          />
        </div>
      </Paper>
    </MainContainer>
  );
};

export default Kanban;
