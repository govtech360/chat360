import React from "react";
import {
    Button,
    Grid,
    TextField,
    Typography,
    makeStyles,
} from "@material-ui/core";
import { i18n } from "../../translate/i18n";

const useStyles = makeStyles((theme) => ({
    filterTitle: {
        fontWeight: 700,
        marginBottom: theme.spacing(2),
        color: theme.palette.text.primary,
    },
    dateField: {
        "& .MuiOutlinedInput-root": {
            borderRadius: 8,
        },
    },
    filterButton: {
        borderRadius: 8,
        padding: "8px 20px",
        textTransform: "none",
        fontWeight: 600,
        transition: "all 0.2s ease",
        "&:hover": {
            boxShadow: theme.palette.mode === "dark"
                ? "0 4px 12px rgba(0, 0, 0, 0.5)"
                : "0 4px 12px rgba(0, 0, 0, 0.15)",
        },
    },
}));

const Filters = ({
    setDateStartTicket,
    setDateEndTicket,
    dateStartTicket,
    dateEndTicket,
    setQueueTicket,
    queueTicket,
    fetchData
}) => {
    const classes = useStyles();
    const [queues] = React.useState(queueTicket);
    const [dateStart, setDateStart] = React.useState(dateStartTicket);
    const [dateEnd, setDateEnd] = React.useState(dateEndTicket);
    const [fetchDataFilter, setFetchDataFilter] = React.useState(false);

    return (
        <>
            <Typography variant="h6" className={classes.filterTitle}>
                Filtros de Período
            </Typography>
            <Grid container spacing={2}>
                <Grid item xs={12} sm={4} md={4}>
                    <TextField
                        fullWidth
                        size="small"
                        name="dateStart"
                        label={i18n.t("dashboard.date.initialDate")}
                        variant="outlined"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        type="date"
                        value={dateStart}
                        onChange={(e) => setDateStart(e.target.value)}
                        className={classes.dateField}
                    />
                </Grid>
                <Grid item xs={12} sm={4} md={4}>
                    <TextField
                        fullWidth
                        size="small"
                        name="dateEnd"
                        label={i18n.t("dashboard.date.finalDate")}
                        variant="outlined"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        type="date"
                        value={dateEnd}
                        onChange={(e) => setDateEnd(e.target.value)}
                        className={classes.dateField}
                    />
                </Grid>
                <Grid item xs={12} sm={4} md={4}>
                    <Button
                        fullWidth
                        variant="contained"
                        color="primary"
                        className={classes.filterButton}
                        onClick={() => {
                            setQueueTicket(queues);
                            setDateStartTicket(dateStart);
                            setDateEndTicket(dateEnd);
                            setFetchDataFilter(!fetchDataFilter);
                            fetchData(!fetchDataFilter);
                        }}
                    >
                        Filtrar
                    </Button>
                </Grid>
            </Grid>
        </>
    );
};

export default Filters;
