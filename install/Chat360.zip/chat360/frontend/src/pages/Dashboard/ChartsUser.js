import React, { useEffect, useState, useContext } from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { Typography } from '@material-ui/core';
import api from '../../services/api';
import { toast } from 'react-toastify';
import { makeStyles, useTheme } from "@material-ui/core/styles";
import './button.css';
import { i18n } from '../../translate/i18n';
import { AuthContext } from "../../context/Auth/AuthContext";

const useStyles = makeStyles((theme) => ({
    container: {
        paddingTop: theme.spacing(1),
        paddingBottom: theme.padding,
        paddingLeft: theme.spacing(1),
        paddingRight: theme.spacing(2),
    },
    countBadge: {
        marginLeft: theme.spacing(1),
        padding: '6px 12px',
        backgroundColor: theme.palette.mode === "dark"
            ? "rgba(255, 255, 255, 0.1)"
            : "rgba(0, 0, 0, 0.08)",
        borderRadius: 8,
        fontSize: '0.875rem',
        fontWeight: 600,
        color: theme.palette.primary.main,
    },
    filterButton: {
        borderRadius: 8,
        padding: '8px 20px',
        fontWeight: 600,
        textTransform: 'none',
        transition: "all 0.2s ease",
        "&:hover": {
            boxShadow: theme.palette.mode === "dark"
                ? "0 4px 12px rgba(0, 0, 0, 0.5)"
                : "0 4px 12px rgba(0, 0, 0, 0.15)",
        },
    },
}));

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ChartDataLabels
);

export const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'top',
            display: false,
        },
        title: {
            display: false,
        },
        datalabels: {
            display: true,
            anchor: 'end',
            align: "end",
            offset: 4,
            color: "#fff",
            textStrokeColor: "#000",
            textStrokeWidth: 2,
            font: {
                size: 14,
                weight: "bold"
            },
        }
    },
    scales: {
        x: {
            grid: {
                display: false,
                drawBorder: false,
            },
            ticks: {
                maxRotation: 45,
                minRotation: 0,
                font: {
                    size: 11,
                },
            },
        },
        y: {
            beginAtZero: true,
            grid: {
                drawBorder: false,
            },
            ticks: {
                padding: 10,
                font: {
                    size: 11,
                },
            },
        },
    },
};

export const ChatsUser = ({ dateStart, dateEnd }) => {
    const classes = useStyles();
    const theme = useTheme();
    const [ticketsData, setTicketsData] = useState({ data: [] });
    const [isLoading, setIsLoading] = useState(false);
    const { user } = useContext(AuthContext);

    const companyId = user.companyId;

    useEffect(() => {
        if (companyId && dateStart && dateEnd) {
            handleGetTicketsInformation();
        }
    }, [companyId, dateStart, dateEnd]);

    const dataCharts = {

        labels: ticketsData && ticketsData?.data.length > 0 && ticketsData?.data.map((item) => item.nome),
        datasets: [
            {
                data: ticketsData?.data.length > 0 && ticketsData?.data.map((item, index) => {
                    return item.quantidade
                }),
                backgroundColor: theme.palette.primary.main,
            },

        ],
    };

    const handleGetTicketsInformation = async () => {
        try {
            setIsLoading(true);
            const { data } = await api.get(`/dashboard/ticketsUsers?initialDate=${dateStart}&finalDate=${dateEnd}&companyId=${companyId}`);
            setTicketsData(data);
        } catch (error) {
            toast.error('Erro ao buscar informações dos tickets');
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
                {i18n.t("dashboard.users.totalCallsUser")}
            </Typography>

            {isLoading ? (
                <div style={{ height: '350px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Typography color="textSecondary" variant="body2">
                        Carregando dados...
                    </Typography>
                </div>
            ) : ticketsData?.data.length === 0 ? (
                <div style={{ height: '350px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: theme.palette.mode === "dark" ? 'rgba(66, 66, 66, 0.2)' : 'rgba(245, 245, 245, 0.5)', borderRadius: 12, border: theme.palette.mode === "dark" ? '1px dashed rgba(255, 255, 255, 0.1)' : '1px dashed rgba(0, 0, 0, 0.1)' }}>
                    <Typography color="textSecondary" variant="body2">
                        Nenhum dado disponível para o período selecionado
                    </Typography>
                </div>
            ) : (
                <div style={{ maxWidth: '100%', height: '350px' }}>
                    <Bar options={options} data={dataCharts} />
                </div>
            )}
        </>
    );
}