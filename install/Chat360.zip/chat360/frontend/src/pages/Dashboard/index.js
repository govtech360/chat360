import React, { useContext, useState, useEffect } from "react";
import { 
  Box, 
  Typography, 
  Card, 
  CardContent, 
  Avatar, 
  Button, 
  IconButton, 
  Paper, 
  Tab, 
  Tabs,
  Divider,
  Tooltip
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import {
  SaveAlt,
  Group,
  FilterList,
  Clear,
  Phone as CallIcon,
  HourglassEmpty as HourglassEmptyIcon,
  CheckCircle as CheckCircleIcon,
  RecordVoiceOver as RecordVoiceOverIcon,
  GroupAdd as GroupAddIcon,
} from "@material-ui/icons";
import * as XLSX from 'xlsx';
import { toast } from "react-toastify";
import { isArray, isEmpty } from "lodash";
import moment from "moment";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";
import TableAttendantsStatus from "../../components/Dashboard/TableAttendantsStatus";
import { AuthContext } from "../../context/Auth/AuthContext";
import useDashboard from "../../hooks/useDashboard";
import useContacts from "../../hooks/useContacts";
import useMessages from "../../hooks/useMessages";
import { ChatsUser } from "./ChartsUser";
import ChartDonut from "./ChartDonut";
import Filters from "./Filters";
import { ChartsDate } from "./ChartsDate";
import ForbiddenPage from "../../components/ForbiddenPage";
import { i18n } from "../../translate/i18n";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
  mainPaper: {
    width: "100%",
    borderRadius: 20,
    overflow: "hidden",
    boxShadow: theme.palette.mode === "dark"
      ? "0 8px 32px rgba(0, 0, 0, 0.6)"
      : "0 8px 32px rgba(0, 0, 0, 0.15)",
    marginBottom: theme.spacing(2),
  },
  filterPaper: {
    padding: theme.spacing(2),
    borderRadius: 20,
    marginBottom: theme.spacing(2),
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
  },
  tabsPaper: {
    borderRadius: 20,
    overflow: "hidden",
    marginBottom: theme.spacing(2),
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
  },
  contentPaper: {
    padding: theme.spacing(3),
    borderRadius: 20,
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
    marginBottom: theme.spacing(2),
  },
  statCard: {
    height: "100%",
    borderRadius: 16,
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
    transition: "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out",
    "&:hover": {
      transform: "translateY(-4px)",
      boxShadow: theme.palette.mode === "dark"
        ? "0 8px 32px rgba(0, 0, 0, 0.6)"
        : "0 8px 32px rgba(0, 0, 0, 0.15)",
    },
  },
  statCardContent: {
    padding: theme.spacing(2.5),
  },
  statTitle: {
    fontWeight: 600,
    fontSize: "0.75rem",
    color: theme.palette.text.secondary,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  statValue: {
    fontWeight: "bold",
    fontSize: "1.75rem",
    color: theme.palette.text.primary,
    marginTop: theme.spacing(0.5),
  },
  statAvatar: {
    width: 56,
    height: 56,
  },
  actionButton: {
    borderRadius: 8,
    padding: "8px 20px",
    textTransform: "none",
    fontWeight: 600,
    boxShadow: "none",
    "&:hover": {
      boxShadow: theme.palette.mode === "dark"
        ? "0 4px 12px rgba(0, 0, 0, 0.5)"
        : "0 4px 12px rgba(0, 0, 0, 0.15)",
    },
  },
  npsCard: {
    borderRadius: 16,
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
    backgroundColor: theme.palette.background.paper,
    height: "100%",
    display: "flex",
    flexDirection: "column",
    transition: "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out",
    "&:hover": {
      transform: "translateY(-4px)",
      boxShadow: theme.palette.mode === "dark"
        ? "0 8px 32px rgba(0, 0, 0, 0.6)"
        : "0 8px 32px rgba(0, 0, 0, 0.15)",
    },
  },
  npsCardContent: {
    padding: theme.spacing(2),
    flex: 1,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  summaryBox: {
    textAlign: "center",
    padding: theme.spacing(2),
  },
  tabs: {
    borderBottom: `1px solid ${theme.palette.divider}`,
    "& .MuiTab-root": {
      textTransform: "none",
      fontWeight: 600,
      fontSize: "0.95rem",
      minHeight: 56,
      color: theme.palette.text.secondary,
      transition: "all 0.2s ease",
      "&:hover": {
        color: theme.palette.primary.main,
        backgroundColor: theme.palette.mode === "dark"
          ? "rgba(255, 255, 255, 0.05)"
          : "rgba(0, 0, 0, 0.02)",
      },
      "&.Mui-selected": {
        color: theme.palette.primary.main,
        fontWeight: 700,
      },
    },
    "& .MuiTabs-indicator": {
      height: 3,
      borderRadius: "3px 3px 0 0",
      backgroundColor: theme.palette.primary.main,
    },
  },
}));

const Dashboard = () => {
  const classes = useStyles();
  const [counters, setCounters] = useState({});
  const [attendants, setAttendants] = useState([]);
  const [showFilter, setShowFilter] = useState(true);
  const [dateStartTicket, setDateStartTicket] = useState(moment().startOf('month').format("YYYY-MM-DD"));
  const [dateEndTicket, setDateEndTicket] = useState(moment().format("YYYY-MM-DD"));
  const [queueTicket, setQueueTicket] = useState(false);
  const [fetchDataFilter, setFetchDataFilter] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  
  const { find } = useDashboard();
  const { user } = useContext(AuthContext);

  let newDate = new Date();
  let date = newDate.getDate();
  let month = newDate.getMonth() + 1;
  let year = newDate.getFullYear();
  let nowIni = `${year}-${month < 10 ? `0${month}` : `${month}`}-01`;
  let now = `${year}-${month < 10 ? `0${month}` : `${month}`}-${date < 10 ? `0${date}` : `${date}`}`;

  useEffect(() => {
    async function firstLoad() {
      await fetchData();
    }
    setTimeout(() => {
      firstLoad();
    }, 1000);
  }, [fetchDataFilter]);

  async function fetchData() {
    setLoading(true);
    let params = {};
    if (!isEmpty(dateStartTicket) && moment(dateStartTicket).isValid()) {
      params = { ...params, date_from: moment(dateStartTicket).format("YYYY-MM-DD") };
    }
    if (!isEmpty(dateEndTicket) && moment(dateEndTicket).isValid()) {
      params = { ...params, date_to: moment(dateEndTicket).format("YYYY-MM-DD") };
    }
    if (Object.keys(params).length === 0) {
      toast.error("Parametrize o filtro");
      setLoading(false);
      return;
    }
    const data = await find(params);
    setCounters(data.counters);
    if (isArray(data.attendants)) {
      setAttendants(data.attendants);
    } else {
      setAttendants([]);
    }
    setLoading(false);
  }

  const exportarGridParaExcel = () => {
    const ws = XLSX.utils.table_to_sheet(document.getElementById('grid-attendants'));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'RelatorioDeAtendentes');
    XLSX.writeFile(wb, 'relatorio-de-atendentes.xlsx');
  };

  function formatTime(minutes) {
    return moment().startOf("day").add(minutes, "minutes").format("HH[h] mm[m]");
  }

  const GetUsers = () => {
    let userOnline = 0;
    attendants.forEach(user => {
      if (user.online === true) {
        userOnline = userOnline + 1;
      }
    });
    return userOnline;
  };

  const GetContacts = (all) => {
    let props = all ? {} : { dateStart: dateStartTicket, dateEnd: dateEndTicket };
    const { count } = useContacts(props);
    return count;
  };

  const GetMessages = (all, fromMe) => {
    let props = all
      ? { fromMe }
      : { fromMe, dateStart: dateStartTicket, dateEnd: dateEndTicket };
    const { count } = useMessages(props);
    return count;
  };

  function toggleShowFilter() {
    setShowFilter(!showFilter);
  }

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  if (user.profile === "user" && user.showDashboard === "disabled") {
    return <ForbiddenPage />;
  }

  const getCardColor = (index) => {
    const colors = [
      "#3498db", // blue
      "#9b59b6", // purple
      "#2ecc71", // green
      "#e74c3c", // red
      "#f39c12", // orange
      "#1abc9c", // teal
    ];
    return colors[index % colors.length];
  };

  const statCards = [
    {
      title: i18n.t("dashboard.cards.inAttendance"),
      value: counters.supportHappening || 0,
      icon: <CallIcon />,
      colorIndex: 0
    },
    {
      title: i18n.t("dashboard.cards.waiting"),
      value: counters.supportPending || 0,
      icon: <HourglassEmptyIcon />,
      colorIndex: 1
    },
    {
      title: i18n.t("dashboard.cards.finalized"),
      value: counters.supportFinished || 0,
      icon: <CheckCircleIcon />,
      colorIndex: 2
    },
    {
      title: i18n.t("dashboard.cards.groups"),
      value: counters.supportGroups || 0,
      icon: <Group />,
      colorIndex: 3
    },
    {
      title: i18n.t("dashboard.cards.activeAttendants"),
      value: `${GetUsers() || 0}/${attendants.length || 0}`,
      icon: <RecordVoiceOverIcon />,
      colorIndex: 4
    },
    {
      title: i18n.t("dashboard.cards.newContacts"),
      value: counters.leads || 0,
      icon: <GroupAddIcon />,
      colorIndex: 5
    }
  ];

  return (
    <MainContainer className={classes.root}>
      <MainHeader>
        <Title>{i18n.t("dashboard.title") || "Dashboard"}</Title>
        <MainHeaderButtonsWrapper>
          <Tooltip title={showFilter ? "Ocultar Filtros" : "Exibir Filtros"}>
            <Button
              variant="contained"
              color="primary"
              onClick={toggleShowFilter}
              startIcon={showFilter ? <Clear /> : <FilterList />}
              className={classes.actionButton}
            >
              {showFilter ? "Ocultar Filtros" : "Filtros"}
            </Button>
          </Tooltip>
        </MainHeaderButtonsWrapper>
      </MainHeader>

      <Box>
        {/* Filters Section */}
        {showFilter && (
          <Paper className={classes.filterPaper} elevation={0}>
            <Filters
              classes={classes}
              setDateStartTicket={setDateStartTicket}
              setDateEndTicket={setDateEndTicket}
              dateStartTicket={dateStartTicket}
              dateEndTicket={dateEndTicket}
              setQueueTicket={setQueueTicket}
              queueTicket={queueTicket}
              fetchData={setFetchDataFilter}
            />
          </Paper>
        )}

        {/* Statistics Cards */}
        <Grid container spacing={2} style={{ marginBottom: 16 }}>
          {statCards.map((card, index) => (
            <Grid item xs={12} sm={6} md={4} lg={2} key={index}>
              <Card className={classes.statCard} elevation={0}>
                <CardContent className={classes.statCardContent}>
                  <Box
                    display="flex"
                    flexDirection="row"
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Box>
                      <Typography className={classes.statTitle}>
                        {card.title}
                      </Typography>
                      <Typography className={classes.statValue}>
                        {card.value}
                      </Typography>
                    </Box>
                    <Avatar 
                      className={classes.statAvatar}
                      style={{ 
                        backgroundColor: getCardColor(card.colorIndex)
                      }}
                    >
                      {card.icon}
                    </Avatar>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Tabs Navigation */}
        <Paper className={classes.tabsPaper} elevation={0}>
          <Tabs 
            value={activeTab} 
            onChange={handleTabChange}
            variant="fullWidth"
            indicatorColor="primary"
            textColor="primary"
            className={classes.tabs}
          >
            <Tab label={i18n.t("dashboard.tabs.performance")} />
            <Tab label={i18n.t("dashboard.tabs.assessments")} />
            <Tab label={i18n.t("dashboard.tabs.attendants")} />
          </Tabs>
        </Paper>

      {/* Tab Panels */}
      {/* Performance Tab */}
      {activeTab === 0 && (
        <Paper className={classes.contentPaper} elevation={0}>
          <Typography variant="h6" style={{ fontWeight: "bold" }} gutterBottom>
            {i18n.t("dashboard.charts.performance")}
          </Typography>
          <Divider style={{ marginBottom: 16 }} />
          <ChartsDate dateStart={dateStartTicket} dateEnd={dateEndTicket} />
        </Paper>
      )}

      {/* Assessments Tab - NPS Data */}
      {activeTab === 1 && (
        <Paper className={classes.contentPaper} elevation={0}>
          <Box style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <Typography variant="h6" style={{ fontWeight: "bold" }}>
              {i18n.t("dashboard.tabs.assessments")}
            </Typography>
          </Box>
          <Divider style={{ marginBottom: 24 }} />
          
          <Grid container spacing={2}>
            {/* Main NPS Score */}
            <Grid item xs={12} sm={6} md={3}>
              <Card className={classes.npsCard} elevation={0}>
                <CardContent className={classes.npsCardContent}>
                  <ChartDonut
                    data={[
                      `{'name': 'Promotores', 'value': ${counters.npsPromotersPerc || 100}}`,
                      `{'name': 'Detratores', 'value': ${counters.npsDetractorsPerc || 0}}`,
                      `{'name': 'Neutros', 'value': ${counters.npsPassivePerc || 0}}`
                    ]}
                    value={counters.npsScore || 0}
                    title="Score"
                    color={(parseInt(counters.npsPromotersPerc || 0) + parseInt(counters.npsDetractorsPerc || 0) + parseInt(counters.npsPassivePerc || 0)) === 0 ? ["#918F94"] : ["#2ecc71", "#e74c3c", "#f39c12"]}
                  />
                </CardContent>
              </Card>
            </Grid>

            {/* Promoters */}
            <Grid item xs={12} sm={6} md={3}>
              <Card className={classes.npsCard} elevation={0}>
                <CardContent className={classes.npsCardContent}>
                  <ChartDonut
                    title={i18n.t("dashboard.assessments.prosecutors")}
                    value={counters.npsPromotersPerc || 0}
                    data={[`{'name': 'Promotores', 'value': 100}`]}
                    color={["#2ecc71"]}
                  />
                </CardContent>
              </Card>
            </Grid>

            {/* Neutral */}
            <Grid item xs={12} sm={6} md={3}>
              <Card className={classes.npsCard} elevation={0}>
                <CardContent className={classes.npsCardContent}>
                  <ChartDonut
                    data={[`{'name': 'Neutros', 'value': 100}`]}
                    title={i18n.t("dashboard.assessments.neutral")}
                    value={counters.npsPassivePerc || 0}
                    color={["#f39c12"]}
                  />
                </CardContent>
              </Card>
            </Grid>

            {/* Detractors */}
            <Grid item xs={12} sm={6} md={3}>
              <Card className={classes.npsCard} elevation={0}>
                <CardContent className={classes.npsCardContent}>
                  <ChartDonut
                    data={[`{'name': 'Detratores', 'value': 100}`]}
                    title={i18n.t("dashboard.assessments.detractors")}
                    value={counters.npsDetractorsPerc || 0}
                    color={["#e74c3c"]}
                  />
                </CardContent>
              </Card>
            </Grid>

            {/* Assessment Summary */}
            <Grid item xs={12}>
              <Card className={classes.npsCard} elevation={0}>
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={4}>
                      <Box className={classes.summaryBox}>
                        <Typography variant="body2" color="textSecondary" gutterBottom>
                          {i18n.t("dashboard.assessments.totalCalls")}
                        </Typography>
                        <Typography variant="h4" style={{ fontWeight: "bold" }} color="primary">
                          {counters.tickets || 0}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <Box className={classes.summaryBox}>
                        <Typography variant="body2" color="textSecondary" gutterBottom>
                          {i18n.t("dashboard.assessments.ratedCalls")}
                        </Typography>
                        <Typography variant="h4" style={{ fontWeight: "bold" }} color="primary">
                          {counters.withRating || 0}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <Box className={classes.summaryBox}>
                        <Typography variant="body2" color="textSecondary" gutterBottom>
                          {i18n.t("dashboard.assessments.evaluationIndex")}
                        </Typography>
                        <Typography variant="h4" style={{ fontWeight: "bold" }} color="primary">
                          {Number(counters.percRating / 100 || 0).toLocaleString(undefined, { style: 'percent' })}
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Paper>
      )}

      {/* Attendants Tab */}
      {activeTab === 2 && (
        <Paper className={classes.contentPaper} elevation={0}>
          <Box style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <Typography variant="h6" style={{ fontWeight: "bold" }}>
              {i18n.t("dashboard.tabs.attendants")}
            </Typography>
            
            <Tooltip title="Exportar para Excel">
              <IconButton 
                onClick={exportarGridParaExcel} 
                color="primary"
                size="small"
                style={{ 
                  backgroundColor: "rgba(53, 152, 220, 0.1)",
                }}
              >
                <SaveAlt />
              </IconButton>
            </Tooltip>
          </Box>
          <Divider style={{ marginBottom: 24 }} />

          <div id="grid-attendants">
            {attendants.length > 0 && (
              <TableAttendantsStatus 
                attendants={attendants} 
                loading={loading} 
              />
            )}
          </div>

          <Box style={{ marginTop: 24 }}>
            <Typography variant="subtitle1" style={{ fontWeight: "bold" }} gutterBottom>
              {i18n.t("dashboard.charts.userPerformance")}
            </Typography>
            <ChatsUser dateStart={dateStartTicket} dateEnd={dateEndTicket} />
          </Box>
        </Paper>
      )}
      </Box>
    </MainContainer>
  );
};

export default Dashboard;