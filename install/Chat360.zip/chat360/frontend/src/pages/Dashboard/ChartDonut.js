import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { useTheme } from '@material-ui/core/styles';
import { Box } from '@material-ui/core';

const DonutChart = (props) => {
  const {title, value, data , color} = props;
  const theme = useTheme();
  const isDarkMode = theme.palette.type === 'dark';
  
  const data1 = JSON.parse(`[${String(data).replace(/'/g, '"')}]`);
  
  const COLORS = [color].length === 1 ? color : [JSON.stringify(color)];
  
  // Cores para textos baseadas no tema
  const textColor = isDarkMode ? '#ffffff' : '#000000';
  const subtitleColor = isDarkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';

  // Responsividade do gráfico
  const isMobile = window.innerWidth < 600;
  const isTablet = window.innerWidth >= 600 && window.innerWidth < 960;
  const outerRadius = isMobile ? 55 : isTablet ? 65 : 70;
  const innerRadius = isMobile ? 40 : isTablet ? 47 : 50;

  return (
    <Box 
      style={{ 
        width: '100%', 
        height: isMobile ? '180px' : isTablet ? '200px' : '220px', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        padding: isMobile ? '4px' : '8px'
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data1}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            outerRadius={outerRadius}
            innerRadius={innerRadius}
            labelLine={false}
            strokeWidth={0}
          >
            {data1.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}            
          </Pie>
          <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle">
            <tspan 
              x="50%" 
              dy="-0.8em" 
              style={{
                fontSize: isMobile ? '0.7rem' : '0.8rem',
                fontWeight: 600,
                fill: subtitleColor,
              }}
            >
              {title}
            </tspan>
            <tspan 
              x="50%" 
              dy="1.5em" 
              style={{
                fontSize: isMobile ? '1.25rem' : isTablet ? '1.4rem' : '1.5rem',
                fontWeight: 'bold',
                fill: textColor,
              }}
            >
              {value}%
            </tspan>
          </text>
        </PieChart>
      </ResponsiveContainer>
    </Box>
  );
};
export default DonutChart;
