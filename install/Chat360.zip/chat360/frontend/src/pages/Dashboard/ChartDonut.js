import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { useTheme } from '@material-ui/core/styles';
import { Box } from '@material-ui/core';

const DonutChart = (props) => {
  const {title, value, data , color} = props;
  const theme = useTheme();
  const isDarkMode = theme.palette.type === 'dark';
  
  const data1 = JSON.parse(`[${String(data).replace(/'/g, '"')}]`);
  
  const COLORS = [color].length === 1 ? color : [JSON.stringify(color)];
  
  // Cores para textos baseadas no tema
  const textColor = isDarkMode ? '#ffffff' : '#000000';
  const subtitleColor = isDarkMode ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.6)';

  return (
    <Box 
      style={{ 
        width: '100%', 
        height: '220px', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        padding: '8px'
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data1}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            outerRadius={70}
            innerRadius={50}
            labelLine={false}
            strokeWidth={0}
          >
            {data1.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}            
          </Pie>
          <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle">
            <tspan 
              x="50%" 
              dy="-0.8em" 
              style={{
                fontSize: '0.8rem',
                fontWeight: 600,
                fill: subtitleColor,
              }}
            >
              {title}
            </tspan>
            <tspan 
              x="50%" 
              dy="1.5em" 
              style={{
                fontSize: '1.5rem',
                fontWeight: 'bold',
                fill: textColor,
              }}
            >
              {value}%
            </tspan>
          </text>
        </PieChart>
      </ResponsiveContainer>
    </Box>
  );
};
export default DonutChart;
