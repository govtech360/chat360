import React, { useEffect, useReducer, useState, useContext } from "react";

import {
  Button,
  IconButton,
  makeStyles,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  Tooltip,
  Box,
} from "@material-ui/core";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import TableRowSkeleton from "../../components/TableRowSkeleton";
import Title from "../../components/Title";
import { i18n } from "../../translate/i18n";
import toastError from "../../errors/toastError";
import api from "../../services/api";
import { 
  DeleteOutline, 
  Edit,
  Fingerprint,
  Label,
  Palette,
  FormatListNumbered,
  Message,
  Settings as SettingsIcon
} from "@material-ui/icons";
import QueueModal from "../../components/QueueModal";
import { toast } from "react-toastify";
import ConfirmationModal from "../../components/ConfirmationModal";
// import { SocketContext } from "../../context/Socket/SocketContext";
import { AuthContext } from "../../context/Auth/AuthContext";
import ForbiddenPage from "../../components/ForbiddenPage";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
  mainPaper: {
    width: "100%",
    borderRadius: 20,
    overflow: "hidden",
    boxShadow: theme.palette.mode === "dark" 
      ? "0 4px 20px rgba(0, 0, 0, 0.5)" 
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
  },
  tableWrapper: {
    overflowX: "auto",
    overflowY: "auto",
    maxHeight: "calc(100vh - 250px)",
    ...theme.scrollbarStyles,
  },
  table: {
    minWidth: 1000,
    "& .MuiTableHead-root": {
      backgroundColor: theme.palette.background.default,
      position: "sticky",
      top: 0,
      zIndex: 10,
    },
    "& .MuiTableCell-head": {
      fontWeight: 700,
      fontSize: "0.85rem",
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      borderBottom: `2px solid ${theme.palette.divider}`,
      padding: theme.spacing(2),
      whiteSpace: "nowrap",
    },
    "& tbody tr": {
      borderBottom: `1px solid ${theme.palette.divider}`,
      transition: "background-color 0.2s ease",
      "&:hover": {
        backgroundColor: theme.palette.mode === "dark" 
          ? "rgba(255, 255, 255, 0.05)" 
          : "rgba(0, 0, 0, 0.02)",
      },
    },
    "& tbody td": {
      padding: theme.spacing(2),
      borderBottom: "none",
      color: theme.palette.text.primary,
    },
  },
  actionButton: {
    borderRadius: 8,
    padding: "8px 20px",
    textTransform: "none",
    fontWeight: 600,
    boxShadow: "none",
    "&:hover": {
      boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
    },
  },
  headerIcon: {
    marginRight: theme.spacing(1),
    fontSize: "1.2rem",
  },
  customTableCell: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  colorBox: {
    borderRadius: 4,
    boxShadow: theme.palette.mode === "dark"
      ? "0 0 0 1px rgba(255, 255, 255, 0.1)"
      : "0 0 0 1px rgba(0, 0, 0, 0.1)",
  },
}));

const reducer = (state, action) => {
  if (action.type === "LOAD_QUEUES") {
    const queues = action.payload;
    const newQueues = [];

    queues.forEach((queue) => {
      const queueIndex = state.findIndex((q) => q.id === queue.id);
      if (queueIndex !== -1) {
        state[queueIndex] = queue;
      } else {
        newQueues.push(queue);
      }
    });

    return [...state, ...newQueues];
  }

  if (action.type === "UPDATE_QUEUES") {
    const queue = action.payload;
    const queueIndex = state.findIndex((u) => u.id === queue.id);

    if (queueIndex !== -1) {
      state[queueIndex] = queue;
      return [...state];
    } else {
      return [queue, ...state];
    }
  }

  if (action.type === "DELETE_QUEUE") {
    const queueId = action.payload;
    const queueIndex = state.findIndex((q) => q.id === queueId);
    if (queueIndex !== -1) {
      state.splice(queueIndex, 1);
    }
    return [...state];
  }

  if (action.type === "RESET") {
    return [];
  }
};

const Queues = () => {
  const classes = useStyles();

  const [queues, dispatch] = useReducer(reducer, []);
  const [loading, setLoading] = useState(false);

  const [queueModalOpen, setQueueModalOpen] = useState(false);
  const [selectedQueue, setSelectedQueue] = useState(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  //   const socketManager = useContext(SocketContext);
  const { user, socket } = useContext(AuthContext);
  const companyId = user.companyId;


  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const { data } = await api.get("/queue");
        dispatch({ type: "LOAD_QUEUES", payload: data });

        setLoading(false);
      } catch (err) {
        toastError(err);
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {

    const onQueueEvent = (data) => {
      if (data.action === "update" || data.action === "create") {
        dispatch({ type: "UPDATE_QUEUES", payload: data.queue });
      }

      if (data.action === "delete") {
        dispatch({ type: "DELETE_QUEUE", payload: data.queueId });
      }
    };
    socket.on(`company-${companyId}-queue`, onQueueEvent);

    return () => {
      socket.off(`company-${companyId}-queue`, onQueueEvent);
    };
  }, [socket, companyId]);

  const handleOpenQueueModal = () => {
    setQueueModalOpen(true);
    setSelectedQueue(null);
  };

  const handleCloseQueueModal = () => {
    setQueueModalOpen(false);
    setSelectedQueue(null);
  };

  const handleEditQueue = (queue) => {
    setSelectedQueue(queue);
    setQueueModalOpen(true);
  };

  const handleCloseConfirmationModal = () => {
    setConfirmModalOpen(false);
    setSelectedQueue(null);
  };

  const handleDeleteQueue = async (queueId) => {
    try {
      await api.delete(`/queue/${queueId}`);
      toast.success(i18n.t("Queue deleted successfully!"));
    } catch (err) {
      toastError(err);
    }
    setSelectedQueue(null);
  };

  return (
    <MainContainer className={classes.root}>
      <ConfirmationModal
        title={
          selectedQueue &&
          `${i18n.t("queues.confirmationModal.deleteTitle")} ${selectedQueue.name
          }?`
        }
        open={confirmModalOpen}
        onClose={handleCloseConfirmationModal}
        onConfirm={() => handleDeleteQueue(selectedQueue.id)}
      >
        {i18n.t("queues.confirmationModal.deleteMessage")}
      </ConfirmationModal>
      <QueueModal
        open={queueModalOpen}
        onClose={handleCloseQueueModal}
        queueId={selectedQueue?.id}
        onEdit={(res) => {
          if (res) {
            setTimeout(() => {
              handleEditQueue(res)
            }, 500)
          }
        }}
      />
      {user.profile === "user" ?
        <ForbiddenPage />
        :
        <>
          <MainHeader>
            <Title>{i18n.t("queues.title")} ({queues.length})</Title>
            <MainHeaderButtonsWrapper>
              <Button
                variant="contained"
                color="primary"
                onClick={handleOpenQueueModal}
                className={classes.actionButton}
              >
                {i18n.t("queues.buttons.add")}
              </Button>
            </MainHeaderButtonsWrapper>
          </MainHeader>
          <Paper className={classes.mainPaper}>
            <div className={classes.tableWrapper}>
              <Table className={classes.table} size="small">
                <TableHead>
                  <TableRow>
                    <TableCell align="center">
                      <Tooltip title="ID da fila">
                        <Box style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <Fingerprint className={classes.headerIcon} />
                          <span>{i18n.t("queues.table.ID")}</span>
                        </Box>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Nome da fila">
                        <Box style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <Label className={classes.headerIcon} />
                          <span>{i18n.t("queues.table.name")}</span>
                        </Box>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Cor identificadora da fila">
                        <Box style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <Palette className={classes.headerIcon} />
                          <span>{i18n.t("queues.table.color")}</span>
                        </Box>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Ordem de apresentação da fila">
                        <Box style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <FormatListNumbered className={classes.headerIcon} />
                          <span>{i18n.t("queues.table.orderQueue")}</span>
                        </Box>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Mensagem de saudação da fila">
                        <Box style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <Message className={classes.headerIcon} />
                          <span>{i18n.t("queues.table.greeting")}</span>
                        </Box>
                      </Tooltip>
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="Ações disponíveis">
                        <Box style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <SettingsIcon className={classes.headerIcon} />
                          <span>{i18n.t("queues.table.actions")}</span>
                        </Box>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <>
                    {queues.map((queue) => (
                      <TableRow key={queue.id}>
                        <TableCell align="center">{queue.id}</TableCell>
                        <TableCell align="center">{queue.name}</TableCell>
                        <TableCell align="center">
                          <div className={classes.customTableCell}>
                            <span
                              className={classes.colorBox}
                              style={{
                                backgroundColor: queue.color,
                                width: 60,
                                height: 20,
                                display: "block",
                              }}
                            />
                          </div>
                        </TableCell>
                        <TableCell align="center">
                          <div className={classes.customTableCell}>
                            <Typography
                              style={{ width: 300, align: "center" }}
                              noWrap
                              variant="body2"
                            >
                              {queue.orderQueue}
                            </Typography>
                          </div>
                        </TableCell>
                        <TableCell align="center">
                          <div className={classes.customTableCell}>
                            <Typography
                              style={{ width: 300, align: "center" }}
                              noWrap
                              variant="body2"
                            >
                              {queue.greetingMessage}
                            </Typography>
                          </div>
                        </TableCell>
                        <TableCell align="center">
                          <IconButton
                            size="small"
                            onClick={() => handleEditQueue(queue)}
                          >
                            <Edit />
                          </IconButton>

                          <IconButton
                            size="small"
                            onClick={() => {
                              setSelectedQueue(queue);
                              setConfirmModalOpen(true);
                            }}
                          >
                            <DeleteOutline />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))}
                    {loading && <TableRowSkeleton columns={6} />}
                  </>
                </TableBody>
              </Table>
            </div>
          </Paper>
        </>}
    </MainContainer>
  );
};

export default Queues;
