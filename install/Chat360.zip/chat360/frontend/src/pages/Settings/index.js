import React, { useState, useEffect, useContext } from "react";

import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import Select from "@material-ui/core/Select";
import { toast } from "react-toastify";

import api from "../../services/api";
import { i18n } from "../../translate/i18n.js";
import toastError from "../../errors/toastError";
import ForbiddenPage from "../../components/ForbiddenPage";
// import { SocketContext } from "../../context/Socket/SocketContext";
import { AuthContext } from "../../context/Auth/AuthContext";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: theme.spacing(3),
    minHeight: "calc(100vh - 64px)",
    backgroundColor: theme.palette.mode === "dark" ? theme.palette.background.default : "#f8fafc",
  },
  container: {
    maxWidth: "800px",
    width: "100%",
  },
  title: {
    fontSize: "1.8rem",
    fontWeight: 700,
    color: theme.palette.mode === "dark" ? "#ffffff" : "#1e293b",
    marginBottom: theme.spacing(3),
    textAlign: "center",
  },
  paper: {
    padding: theme.spacing(3),
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: "16px",
    backgroundColor: theme.palette.mode === "dark" ? theme.palette.background.paper : "#ffffff",
    boxShadow: theme.palette.mode === "dark" 
      ? "0 4px 20px rgba(0, 0, 0, 0.5)" 
      : "0 2px 12px rgba(0, 0, 0, 0.08)",
    transition: "all 0.3s ease",
    marginBottom: theme.spacing(2),
    "&:hover": {
      boxShadow: theme.palette.mode === "dark"
        ? "0 6px 24px rgba(0, 0, 0, 0.6)"
        : "0 4px 16px rgba(0, 0, 0, 0.12)",
      transform: "translateY(-2px)",
    },
  },
  settingLabel: {
    fontSize: "1rem",
    fontWeight: 600,
    color: theme.palette.text.primary,
  },
  settingOption: {
    minWidth: "200px",
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
      backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.02)",
      "&:hover": {
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.08)" : "rgba(0, 0, 0, 0.04)",
      },
      "&.Mui-focused": {
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.03)",
        "& fieldset": {
          borderColor: theme.palette.primary.main,
          borderWidth: "2px",
        },
      },
    },
    "& .MuiSelect-select": {
      color: theme.palette.text.primary,
      fontSize: "0.9rem",
      padding: "12px 14px",
    },
    "& .MuiOutlinedInput-notchedOutline": {
      borderColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.12)",
    },
  },
  margin: {
    margin: theme.spacing(2, 0),
  },
}));

const Settings = () => {
  const classes = useStyles();
  //   const socketManager = useContext(SocketContext);
  const { user, socket } = useContext(AuthContext);

  const [settings, setSettings] = useState([]);

  useEffect(() => {
    const fetchSession = async () => {
      try {
        const { data } = await api.get("/settings");
        setSettings(data);
      } catch (err) {
        toastError(err);
      }
    };
    fetchSession();
  }, []);

  useEffect(() => {
    const companyId = user.companyId;
    // const socket = socketManager.GetSocket();

    const onSettingsEvent = (data) => {
      if (data.action === "update") {
        setSettings((prevState) => {
          const aux = [...prevState];
          const settingIndex = aux.findIndex((s) => s.key === data.setting.key);
          aux[settingIndex].value = data.setting.value;
          return aux;
        });
      }
    };
    socket.on(`company-${companyId}-settings`, onSettingsEvent);

    return () => {
      socket.off(`company-${companyId}-settings`, onSettingsEvent);
    };
  }, [socket]);

  const handleChangeSetting = async (e) => {
    const selectedValue = e.target.value;
    const settingKey = e.target.name;

    try {
      await api.put(`/settings/${settingKey}`, {
        value: selectedValue,
      });
      toast.success(i18n.t("settings.success"));
    } catch (err) {
      toastError(err);
    }
  };

  const getSettingValue = (key) => {
    const { value } = settings.find((s) => s.key === key);
    return value;
  };

  return (
    <div className={classes.root}>
      {user.profile === "user" ?
        <ForbiddenPage />
        :
        <>
          <Container className={classes.container} maxWidth="md">
            <Typography className={classes.title}>
              {i18n.t("settings.title")}
            </Typography>
            <Paper className={classes.paper} elevation={0}>
              <Typography className={classes.settingLabel}>
                {i18n.t("settings.settings.userCreation.name")}
              </Typography>
              <Select
                margin="dense"
                variant="outlined"
                native
                id="userCreation-setting"
                name="userCreation"
                value={
                  settings && settings.length > 0 && getSettingValue("userCreation")
                }
                className={classes.settingOption}
                onChange={handleChangeSetting}
              >
                <option value="enabled">
                  {i18n.t("settings.settings.userCreation.options.enabled")}
                </option>
                <option value="disabled">
                  {i18n.t("settings.settings.userCreation.options.disabled")}
                </option>
              </Select>
            </Paper>
          </Container>
        </>}
    </div>
  );
};

export default Settings;
