import React, { useState, useEffect, useContext } from "react";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";
import { makeStyles, Paper, Tabs, Tab } from "@material-ui/core";

import TabPanel from "../../components/TabPanel";

import SchedulesForm from "../../components/SchedulesForm";
import CompaniesManager from "../../components/CompaniesManager";
import PlansManager from "../../components/PlansManager";
import HelpsManager from "../../components/HelpsManager";
import Options from "../../components/Settings/Options";
import Whitelabel from "../../components/Settings/Whitelabel";

import { i18n } from "../../translate/i18n.js";
import { toast } from "react-toastify";

import useCompanies from "../../hooks/useCompanies";
import { AuthContext } from "../../context/Auth/AuthContext";

import OnlyForSuperUser from "../../components/OnlyForSuperUser";
import useCompanySettings from "../../hooks/useSettings/companySettings";
import useSettings from "../../hooks/useSettings";
import ForbiddenPage from "../../components/ForbiddenPage/index.js";

const useStyles = makeStyles((theme) => ({
  root: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    width: "100%",
    maxWidth: "100%",
  },
  mainPaper: {
    flex: 1,
    borderRadius: 20,
    display: "flex",
    flexDirection: "column",
    width: "100%",
    maxWidth: "100%",
    minWidth: 0,
    boxSizing: "border-box",
    height: "calc(100vh - 200px)",
    boxShadow: theme.palette.mode === "dark" 
      ? "0 4px 20px rgba(0, 0, 0, 0.5), 0 2px 12px rgba(0, 0, 0, 0.3)" 
      : "0 4px 20px rgba(0, 0, 0, 0.08), 0 2px 12px rgba(0, 0, 0, 0.04)",
    [theme.breakpoints.down('md')]: {
      height: "calc(100vh - 150px)",
    },
    [theme.breakpoints.down('sm')]: {
      height: "calc(100vh - 120px)",
      borderRadius: 12,
    },
  },
  tab: {
    backgroundColor: theme.palette.background.default,
    borderRadius: "20px 20px 0 0",
    width: "100%",
    maxWidth: "100%",
    boxSizing: "border-box",
    "& .MuiTabs-scrollButtons": {
      [theme.breakpoints.down('sm')]: {
        display: "flex",
      },
    },
    "& .MuiTab-root": {
      minWidth: "auto",
      [theme.breakpoints.down('sm')]: {
        fontSize: "0.75rem",
        padding: "6px 8px",
        minWidth: "80px",
      },
    },
    [theme.breakpoints.down('sm')]: {
      borderRadius: "12px 12px 0 0",
    },
  },
  paper: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    width: 0,
    minWidth: "100%",
    overflowX: "auto",
    overflowY: "auto",
    padding: theme.spacing(2),
    boxSizing: "border-box",
    position: "relative",
    WebkitOverflowScrolling: "touch",
    borderRadius: "0 0 20px 20px",
    // Scrollbar horizontal sempre visível
    "&::-webkit-scrollbar": {
      height: "14px",
      width: "14px",
      backgroundColor: "transparent",
    },
    "&::-webkit-scrollbar-track": {
      background: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.05)",
      borderRadius: "0 0 20px 20px",
      margin: "0 0 2px 0",
    },
    "&::-webkit-scrollbar-track:horizontal": {
      borderRadius: "0 0 20px 20px",
    },
    "&::-webkit-scrollbar-track:vertical": {
      borderRadius: "0 20px 20px 0",
      margin: "0 2px 0 0",
    },
    "&::-webkit-scrollbar-thumb": {
      background: theme.palette.mode === "dark" 
        ? "linear-gradient(180deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.25))" 
        : "linear-gradient(180deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.25))",
      borderRadius: "10px",
      border: `3px solid ${theme.palette.mode === "dark" ? theme.palette.background.paper : "#fff"}`,
      "&:hover": {
        background: theme.palette.mode === "dark" 
          ? "linear-gradient(180deg, rgba(255, 255, 255, 0.4), rgba(255, 255, 255, 0.35))" 
          : "linear-gradient(180deg, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.35))",
      },
      "&:active": {
        background: theme.palette.mode === "dark" 
          ? "rgba(255, 255, 255, 0.5)" 
          : "rgba(0, 0, 0, 0.5)",
      },
    },
    "&::-webkit-scrollbar-corner": {
      background: "transparent",
      borderRadius: "0 0 20px 0",
    },
    // Firefox scrollbar
    scrollbarWidth: "auto",
    scrollbarColor: theme.palette.mode === "dark" 
      ? "rgba(255, 255, 255, 0.3) rgba(255, 255, 255, 0.05)"
      : "rgba(0, 0, 0, 0.3) rgba(0, 0, 0, 0.05)",
    [theme.breakpoints.down('sm')]: {
      padding: theme.spacing(1),
      borderRadius: "0 0 12px 12px",
      "&::-webkit-scrollbar-track": {
        borderRadius: "0 0 12px 12px",
      },
      "&::-webkit-scrollbar-track:horizontal": {
        borderRadius: "0 0 12px 12px",
      },
      "&::-webkit-scrollbar-track:vertical": {
        borderRadius: "0 12px 12px 0",
      },
      "&::-webkit-scrollbar-corner": {
        borderRadius: "0 0 12px 0",
      },
    },
  },
  container: {
    width: "100%",
    maxWidth: "100%",
    boxSizing: "border-box",
  },
  control: {
    padding: theme.spacing(1),
  },
  textfield: {
    width: "100%",
  },
}));

const SettingsCustom = () => {
  const classes = useStyles();
  const [tab, setTab] = useState("options");
  const [schedules, setSchedules] = useState([]);
  const [company, setCompany] = useState({});
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState({});
  const [settings, setSettings] = useState({});
  const [oldSettings, setOldSettings] = useState({});
  const [schedulesEnabled, setSchedulesEnabled] = useState(false);

  const { find, updateSchedules } = useCompanies();

  //novo hook
  const { getAll: getAllSettings } = useCompanySettings();
  const { getAll: getAllSettingsOld } = useSettings();
  const { user, socket } = useContext(AuthContext);

  useEffect(() => {
    async function findData() {
      setLoading(true);
      try {
        const companyId = user.companyId;
        const company = await find(companyId);

        const settingList = await getAllSettings(companyId);

        const settingListOld = await getAllSettingsOld();

        setCompany(company);
        setSchedules(company.schedules);
        setSettings(settingList);
        setOldSettings(settingListOld);

        /*  if (Array.isArray(settingList)) {
           const scheduleType = settingList.find(
             (d) => d.key === "scheduleType"
           );
           if (scheduleType) {
             setSchedulesEnabled(scheduleType.value === "company");
           }
         } */
        setSchedulesEnabled(settingList.scheduleType === "company");
        setCurrentUser(user);
      } catch (e) {
        toast.error(e);
      }
      setLoading(false);
    }
    findData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleTabChange = (event, newValue) => {
    setTab(newValue);
  };

  const handleSubmitSchedules = async (data) => {
    setLoading(true);
    try {
      setSchedules(data);
      await updateSchedules({ id: company.id, schedules: data });
      toast.success("Horários atualizados com sucesso.");
    } catch (e) {
      toast.error(e);
    }
    setLoading(false);
  };

  const isSuper = () => {
    return currentUser.super;
  };

  return (
    <MainContainer className={classes.root}>
      {user.profile === "user" ?
        <ForbiddenPage />
        :
        <>
          <MainHeader>
            <Title>{i18n.t("settings.title")}</Title>
          </MainHeader>
          <Paper className={classes.mainPaper} elevation={1}>
            <Tabs
              value={tab}
              indicatorColor="primary"
              textColor="primary"
              scrollButtons="on"
              variant="scrollable"
              onChange={handleTabChange}
              className={classes.tab}
            >
              <Tab label={i18n.t("settings.tabs.options")} value={"options"} />
              {schedulesEnabled && <Tab label="Horários" value={"schedules"} />}
              {isSuper() ? <Tab label="Empresas" value={"companies"} /> : null}
              {isSuper() ? <Tab label={i18n.t("settings.tabs.plans")} value={"plans"} /> : null}
              {isSuper() ? <Tab label={i18n.t("settings.tabs.helps")} value={"helps"} /> : null}
              {isSuper() ? <Tab label="Whitelabel" value={"whitelabel"} /> : null}
            </Tabs>
            <Paper className={classes.paper} elevation={0}>
              <TabPanel
                className={classes.container}
                value={tab}
                name={"schedules"}
              >
                <SchedulesForm
                  loading={loading}
                  onSubmit={handleSubmitSchedules}
                  initialValues={schedules}
                />
              </TabPanel>
              <OnlyForSuperUser
                user={currentUser}
                yes={() => (
                  <>
                    <TabPanel
                      className={classes.container}
                      value={tab}
                      name={"companies"}
                    >
                      <CompaniesManager />
                    </TabPanel>

                    <TabPanel
                      className={classes.container}
                      value={tab}
                      name={"plans"}
                    >
                      <PlansManager />
                    </TabPanel>

                    <TabPanel
                      className={classes.container}
                      value={tab}
                      name={"helps"}
                    >
                      <HelpsManager />
                    </TabPanel>
                    <TabPanel
                      className={classes.container}
                      value={tab}
                      name={"whitelabel"}
                    >
                      <Whitelabel
                        settings={oldSettings}
                      />
                    </TabPanel>
                  </>
                )}
              />
              <TabPanel className={classes.container} value={tab} name={"options"}>
                <Options
                  settings={settings}
                  oldSettings={oldSettings}
                  user={currentUser}
                  scheduleTypeChanged={(value) =>
                    setSchedulesEnabled(value === "company")
                  }
                />
              </TabPanel>
            </Paper>
          </Paper>
        </>}
    </MainContainer>
  );
};

export default SettingsCustom;
