import React, { useState, useContext, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";

import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';

import SubscriptionModal from "../../components/SubscriptionModal";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";
import MainContainer from "../../components/MainContainer";
import moment from "moment";
import { useDate } from "../../hooks/useDate";

import { AuthContext } from "../../context/Auth/AuthContext";

const useStyles = makeStyles((theme) => ({
  mainContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "flex-start",
    padding: theme.spacing(2),
    minHeight: "calc(100vh - 64px)",
    backgroundColor: theme.palette.mode === "dark" ? theme.palette.background.default : "#f8fafc",
    width: "100%",
    boxSizing: "border-box",
    [theme.breakpoints.down('sm')]: {
      padding: theme.spacing(1),
    },
  },
  mainPaper: {
    padding: theme.spacing(4),
    borderRadius: "16px",
    backgroundColor: theme.palette.mode === "dark" ? theme.palette.background.paper : "#ffffff",
    boxShadow: theme.palette.mode === "dark" 
      ? "0 4px 20px rgba(0, 0, 0, 0.5)" 
      : "0 2px 12px rgba(0, 0, 0, 0.08)",
    maxWidth: "600px",
    width: "100%",
    boxSizing: "border-box",
    [theme.breakpoints.down('sm')]: {
      padding: theme.spacing(2),
    },
  },
  inputField: {
    marginBottom: theme.spacing(2),
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
      backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.02)",
      "&:hover": {
        backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.08)" : "rgba(0, 0, 0, 0.04)",
      },
    },
    "& .MuiInputLabel-outlined": {
      fontSize: "0.9rem",
      color: theme.palette.text.secondary,
    },
    "& .MuiOutlinedInput-input": {
      color: theme.palette.text.primary,
      padding: "12px 14px",
      fontSize: "0.9rem",
    },
    "& .MuiOutlinedInput-notchedOutline": {
      borderColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.12)" : "rgba(0, 0, 0, 0.12)",
    },
  },
  submitBtn: {
    marginTop: theme.spacing(2),
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    padding: "10px 24px",
    fontSize: "0.95rem",
    fontWeight: 600,
    borderRadius: "8px",
    textTransform: "none",
    boxShadow: "none",
    transition: "all 0.2s ease",
    "&:hover": {
      backgroundColor: theme.palette.primary.dark,
      boxShadow: `0 2px 8px ${theme.palette.primary.main}4D`,
    },
  },
}));

const Contacts = () => {
  const classes = useStyles();
  const { user, socket } = useContext(AuthContext);

  const [loading,] = useState(false);
  const [, setPageNumber] = useState(1);
  const [selectedContactId, setSelectedContactId] = useState(null);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [hasMore,] = useState(false);
  const [dueDate, setDueDate] = useState("");
  const { returnDays } = useDate();

  const handleOpenContactModal = () => {
    setSelectedContactId(null);
    setContactModalOpen(true);
  };

  const handleCloseContactModal = () => {
    setSelectedContactId(null);
    setContactModalOpen(false);
  };

  const loadMore = () => {
    setPageNumber((prevState) => prevState + 1);
  };

  const handleScroll = (e) => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - (scrollTop + 100) < clientHeight) {
      loadMore();
    }
  };

  useEffect(() => {
    const currentDueDate = localStorage.getItem("dueDate");
    if (currentDueDate !== "" && currentDueDate !== "null") {
      setDueDate(moment(currentDueDate).format("DD/MM/YYYY"));
    }
  }, []);

  return (
    <MainContainer>
      <SubscriptionModal
        open={contactModalOpen}
        onClose={handleCloseContactModal}
        aria-labelledby="form-dialog-title"
        contactId={selectedContactId}
      ></SubscriptionModal>

      <MainHeader>
        <Title>Assinatura</Title>
      </MainHeader>
      <div className={classes.mainContainer}>
        <Paper
          className={classes.mainPaper}
          elevation={0}
        >
          <TextField
            id="license-period"
            label="Período de Licença"
            defaultValue={returnDays(user?.company?.dueDate) === 0 ? `Sua licença vence hoje!` : `Sua licença vence em ${returnDays(user?.company?.dueDate)} dias!`}
            fullWidth
            InputLabelProps={{ shrink: true }}
            InputProps={{ readOnly: true }}
            variant="outlined"
            className={classes.inputField}
          />

          <TextField
            id="billing-email"
            label="Email de cobrança"
            defaultValue={user?.email}
            fullWidth
            InputLabelProps={{ shrink: true }}
            InputProps={{ readOnly: true }}
            variant="outlined"
            className={classes.inputField}
          />

          <Button
            variant="contained"
            onClick={handleOpenContactModal}
            fullWidth
            className={classes.submitBtn}
          >
            Assine Agora!
          </Button>
        </Paper>
      </div>
    </MainContainer>
  );
};

export default Contacts;
