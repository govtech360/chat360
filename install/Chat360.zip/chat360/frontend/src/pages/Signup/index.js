import React, { useState, useEffect, useRef } from "react";
import qs from "query-string";
import * as Yup from "yup";
import { useHistory } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
import { toast } from "react-toastify";
import { Formik, Form, Field } from "formik";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import { Fade } from "@mui/material";
import { Helmet } from "react-helmet";
import { FormControl, InputLabel, MenuItem, Select } from "@material-ui/core";
import SecurityIcon from "@material-ui/icons/Security";
import usePlans from "../../hooks/usePlans";
import { i18n } from "../../translate/i18n";
import { openApi } from "../../services/api";
import toastError from "../../errors/toastError";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100vw",
    minHeight: "100vh",
    display: "flex",
    position: "relative",
    overflow: "hidden",
    background: "linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%)",
    "&::before": {
      content: '""',
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 
        "radial-gradient(circle at 20% 50%, rgba(62, 58, 242, 0.12) 0%, transparent 50%)," +
        "radial-gradient(circle at 80% 80%, rgba(107, 95, 255, 0.12) 0%, transparent 50%)",
      animation: "$gradientShift 15s ease infinite",
    },
  },
  "@keyframes gradientShift": {
    "0%, 100%": { opacity: 1 },
    "50%": { opacity: 0.8 },
  },
  "@keyframes slideInLeft": {
    "0%": { opacity: 0, transform: "translateX(-30px)" },
    "100%": { opacity: 1, transform: "translateX(0)" },
  },
  "@keyframes slideInRight": {
    "0%": { opacity: 0, transform: "translateX(30px)" },
    "100%": { opacity: 1, transform: "translateX(0)" },
  },
  "@keyframes phoneFloat": {
    "0%, 100%": { transform: "translateY(-20px) rotate(-5deg)" },
    "50%": { transform: "translateY(20px) rotate(5deg)" },
  },
  "@keyframes floatAround": {
    "0%, 100%": { transform: "translate(0, 0) scale(1)", opacity: 0.8 },
    "25%": { transform: "translate(10px, -15px) scale(1.1)", opacity: 1 },
    "50%": { transform: "translate(-10px, -25px) scale(0.9)", opacity: 0.7 },
    "75%": { transform: "translate(15px, -10px) scale(1.05)", opacity: 0.9 },
  },
  contentWrapper: {
    width: "100%",
    maxWidth: "1400px",
    margin: "0 auto",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "40px",
    position: "relative",
    zIndex: 1,
    minHeight: "100vh",
    [theme.breakpoints.down("lg")]: {
      maxWidth: "1200px",
      padding: "30px",
    },
    [theme.breakpoints.down("md")]: {
      justifyContent: "center",
      padding: "20px",
      minHeight: "auto",
      paddingTop: "60px",
      paddingBottom: "60px",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "15px",
      paddingTop: "40px",
      paddingBottom: "40px",
    },
  },
  leftSection: {
    flex: 1,
    paddingRight: "80px",
    animation: "$slideInLeft 0.8s cubic-bezier(0.4, 0, 0.2, 1)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    [theme.breakpoints.down("lg")]: {
      paddingRight: "60px",
    },
    [theme.breakpoints.down("md")]: {
      display: "none",
    },
  },
  phoneMockupContainer: {
    position: "relative",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    pointerEvents: "none",
  },
  phoneMockup: {
    width: "360px",
    height: "720px",
    animation: "$phoneFloat 6s ease-in-out infinite",
    position: "relative",
    transformStyle: "preserve-3d",
    transition: "transform 0.3s ease-out",
    "& svg": {
      width: "100%",
      height: "100%",
      filter: "drop-shadow(0 30px 60px rgba(62, 58, 242, 0.4))",
    },
    [theme.breakpoints.down("lg")]: {
      width: "320px",
      height: "640px",
    },
  },
  floatingElement: {
    position: "absolute",
    animation: "$floatAround 8s ease-in-out infinite",
    filter: "drop-shadow(0 8px 16px rgba(0, 0, 0, 0.4))",
    "& svg": {
      width: "60px",
      height: "60px",
    },
  },
  element1: {
    top: "10%",
    left: "-80px",
    animationDelay: "0s",
  },
  element2: {
    top: "30%",
    right: "-60px",
    animationDelay: "-2s",
  },
  element3: {
    bottom: "20%",
    left: "-70px",
    animationDelay: "-4s",
  },
  element4: {
    bottom: "10%",
    right: "-50px",
    animationDelay: "-6s",
  },
  formSection: {
    flex: "0 0 480px",
    animation: "$slideInRight 0.8s cubic-bezier(0.4, 0, 0.2, 1)",
    [theme.breakpoints.down("lg")]: {
      flex: "0 0 440px",
    },
    [theme.breakpoints.down("md")]: {
      flex: "0 0 100%",
      maxWidth: "440px",
    },
    [theme.breakpoints.down("sm")]: {
      maxWidth: "100%",
    },
  },
  formContainer: {
    background: "rgba(26, 26, 26, 0.95)",
    backdropFilter: "blur(30px)",
    borderRadius: "20px",
    padding: "32px 36px",
    boxShadow: 
      "0 25px 70px rgba(0, 0, 0, 0.5)," +
      "0 0 0 1px rgba(62, 58, 242, 0.2)," +
      "inset 0 1px 0 rgba(255, 255, 255, 0.05)",
    position: "relative",
    transition: "all 0.4s ease",
    "&:hover": {
      boxShadow: 
        "0 30px 80px rgba(0, 0, 0, 0.6)," +
        "0 0 0 1px rgba(62, 58, 242, 0.4)," +
        "inset 0 1px 0 rgba(255, 255, 255, 0.08)",
    },
    [theme.breakpoints.down("sm")]: {
      padding: "28px 24px",
    },
    [theme.breakpoints.down("xs")]: {
      padding: "24px 20px",
    },
  },
  formLogo: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "16px",
    "& img": {
      maxWidth: "190px",
      height: "auto",
      filter: "drop-shadow(0 0 20px rgba(62, 58, 242, 0.4))",
      transition: "all 0.3s ease",
      "&:hover": {
        transform: "scale(1.05)",
        filter: "drop-shadow(0 0 30px rgba(107, 95, 255, 0.6))",
      },
    },
  },
  formTitle: {
    fontSize: "clamp(1.4rem, 4vw, 1.65rem)",
    fontWeight: 800,
    color: "#ffffff",
    marginBottom: "6px",
    textAlign: "center",
    background: "linear-gradient(135deg, #3E3AF2 0%, #6B5FFF 100%)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text",
    letterSpacing: "-0.01em",
  },
  formSubtitle: {
    fontSize: "0.86rem",
    color: "#94a3b8",
    marginBottom: "20px",
    textAlign: "center",
    lineHeight: 1.4,
  },
  inputField: {
    marginBottom: "14px",
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
      backgroundColor: "#0f172a",
      transition: "all 0.3s ease",
      border: "1px solid rgba(62, 58, 242, 0.2)",
      minHeight: "46px",
      [theme.breakpoints.down("sm")]: {
        minHeight: "44px",
      },
      "&:hover": {
        backgroundColor: "#1a2332",
        borderColor: "rgba(62, 58, 242, 0.4)",
        "& fieldset": {
          borderColor: "rgba(62, 58, 242, 0.4)",
        },
      },
      "&.Mui-focused": {
        backgroundColor: "#1a2332",
        borderColor: "#3E3AF2",
        boxShadow: "0 0 0 3px rgba(62, 58, 242, 0.12)",
        "& fieldset": {
          borderColor: "#3E3AF2 !important",
          borderWidth: "2px",
        },
      },
    },
    "& .MuiOutlinedInput-input": {
      padding: "14px 13px",
      fontSize: "0.92rem",
      color: "#e2e8f0",
      fontWeight: 500,
      [theme.breakpoints.down("sm")]: {
        padding: "13px 12px",
        fontSize: "0.9rem",
      },
    },
    "& .MuiInputLabel-outlined": {
      fontSize: "0.93rem",
      fontWeight: 500,
      color: "#94a3b8",
      transform: "translate(14px, 14px) scale(1)",
      [theme.breakpoints.down("sm")]: {
        fontSize: "0.91rem",
        transform: "translate(14px, 13px) scale(1)",
      },
      "&.MuiInputLabel-shrink": {
        transform: "translate(14px, -9px) scale(0.75)",
        backgroundColor: "#0f172a",
        padding: "0 4px",
      },
      "&.Mui-focused": {
        color: "#3E3AF2",
        fontWeight: 600,
        backgroundColor: "#0f172a",
        padding: "0 4px",
      },
    },
    "& fieldset": {
      borderColor: "rgba(62, 58, 242, 0.2)",
      borderWidth: "1px",
    },
    "& .MuiInputAdornment-root": {
      "& svg": {
        color: "#3E3AF2",
        fontSize: "1.3rem",
      },
    },
  },
  submitBtn: {
    marginTop: "16px",
    marginBottom: "10px",
    background: "linear-gradient(135deg, #3E3AF2 0%, #6B5FFF 100%)",
    color: "#fff",
    padding: "10px 28px",
    fontSize: "0.96rem",
    fontWeight: 600,
    width: "100%",
    height: "46px",
    borderRadius: "8px",
    textTransform: "none",
    boxShadow: "0 4px 15px rgba(62, 58, 242, 0.4)",
    transition: "all 0.3s ease",
    cursor: "pointer",
    border: "2px solid transparent",
    position: "relative",
    overflow: "visible",
    [theme.breakpoints.down("sm")]: {
      height: "44px",
      fontSize: "0.94rem",
      padding: "10px 24px",
    },
    "&:hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 10px 20px rgba(62, 58, 242, 0.3)",
    },
    "&:active": {
      transform: "translateY(0)",
    },
  },
  loginLink: {
    marginTop: "12px",
    textAlign: "center",
    "& a": {
      color: "#3E3AF2",
      textDecoration: "none",
      fontSize: "0.88rem",
      fontWeight: 600,
      transition: "all 0.2s ease",
      position: "relative",
      "&::after": {
        content: '""',
        position: "absolute",
        bottom: -2,
        left: 0,
        width: "0%",
        height: "2px",
        background: "linear-gradient(90deg, #3E3AF2, #6B5FFF)",
        transition: "width 0.3s ease",
      },
      "&:hover": {
        color: "#6B5FFF",
        "&::after": {
          width: "100%",
        },
      },
    },
  },
  securityBadge: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginTop: "16px",
    padding: "9px 14px",
    backgroundColor: "rgba(59, 130, 246, 0.1)",
    borderRadius: "10px",
    border: "1px solid rgba(59, 130, 246, 0.3)",
    transition: "all 0.3s ease",
    "&:hover": {
      backgroundColor: "rgba(59, 130, 246, 0.15)",
      transform: "scale(1.02)",
    },
  },
  securityText: {
    display: "flex",
    alignItems: "center",
    fontSize: "0.8rem",
    color: "#60a5fa",
    fontWeight: 600,
    "& svg": {
      marginRight: "7px",
      fontSize: "1.15rem",
      color: "#3b82f6",
    },
  },
}));

const UserSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Campo obrigatório"),
  companyName: Yup.string()
    .min(2, "Muito curto!")
    .max(50, "Muito longo!")
    .required("Campo obrigatório"),
  document: Yup.string()
    .required("Campo obrigatório")
    .min(11, "CPF deve ter 11 dígitos ou CNPJ 14 dígitos")
    .max(14, "CPF deve ter 11 dígitos ou CNPJ 14 dígitos")
    .matches(/^[0-9]+$/, "Apenas números são permitidos"),
  password: Yup.string()
    .min(5, "Mínimo 5 caracteres!")
    .max(50, "Muito longo!")
    .required("Campo obrigatório"),
  email: Yup.string()
    .email("Email inválido")
    .required("Campo obrigatório"),
  phone: Yup.string().required("Campo obrigatório"),
  planId: Yup.string().required("Selecione um plano"),
});

// Componente PhoneMockup com animações
const PhoneMockup = () => {
  const classes = useStyles();
  const phoneRef = useRef(null);
  const [currentTime, setCurrentTime] = useState("9:41");
  const [messages, setMessages] = useState([
    { id: "message1", text: "Bem-vindo ao Chat360! 🎉", visible: false, typed: "" },
    { id: "message2", text: "Pronto para começar?", visible: false, typed: "" },
    { id: "message3", text: "Criar conta é rápido!", visible: false, typed: "" },
    { 
      id: "message4", 
      texts: [
        "✓ Escolha o Plano Ideal",
        "✓ Suporte especializado",
        "✓ Transforme seu Atendimento",
        "✓ Acesso a todos os recursos"
      ], 
      visible: false, 
      typed: ["", "", "", ""] 
    },
  ]);
  const [showTyping, setShowTyping] = useState(false);
  const [iconsVisible, setIconsVisible] = useState(false);

  // Atualizar hora
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
      }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Efeito 3D do mouse
  useEffect(() => {
    const handleMouseMove = (e) => {
      if (phoneRef.current && window.innerWidth > 968) {
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;
        
        const rotateY = (mouseX - 0.5) * 15;
        const rotateX = (mouseY - 0.5) * -15;
        
        phoneRef.current.style.transform = `perspective(1000px) rotateY(${rotateY}deg) rotateX(${rotateX}deg)`;
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Animação de digitação
  useEffect(() => {
    let timeouts = [];
    
    const animateMessages = async () => {
      // Mostrar ícones primeiro
      setTimeout(() => setIconsVisible(true), 500);

      let currentDelay = 1000;

      for (let i = 0; i < messages.length; i++) {
        const message = messages[i];
        
        // Mostrar indicador de digitação para mensagens do bot
        if (i % 2 === 0) {
          timeouts.push(setTimeout(() => setShowTyping(true), currentDelay));
          currentDelay += 800;
        }

        // Mostrar mensagem
        timeouts.push(setTimeout(() => {
          setShowTyping(false);
          setMessages(prev => {
            const newMessages = [...prev];
            newMessages[i] = { ...newMessages[i], visible: true };
            return newMessages;
          });
        }, currentDelay));

        currentDelay += 300;

        // Animar digitação
        if (message.texts) {
          // Múltiplas linhas
          for (let j = 0; j < message.texts.length; j++) {
            const text = message.texts[j];
            for (let k = 0; k <= text.length; k++) {
              timeouts.push(setTimeout(() => {
                setMessages(prev => {
                  const newMessages = [...prev];
                  const newTyped = [...newMessages[i].typed];
                  newTyped[j] = text.substring(0, k);
                  newMessages[i] = { ...newMessages[i], typed: newTyped };
                  return newMessages;
                });
              }, currentDelay + (k * 35)));
            }
            currentDelay += text.length * 35 + 100;
          }
        } else {
          // Linha única
          for (let k = 0; k <= message.text.length; k++) {
            timeouts.push(setTimeout(() => {
              setMessages(prev => {
                const newMessages = [...prev];
                newMessages[i] = { ...newMessages[i], typed: message.text.substring(0, k) };
                return newMessages;
              });
            }, currentDelay + (k * 35)));
          }
          currentDelay += message.text.length * 35;
        }

        currentDelay += 800;
      }

      // Reiniciar animação
      timeouts.push(setTimeout(() => {
        setMessages(prev => prev.map(msg => ({
          ...msg,
          visible: false,
          typed: Array.isArray(msg.typed) ? ["", "", "", ""] : ""
        })));
        setShowTyping(false);
        setTimeout(animateMessages, 1000);
      }, currentDelay + 2000));
    };

    animateMessages();

    return () => timeouts.forEach(clearTimeout);
  }, []);

  return (
    <div className={classes.phoneMockupContainer}>
      <div ref={phoneRef} className={classes.phoneMockup}>
        <svg viewBox="0 0 300 600" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Phone Frame */}
          <rect x="10" y="10" width="280" height="580" rx="40" fill="#1a1a1a" stroke="#3a3a3a" strokeWidth="2"/>
          
          {/* Screen */}
          <rect x="20" y="25" width="260" height="550" rx="30" fill="#0a0a0a"/>
          
          {/* Notch */}
          <rect x="110" y="25" width="80" height="25" rx="12" fill="#1a1a1a"/>
          
          {/* Status Bar */}
          <g opacity="0.8">
            <text x="35" y="43" fill="#ffffff" fontSize="10" fontFamily="Inter">{currentTime}</text>
            <circle cx="250" cy="39" r="3" fill="#4ade80"/>
            <rect x="257" y="36" width="15" height="7" rx="2" stroke="#ffffff" strokeWidth="1" fill="none"/>
            <rect x="273" y="38" width="2" height="3" fill="#ffffff"/>
          </g>
          
          {/* App Content */}
          <g>
            {/* Header */}
            <rect x="35" y="70" width="230" height="60" rx="15" fill="url(#signupGradient1)"/>
            <text x="50" y="95" fill="#ffffff" fontSize="14" fontWeight="bold" fontFamily="Inter">Chat360</text>
            <text x="50" y="115" fill="#e0e0e0" fontSize="10" fontFamily="Inter">Crie sua conta agora</text>
            
            {/* Messages */}
            {messages[0].visible && (
              <g opacity="0.9">
                <rect x="35" y="150" width="200" height="40" rx="12" fill="#3E3AF2"/>
                <text x="45" y="175" fill="#ffffff" fontSize="10" fontFamily="Inter">{messages[0].typed}</text>
              </g>
            )}
            
            {messages[1].visible && (
              <g opacity="0.9">
                <rect x="65" y="210" width="200" height="40" rx="12" fill="#2a2a2a"/>
                <text x="75" y="235" fill="#ffffff" fontSize="10" fontFamily="Inter">{messages[1].typed}</text>
              </g>
            )}
            
            {messages[2].visible && (
              <g opacity="0.9">
                <rect x="35" y="270" width="180" height="40" rx="12" fill="#6B5FFF"/>
                <text x="45" y="295" fill="#ffffff" fontSize="10" fontFamily="Inter">{messages[2].typed}</text>
              </g>
            )}
            
            {messages[3].visible && (
              <g opacity="0.9">
                <rect x="35" y="330" width="240" height="80" rx="12" fill="#6B5FFF"/>
                <text x="45" y="350" fill="#ffffff" fontSize="9" fontFamily="Inter">{messages[3].typed[0]}</text>
                <text x="45" y="362" fill="#ffffff" fontSize="9" fontFamily="Inter">{messages[3].typed[1]}</text>
                <text x="45" y="374" fill="#ffffff" fontSize="9" fontFamily="Inter">{messages[3].typed[2]}</text>
                <text x="45" y="386" fill="#ffffff" fontSize="9" fontFamily="Inter">{messages[3].typed[3]}</text>
              </g>
            )}
            
            {/* Typing Indicator */}
            {showTyping && (
              <g opacity="1">
                <rect x="35" y="430" width="60" height="30" rx="12" fill="#3E3AF2"/>
                <circle cx="50" cy="445" r="3" fill="#ffffff">
                  <animate attributeName="opacity" values="0.3;1;0.3" dur="1.4s" repeatCount="indefinite"/>
                </circle>
                <circle cx="65" cy="445" r="3" fill="#ffffff">
                  <animate attributeName="opacity" values="0.3;1;0.3" dur="1.4s" begin="0.2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="80" cy="445" r="3" fill="#ffffff">
                  <animate attributeName="opacity" values="0.3;1;0.3" dur="1.4s" begin="0.4s" repeatCount="indefinite"/>
                </circle>
              </g>
            )}
            
            {/* Features Icons */}
            {iconsVisible && (
              <g opacity="0.8">
                <circle cx="80" cy="490" r="18" fill="#3a3a3a"/>
                <path d="M84 483 L79 490 L82 490 L78 497 L85 488 L82 488 Z" fill="#fbbf24" stroke="#f59e0b" strokeWidth="0.5"/>
                
                <circle cx="150" cy="490" r="18" fill="#3a3a3a"/>
                <rect x="147" y="483" width="6" height="10" rx="3" fill="#60a5fa"/>
                
                <circle cx="220" cy="490" r="18" fill="#3a3a3a"/>
                <circle cx="220" cy="490" r="7" stroke="#34d399" strokeWidth="1.5" fill="none"/>
              </g>
            )}
            
            {/* Bottom Bar */}
            <rect x="35" y="525" width="230" height="45" rx="22.5" fill="#2a2a2a"/>
            <text x="75" y="553" fill="#a0a0a0" fontSize="11" fontFamily="Inter">Começar agora...</text>
            <circle cx="245" cy="547.5" r="15" fill="url(#signupGradient2)"/>
            <path d="M242 547.5 L250 547.5 L246 543 Z" fill="#ffffff"/>
          </g>
          
          {/* Gradients */}
          <defs>
            <linearGradient id="signupGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{stopColor:"#3E3AF2", stopOpacity:1}} />
              <stop offset="100%" style={{stopColor:"#6B5FFF", stopOpacity:1}} />
            </linearGradient>
            <linearGradient id="signupGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{stopColor:"#3E3AF2", stopOpacity:1}} />
              <stop offset="100%" style={{stopColor:"#6B5FFF", stopOpacity:1}} />
            </linearGradient>
          </defs>
        </svg>

        {/* Floating Social Media Icons */}
        <div className={`${classes.floatingElement} ${classes.element1}`}>
          <svg width="60" height="60" viewBox="0 0 50 50">
            <defs>
              <linearGradient id="whatsapp-grad-signup" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style={{ stopColor: "#60D669" }}/>
                <stop offset="100%" style={{ stopColor: "#1EBE4F" }}/>
              </linearGradient>
            </defs>
            <circle cx="25" cy="25" r="23" fill="url(#whatsapp-grad-signup)"/>
            <path d="M25 12 C17.8 12 12 17.8 12 25 C12 27.4 12.6 29.7 13.7 31.7 L12.5 36 L17 34.8 C18.9 35.8 21 36.5 25 36.5 C32.2 36.5 38 30.7 38 25 C38 17.8 32.2 12 25 12 Z M31 28.5 C30.7 29.3 29.5 30 28.7 30.2 C28.2 30.3 27.5 30.4 24.9 29.4 C21.6 28.1 19.5 24.8 19.3 24.6 C19.1 24.4 17.8 22.7 17.8 20.9 C17.8 19.1 18.7 18.2 19 17.9 C19.3 17.6 19.6 17.5 19.9 17.5 C20 17.5 20.2 17.5 20.3 17.5 C20.5 17.5 20.7 17.5 20.9 18 C21.2 18.6 21.8 20.4 21.9 20.6 C22 20.8 22.1 21 22 21.2 C21.9 21.4 21.8 21.5 21.6 21.7 C21.4 21.9 21.2 22.2 21.1 22.3 C20.9 22.5 20.7 22.7 20.9 23 C21.1 23.3 21.8 24.5 22.9 25.5 C24.3 26.7 25.5 27.1 25.8 27.3 C26.1 27.5 26.3 27.4 26.5 27.2 C26.7 27 27.3 26.3 27.5 26 C27.7 25.7 28 25.8 28.3 25.9 C28.6 26 30.4 26.9 30.7 27.1 C31 27.3 31.2 27.4 31.3 27.5 C31.3 27.7 31.3 28.2 31 28.5 Z" fill="white"/>
          </svg>
        </div>

        <div className={`${classes.floatingElement} ${classes.element2}`}>
          <svg width="60" height="60" viewBox="0 0 50 50">
            <defs>
              <linearGradient id="instagram-grad-signup" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" style={{ stopColor: "#FFD521" }}/>
                <stop offset="50%" style={{ stopColor: "#E4405F" }}/>
                <stop offset="100%" style={{ stopColor: "#5B51D8" }}/>
              </linearGradient>
            </defs>
            <rect x="9" y="9" width="32" height="32" rx="7" fill="url(#instagram-grad-signup)"/>
            <circle cx="25" cy="25" r="7" fill="none" stroke="white" strokeWidth="2.5"/>
            <circle cx="34" cy="16" r="2" fill="white"/>
          </svg>
        </div>

        <div className={`${classes.floatingElement} ${classes.element3}`}>
          <svg width="60" height="60" viewBox="0 0 50 50">
            <defs>
              <linearGradient id="facebook-grad-signup" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style={{ stopColor: "#4A90E2" }}/>
                <stop offset="100%" style={{ stopColor: "#1877F2" }}/>
              </linearGradient>
            </defs>
            <circle cx="25" cy="25" r="23" fill="url(#facebook-grad-signup)"/>
            <path d="M27.5 39 L27.5 26.5 L31.5 26.5 L32 21.5 L27.5 21.5 L27.5 18.8 C27.5 17.4 27.9 16.5 29.9 16.5 L32.2 16.5 L32.2 12.1 C31.8 12.05 30.3 11.9 28.6 11.9 C25 11.9 22.5 14.1 22.5 18.3 L22.5 21.5 L18.5 21.5 L18.5 26.5 L22.5 26.5 L22.5 39 L27.5 39 Z" fill="white"/>
          </svg>
        </div>

        <div className={`${classes.floatingElement} ${classes.element4}`}>
          <svg width="60" height="60" viewBox="0 0 50 50">
            <defs>
              <linearGradient id="telegram-grad-signup" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style={{ stopColor: "#37BBF8" }}/>
                <stop offset="100%" style={{ stopColor: "#0088CC" }}/>
              </linearGradient>
            </defs>
            <circle cx="25" cy="25" r="23" fill="url(#telegram-grad-signup)"/>
            <path d="M34 16 L14 24 C13.3 24.3 13.3 25.1 14 25.4 L18 26.8 L31 19 L21.5 27.5 L21.5 32.5 C21.5 33.2 22.4 33.5 22.9 33 L26 30 L30 32.5 C30.6 32.8 31.3 32.5 31.5 31.8 L35.5 17.5 C35.7 16.7 35 16 34 16 Z" fill="white"/>
          </svg>
        </div>
      </div>
    </div>
  );
};

const SignUp = () => {
  const classes = useStyles();
  const history = useHistory();
  const { getPlanList } = usePlans();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [userCreationEnabled, setUserCreationEnabled] = useState(true);

  let companyId = null;
  const params = qs.parse(window.location.search);
  if (params.companyId !== undefined) {
    companyId = params.companyId;
  }

  const initialState = {
    name: "",
    email: "",
    password: "",
    phone: "",
    companyId,
    companyName: "",
    document: "",
    planId: "",
  };

  const [user] = useState(initialState);

  const backendUrl =
    process.env.REACT_APP_BACKEND_URL === "https://localhost:8090"
      ? "https://localhost:8090"
      : process.env.REACT_APP_BACKEND_URL;

  useEffect(() => {
    const fetchUserCreationStatus = async () => {
      try {
        const response = await fetch(`${backendUrl}/settings/userCreation`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch user creation status");
        }

        const data = await response.json();
        const isEnabled = data.userCreation === "enabled";
        setUserCreationEnabled(isEnabled);

        if (!isEnabled) {
          toast.info("Cadastro de novos usuários está desabilitado.");
          history.push("/login");
        }
      } catch (err) {
        console.error("Erro ao verificar userCreation:", err);
        setUserCreationEnabled(false);
        toast.error("Erro ao verificar permissão de cadastro.");
        history.push("/login");
      }
    };

    fetchUserCreationStatus();
  }, [backendUrl, history]);

  useEffect(() => {
    setLoading(true);
    const fetchData = async () => {
      const planList = await getPlanList({ listPublic: "false" });
      setPlans(planList);
      setLoading(false);
    };
    fetchData();
  }, [getPlanList]);

  const handleSignUp = async (values) => {
    try {
      await openApi.post("/auth/signup", values);
      toast.success(i18n.t("signup.toasts.success"));
      history.push("/login");
    } catch (err) {
      toastError(err);
    }
  };

  if (!userCreationEnabled) {
    return null;
  }

  return (
    <>
      <Helmet>
        <title>Cadastro - Chat360 | Crie sua conta</title>
        <meta name="description" content="Crie sua conta na plataforma Chat360 e comece a gerenciar seus atendimentos" />
        <link rel="icon" type="image/png" href="/favicon.png" />
      </Helmet>

      <div className={classes.root}>
        <div className={classes.contentWrapper}>
          {/* Seção Esquerda - Phone Mockup Animado */}
          <div className={classes.leftSection}>
            <PhoneMockup />
          </div>

          {/* Seção Direita - Formulário de Cadastro */}
          <div className={classes.formSection}>
            <Fade in={true} timeout={800}>
              <div className={classes.formContainer}>
                {/* Logo do Chat360 */}
                <div className={classes.formLogo}>
                  <img 
                    src="/logo-horizontal-branco.png" 
                    alt="Chat360 Logo" 
                  />
                </div>

                <Typography className={classes.formTitle}>
                  Criar Nova Conta
                </Typography>
                <Typography className={classes.formSubtitle}>
                  Preencha seus dados para começar
                </Typography>

                <Formik
                  initialValues={user}
                  enableReinitialize={true}
                  validationSchema={UserSchema}
                  onSubmit={(values, actions) => {
                    setTimeout(() => {
                      handleSignUp(values);
                      actions.setSubmitting(false);
                    }, 400);
                  }}
                >
                  {({ touched, errors, isSubmitting, isValid, dirty }) => (
                    <Form>
                      <Grid container spacing={2}>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="companyName"
                            label={i18n.t("signup.form.company")}
                            error={touched.companyName && Boolean(errors.companyName)}
                            helperText={touched.companyName && errors.companyName}
                            name="companyName"
                            autoComplete="companyName"
                            autoFocus
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="document"
                            label="CPF/CNPJ *"
                            error={touched.document && Boolean(errors.document)}
                            helperText={touched.document && errors.document}
                            name="document"
                            autoComplete="document"
                            placeholder="Apenas números (11 ou 14 dígitos)"
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            autoComplete="name"
                            name="name"
                            error={touched.name && Boolean(errors.name)}
                            helperText={touched.name && errors.name}
                            variant="outlined"
                            fullWidth
                            id="name"
                            label={i18n.t("signup.form.name")}
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="email"
                            label={i18n.t("signup.form.email")}
                            name="email"
                            error={touched.email && Boolean(errors.email)}
                            helperText={touched.email && errors.email}
                            autoComplete="email"
                            inputProps={{ style: { textTransform: "lowercase" } }}
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            name="password"
                            error={touched.password && Boolean(errors.password)}
                            helperText={touched.password && errors.password}
                            label={i18n.t("signup.form.password")}
                            type="password"
                            id="password"
                            autoComplete="current-password"
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <Field
                            as={TextField}
                            variant="outlined"
                            fullWidth
                            id="phone"
                            label={i18n.t("signup.form.phone")}
                            name="phone"
                            error={touched.phone && Boolean(errors.phone)}
                            helperText={touched.phone && errors.phone}
                            autoComplete="phone"
                            className={classes.inputField}
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <FormControl fullWidth variant="outlined" className={classes.inputField}>
                            <InputLabel id="plan-selection-label">Plano *</InputLabel>
                            <Field
                              as={Select}
                              labelId="plan-selection-label"
                              id="plan-selection"
                              name="planId"
                              label="Plano *"
                              required
                              error={touched.planId && Boolean(errors.planId)}
                            >
                              {plans.map((plan, key) => (
                                <MenuItem key={key} value={plan.id}>
                                  {plan.name} - Atendentes: {plan.users} - WhatsApp: {plan.connections} - R$ {plan.amount}
                                </MenuItem>
                              ))}
                            </Field>
                            {touched.planId && errors.planId && (
                              <Typography variant="caption" color="error" style={{ marginLeft: 14, marginTop: 4 }}>
                                {errors.planId}
                              </Typography>
                            )}
                          </FormControl>
                        </Grid>
                      </Grid>

                      <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        className={classes.submitBtn}
                        disabled={isSubmitting || !isValid || !dirty}
                      >
                        {isSubmitting ? "Criando conta..." : i18n.t("signup.buttons.submit")}
                      </Button>

                      <div className={classes.loginLink}>
                        <RouterLink to="/login">
                          {i18n.t("signup.buttons.login")}
                        </RouterLink>
                      </div>

                      <div className={classes.securityBadge}>
                        <div className={classes.securityText}>
                          <SecurityIcon />
                          <span>Seus dados estão protegidos e seguros</span>
                        </div>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </Fade>
          </div>
        </div>
      </div>
    </>
  );
};

export default SignUp;
