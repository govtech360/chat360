import React, { useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";

import MomentsUser from "../../components/MomentsUser";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import { Paper } from "@material-ui/core";
import Title from "../../components/Title";
import ForbiddenPage from "../../components/ForbiddenPage";
import { AuthContext } from "../../context/Auth/AuthContext";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(3),
    borderRadius: 20,
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
    marginBottom: theme.spacing(2),
    minHeight: "calc(100vh - 150px)",
  },
}));

const ChatMoments = () => {
  const classes = useStyles();
  const { user } = useContext(AuthContext);
  
  return (
    user.profile === "user" && user.allowRealTime === "disabled" ? (
      <ForbiddenPage />
    ) : (
      <MainContainer>
        <MainHeader>
          <Title>Painel de Atendimentos</Title>
        </MainHeader>
        <Paper className={classes.mainPaper} elevation={0}>
          <MomentsUser />
        </Paper>
      </MainContainer>
    )
  );
};

export default ChatMoments;
