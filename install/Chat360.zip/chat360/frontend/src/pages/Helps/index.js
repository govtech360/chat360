import React, { useState, useEffect, useCallback } from "react";
import { makeStyles, Paper, Typography, Modal, IconButton } from "@material-ui/core";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";
import { i18n } from "../../translate/i18n";
import useHelps from "../../hooks/useHelps";

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(2),
  },
  mainPaper: {
    width: '100%',
    borderRadius: 20,
    overflow: "hidden",
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
    padding: theme.spacing(3),
  },
  contentWrapper: {
    overflowY: 'auto',
    maxHeight: 'calc(100vh - 250px)',
    ...theme.scrollbarStyles,
  },
  cardsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
    gap: theme.spacing(3),
    padding: theme.spacing(1),
  },
  helpCard: {
    position: 'relative',
    width: '100%',
    minHeight: '340px',
    padding: 0,
    borderRadius: 12,
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    backgroundColor: theme.palette.background.paper,
    border: `1px solid ${theme.palette.divider}`,
    overflow: 'hidden',
    transition: 'all 0.2s ease',
    '&:hover': {
      transform: 'translateY(-4px)',
      boxShadow: theme.palette.mode === "dark"
        ? "0 8px 24px rgba(0, 0, 0, 0.6)"
        : "0 8px 24px rgba(0, 0, 0, 0.12)",
      borderColor: theme.palette.primary.main,
    },
  },
  videoThumbnail: {
    width: '100%',
    height: '200px',
    objectFit: 'cover',
  },
  videoTitle: {
    padding: theme.spacing(2, 2, 1, 2),
    fontSize: '1.05rem',
    fontWeight: 600,
    color: theme.palette.text.primary,
    lineHeight: 1.4,
  },
  videoDescription: {
    padding: theme.spacing(0, 2, 2, 2),
    maxHeight: '60px',
    overflow: 'hidden',
    fontSize: '0.875rem',
    color: theme.palette.text.secondary,
    lineHeight: 1.5,
  },
  videoModal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backdropFilter: 'blur(8px)',
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
  },
  videoModalContent: {
    outline: 'none',
    width: '90%',
    maxWidth: 1280,
    aspectRatio: '16/9',
    position: 'relative',
    backgroundColor: '#000',
    borderRadius: 12,
    overflow: 'hidden',
    boxShadow: '0 20px 60px rgba(0, 0, 0, 0.7)',
  },
}));

const Helps = () => {
  const classes = useStyles();
  const [records, setRecords] = useState([]);
  const { list } = useHelps();
  const [selectedVideo, setSelectedVideo] = useState(null);

  useEffect(() => {
    async function fetchData() {
      const helps = await list();
      setRecords(helps);
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openVideoModal = (video) => {
    setSelectedVideo(video);
  };

  const closeVideoModal = () => {
    setSelectedVideo(null);
  };

  const handleModalClose = useCallback((event) => {
    if (event.key === "Escape") {
      closeVideoModal();
    }
  }, []);

  useEffect(() => {
    document.addEventListener("keydown", handleModalClose);
    return () => {
      document.removeEventListener("keydown", handleModalClose);
    };
  }, [handleModalClose]);

  const renderVideoModal = () => {
    return (
      <Modal
        open={Boolean(selectedVideo)}
        onClose={closeVideoModal}
        className={classes.videoModal}
      >
        <div className={classes.videoModalContent}>
          {selectedVideo && (
            <iframe
              style={{ width: "100%", height: "100%", position: "absolute", top: 0, left: 0 }}
              src={`https://www.youtube.com/embed/${selectedVideo}`}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          )}
        </div>
      </Modal>
    );
  };

  const renderHelps = () => {
    return (
      <div className={classes.cardsGrid}>
        {records.length ? records.map((record, key) => (
          <Paper 
            key={key} 
            className={classes.helpCard} 
            onClick={() => openVideoModal(record.video)}
            elevation={0}
          >
            <img
              src={`https://img.youtube.com/vi/${record.video}/mqdefault.jpg`}
              alt="Thumbnail"
              className={classes.videoThumbnail}
            />
            <Typography variant="button" className={classes.videoTitle}>
              {record.title}
            </Typography>
            <Typography variant="caption" className={classes.videoDescription}>
              {record.description}
            </Typography>
          </Paper>
        )) : (
          <Typography 
            variant="body1" 
            style={{ 
              gridColumn: '1 / -1', 
              textAlign: 'center', 
              padding: '40px 0' 
            }}
          >
            {i18n.t("helps.noRecords")}
          </Typography>
        )}
      </div>
    );
  };

  return (
    <MainContainer className={classes.root}>
      <MainHeader>
        <Title>{i18n.t("helps.title")} ({records.length})</Title>
        <MainHeaderButtonsWrapper></MainHeaderButtonsWrapper>
      </MainHeader>
      <Paper className={classes.mainPaper}>
        <div className={classes.contentWrapper}>
          {renderHelps()}
        </div>
      </Paper>
      {renderVideoModal()}
    </MainContainer>
  );
};

export default Helps;