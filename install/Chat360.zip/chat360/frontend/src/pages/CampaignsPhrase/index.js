/* eslint-disable no-unused-vars */

import { useTheme } from "@material-ui/core/styles";
import React, { useState, useEffect, useReducer, useContext } from "react";
import { toast } from "react-toastify";

import { useHistory } from "react-router-dom";

import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import IconButton from "@material-ui/core/IconButton";
import SearchIcon from "@material-ui/icons/Search";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import EditIcon from "@material-ui/icons/Edit";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import { Box, Tooltip } from "@material-ui/core";
import { ToggleOn, Settings as SettingsIcon } from "@material-ui/icons";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";

import api from "../../services/api";
import { i18n } from "../../translate/i18n";
import TableRowSkeleton from "../../components/TableRowSkeleton";
import ConfirmationModal from "../../components/ConfirmationModal";
import toastError from "../../errors/toastError";
import { Can } from "../../components/Can";
import { AuthContext } from "../../context/Auth/AuthContext";
import CampaignModalPhrase from "../../components/CampaignModalPhrase";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";

const reducer = (state, action) => {
  if (action.type === "LOAD_CAMPAIGNS") {
    const campaigns = action.payload;
    const newCampaigns = [];

    if (Array.isArray(campaigns)) {
      campaigns.forEach(campaign => {
        const campaignIndex = state.findIndex(u => u.id === campaign.id);
        if (campaignIndex !== -1) {
          state[campaignIndex] = campaign;
        } else {
          newCampaigns.push(campaign);
        }
      });
    }

    return [...state, ...newCampaigns];
  }

  if (action.type === "UPDATE_CAMPAIGNS") {
    const campaign = action.payload;
    const campaignIndex = state.findIndex(u => u.id === campaign.id);

    if (campaignIndex !== -1) {
      state[campaignIndex] = campaign;
      return [...state];
    } else {
      return [campaign, ...state];
    }
  }

  if (action.type === "DELETE_CAMPAIGN") {
    const campaignId = action.payload;

    const campaignIndex = state.findIndex(u => u.id === campaignId);
    if (campaignIndex !== -1) {
      state.splice(campaignIndex, 1);
    }
    return [...state];
  }

  if (action.type === "RESET") {
    return [];
  }
};

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(2),
  },
  mainPaper: {
    width: "100%",
    borderRadius: 20,
    overflow: "hidden",
    boxShadow: theme.palette.mode === "dark"
      ? "0 4px 20px rgba(0, 0, 0, 0.5)"
      : "0 4px 20px rgba(0, 0, 0, 0.08)",
  },
  tableWrapper: {
    overflowX: "auto",
    overflowY: "auto",
    maxHeight: "calc(100vh - 250px)",
    ...theme.scrollbarStyles,
  },
  table: {
    minWidth: 900,
    "& .MuiTableHead-root": {
      backgroundColor: theme.palette.background.default,
      position: "sticky",
      top: 0,
      zIndex: 10,
    },
    "& .MuiTableCell-head": {
      fontWeight: 700,
      fontSize: "0.85rem",
      color: theme.palette.text.primary,
      backgroundColor: theme.palette.background.default,
      borderBottom: `2px solid ${theme.palette.divider}`,
      padding: theme.spacing(2),
      whiteSpace: "nowrap",
    },
    "& tbody tr": {
      borderBottom: `1px solid ${theme.palette.divider}`,
      transition: "background-color 0.2s ease",
      "&:hover": {
        backgroundColor: theme.palette.mode === "dark"
          ? "rgba(255, 255, 255, 0.05)"
          : "rgba(0, 0, 0, 0.02)",
      },
    },
    "& tbody td": {
      padding: theme.spacing(2),
      borderBottom: "none",
      color: theme.palette.text.primary,
    },
  },
  actionButton: {
    borderRadius: 8,
    padding: "8px 20px",
    textTransform: "none",
    fontWeight: 600,
    boxShadow: "none",
    "&:hover": {
      boxShadow: theme.palette.mode === "dark"
        ? "0 4px 12px rgba(0, 0, 0, 0.4)"
        : "0 4px 12px rgba(0, 0, 0, 0.15)",
    },
  },
  searchField: {
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
    },
  },
  headerIcon: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
    "& svg": {
      fontSize: "1rem",
    },
  },
}));

const CampaignsPhrase = () => {
  const classes = useStyles();
  const theme = useTheme();

  const history = useHistory();

  const { user } = useContext(AuthContext);

  const [loading, setLoading] = useState(true);
  const [pageNumber, setPageNumber] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [deletingCampaign, setDeletingCampaign] = useState(null);
  const [campaignModalOpen, setCampaignModalOpen] = useState(false);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [searchParam, setSearchParam] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deletingContact, setDeletingContact] = useState(null);

  const [campaignflows, setCampaignFlows] = useState([]);
  const [ModalOpenPhrase, setModalOpenPhrase] = useState(false);
  const [campaignflowSelected, setCampaignFlowSelected] = useState();
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedCampaignFlow, setSelectedCampaignFlow] = useState(null);

  const handleDeleteCampaign = async campaignId => {
    try {
      await api.delete(`/flowcampaign/${campaignId}`);
      toast.success("Frase deletada");
      getCampaigns()
    } catch (err) {
      toastError(err);
    }
    
  };

  const getCampaigns =  async() => {
    setLoading(true);
    await api.get("/flowcampaign").then(res => {
      setCampaignFlows(res.data.flow);
      setLoading(false);
    });
  };

  const onSaveModal = () => {
    getCampaigns()
  }

  const handleScroll = e => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - (scrollTop + 100) < clientHeight) {
    }
  };

  const handleMenuClick = (event, flow) => {
    setAnchorEl(event.currentTarget);
    setSelectedCampaignFlow(flow);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedCampaignFlow(null);
  };

  const handleMenuEdit = () => {
    if (selectedCampaignFlow) {
      setCampaignFlowSelected(selectedCampaignFlow.id);
      setModalOpenPhrase(true);
    }
    handleMenuClose();
  };

  const handleMenuDelete = () => {
    if (selectedCampaignFlow) {
      setConfirmModalOpen(true);
      setDeletingContact(selectedCampaignFlow);
    }
    handleMenuClose();
  };

  useEffect(() => {
    getCampaigns();
  }, []);

  return (
    <MainContainer className={classes.root}>
      <ConfirmationModal
        title={
          deletingCampaign &&
          `${i18n.t("campaigns.confirmationModal.deleteTitle")} ${
            deletingCampaign.name
          }?`
        }
        open={confirmModalOpen}
        onClose={setConfirmModalOpen}
        onConfirm={() => handleDeleteCampaign(deletingContact.id)}
      >
        {i18n.t("campaigns.confirmationModal.deleteMessage")}
      </ConfirmationModal>
      <CampaignModalPhrase
        open={ModalOpenPhrase}
        onClose={() => setModalOpenPhrase(false)}
        FlowCampaignId={campaignflowSelected}
        onSave={onSaveModal}
      />
      <MainHeader>
        <Title>Campanhas ({campaignflows.length})</Title>
        <MainHeaderButtonsWrapper>
          <Button
            variant="contained"
            color="primary"
            onClick={() => {
              setCampaignFlowSelected();
              setModalOpenPhrase(true);
            }}
            className={classes.actionButton}
          >
            Adicionar Campanha
          </Button>
        </MainHeaderButtonsWrapper>
      </MainHeader>
      <Paper className={classes.mainPaper}>
        <div className={classes.tableWrapper} onScroll={handleScroll}>
          <Table size="small" className={classes.table}>
            <TableHead>
              <TableRow>
                <TableCell align="left">
                  <Tooltip title="Nome da campanha">
                    <Box className={classes.headerIcon}>
                      <ToggleOn />
                      <span>Nome</span>
                    </Box>
                  </Tooltip>
                </TableCell>
                <TableCell align="left" style={{ width: "150px" }}>
                  <Tooltip title="Status da campanha">
                    <Box className={classes.headerIcon}>
                      <ToggleOn />
                      <span>Status</span>
                    </Box>
                  </Tooltip>
                </TableCell>
                <TableCell align="center" style={{ width: "100px" }}>
                  <Tooltip title="Ações">
                    <Box className={classes.headerIcon}>
                      <SettingsIcon />
                      <span>Ações</span>
                    </Box>
                  </Tooltip>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {campaignflows.map((flow) => (
                <TableRow key={flow.id}>
                  <TableCell align="left">{flow.name}</TableCell>
                  <TableCell align="left">
                    {flow.status ? "Ativo" : "Desativado"}
                  </TableCell>
                  <TableCell align="center">
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuClick(e, flow)}
                      title="Mais opções"
                    >
                      <MoreVertIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
              {loading && <TableRowSkeleton columns={3} />}
            </TableBody>
          </Table>
        </div>
      </Paper>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        PaperProps={{
          style: {
            borderRadius: 8,
            minWidth: 180,
          }
        }}
      >
        <MenuItem onClick={handleMenuEdit}>
          <ListItemIcon>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText primary="Editar" />
        </MenuItem>
        <Can
          role={user.profile}
          perform="contacts-page:deleteContact"
          yes={() => (
            <MenuItem onClick={handleMenuDelete}>
              <ListItemIcon>
                <DeleteOutlineIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText primary="Excluir" />
            </MenuItem>
          )}
        />
      </Menu>
    </MainContainer>
  );
};

export default CampaignsPhrase;
