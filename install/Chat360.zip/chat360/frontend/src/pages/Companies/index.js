import React, { useState, useEffect, useContext } from "react";
import { toast } from "react-toastify";
import { useHistory } from "react-router-dom";

import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import SearchIcon from "@material-ui/icons/Search";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";
import { CompanyForm, CompaniesManagerGrid } from "../../components/CompaniesManager";

import { i18n } from "../../translate/i18n";
import { AuthContext } from "../../context/Auth/AuthContext";
import useCompanies from "../../hooks/useCompanies";
import ConfirmationModal from "../../components/ConfirmationModal";

const useStyles = makeStyles((theme) => ({
    root: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        width: "100%",
        maxWidth: "100%",
    },
    mainPaper: {
        flex: 1,
        borderRadius: 20,
        display: "flex",
        flexDirection: "column",
        width: "100%",
        maxWidth: "100%",
        minWidth: 0,
        boxSizing: "border-box",
        height: "calc(100vh - 200px)",
        boxShadow: theme.palette.mode === "dark" 
          ? "0 4px 20px rgba(0, 0, 0, 0.5), 0 2px 12px rgba(0, 0, 0, 0.3)" 
          : "0 4px 20px rgba(0, 0, 0, 0.08), 0 2px 12px rgba(0, 0, 0, 0.04)",
    overflow: "hidden",
        [theme.breakpoints.down('md')]: {
            height: "calc(100vh - 150px)",
        },
        [theme.breakpoints.down('sm')]: {
            height: "calc(100vh - 120px)",
            borderRadius: 12,
        },
    },
  formSection: {
    padding: theme.spacing(2),
    borderBottom: `1px solid ${theme.palette.divider}`,
    backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.02)" : "rgba(0, 0, 0, 0.01)",
        [theme.breakpoints.down('sm')]: {
      padding: theme.spacing(1),
        },
    },
  tableSection: {
        flex: 1,
    overflow: "hidden",
    },
}));

const Companies = () => {
    const classes = useStyles();
    const history = useHistory();
    const { user } = useContext(AuthContext);
    const { list, save, update, remove } = useCompanies();

    const [showConfirmDialog, setShowConfirmDialog] = useState(false);
    const [loading, setLoading] = useState(false);
    const [records, setRecords] = useState([]);
    const [filteredRecords, setFilteredRecords] = useState([]);
    const [searchParam, setSearchParam] = useState("");
    const [record, setRecord] = useState({
        name: "",
        email: "",
        phone: "",
        planId: "",
        status: true,
        dueDate: "",
        recurrence: "",
        password: "",
        document: "",
        paymentMethod: ""
    });

    useEffect(() => {
        async function fetchData() {
            if (!user.super) {
                toast.error("Esta empresa não possui permissão para acessar essa página! Estamos lhe redirecionando.");
                setTimeout(() => {
                    history.push(`/`)
                }, 1000);
            }
        }
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        loadCompanies();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        // Filtro de busca
        if (searchParam) {
            const filtered = records.filter((company) => {
                const searchLower = searchParam.toLowerCase();
                return (
                    (company.name && company.name.toLowerCase().includes(searchLower)) ||
                    (company.email && company.email.toLowerCase().includes(searchLower)) ||
                    (company.phone && company.phone.toLowerCase().includes(searchLower)) ||
                    (company.id && company.id.toString().includes(searchLower)) ||
                    (company.plan && company.plan.name && company.plan.name.toLowerCase().includes(searchLower))
                );
            });
            setFilteredRecords(filtered);
        } else {
            setFilteredRecords(records);
        }
    }, [searchParam, records]);

    const loadCompanies = async () => {
        setLoading(true);
        try {
            const companyList = await list();
            setRecords(companyList);
            setFilteredRecords(companyList);
        } catch (e) {
            toast.error("Não foi possível carregar a lista de empresas");
        }
                    setLoading(false);
    };

    const handleSubmit = async (data) => {
        setLoading(true);
        try {
            if (data.id !== undefined) {
                await update(data);
            } else {
                await save(data);
            }
            await loadCompanies();
            handleCancel();
            toast.success("Operação realizada com sucesso!");
        } catch (e) {
            toast.error(
                "Não foi possível realizar a operação. Verifique se já existe uma empresa com o mesmo nome ou se os campos foram preenchidos corretamente"
            );
        }
        setLoading(false);
    };

    const handleDelete = async () => {
        setLoading(true);
        try {
            await remove(record.id);
            await loadCompanies();
            handleCancel();
            toast.success("Operação realizada com sucesso!");
        } catch (e) {
            toast.error("Não foi possível realizar a operação");
        }
        setLoading(false);
    };

    const handleOpenDeleteDialog = () => {
        setShowConfirmDialog(true);
    };

    const handleCancel = () => {
        setRecord((prev) => ({
            ...prev,
            name: "",
            email: "",
            phone: "",
            planId: "",
            status: true,
            dueDate: "",
            recurrence: "",
            password: "",
            document: "",
            paymentMethod: ""
        }));
    };

    const handleSelect = (data) => {
        setRecord((prev) => ({
            ...prev,
            id: data.id,
            name: data.name || "",
            phone: data.phone || "",
            email: data.email || "",
            planId: data.planId || "",
            status: data.status === false ? false : true,
            dueDate: data.dueDate || "",
            recurrence: data.recurrence || "",
            password: "",
            document: data.document || "",
            paymentMethod: data.paymentMethod || "",
        }));
    };

    const handleSearch = (event) => {
        setSearchParam(event.target.value);
    };

    return (
        <MainContainer className={classes.root}>
            <ConfirmationModal
                title="Exclusão de Registro"
                open={showConfirmDialog}
                onClose={() => setShowConfirmDialog(false)}
                onConfirm={() => handleDelete()}
            >
                Deseja realmente excluir esse registro?
            </ConfirmationModal>
            
            <MainHeader>
                <Title>{i18n.t("compaies.title")} ({filteredRecords.length})</Title>
                <MainHeaderButtonsWrapper>
                    <TextField
                        placeholder={i18n.t("contacts.searchPlaceholder")}
                        type="search"
                        value={searchParam}
                        onChange={handleSearch}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: "gray" }} />
                                </InputAdornment>
                            ),
                        }}
                    />
                </MainHeaderButtonsWrapper>
            </MainHeader>

            <Paper className={classes.mainPaper} elevation={1}>
                <div className={classes.formSection}>
                    <CompanyForm
                        initialValue={record}
                        onDelete={handleOpenDeleteDialog}
                        onSubmit={handleSubmit}
                        onCancel={handleCancel}
                        loading={loading}
                    />
                </div>
                <div className={classes.tableSection}>
                    <CompaniesManagerGrid 
                        records={filteredRecords} 
                        onSelect={handleSelect} 
                    />
                    </div>
            </Paper>
        </MainContainer>
    );
};

export default Companies;
