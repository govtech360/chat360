import React, { useState, useEffect, useReducer, useContext } from "react";
import { toast } from "react-toastify";
import { useHistory } from "react-router-dom";
// import { SocketContext } from "../../context/Socket/SocketContext";

import { makeStyles, useTheme } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Box from "@material-ui/core/Box";
import Tooltip from "@material-ui/core/Tooltip";

// Ícones
import FingerprintIcon from "@material-ui/icons/Fingerprint";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import BusinessIcon from "@material-ui/icons/Business";
import EmailIcon from "@material-ui/icons/Email";
import CardMembershipIcon from "@material-ui/icons/CardMembership";
import AttachMoneyIcon from "@material-ui/icons/AttachMoney";
import EventIcon from "@material-ui/icons/Event";
import DateRangeIcon from "@material-ui/icons/DateRange";
import AccessTimeIcon from "@material-ui/icons/AccessTime";
import FolderIcon from "@material-ui/icons/Folder";
import DescriptionIcon from "@material-ui/icons/Description";
import UpdateIcon from "@material-ui/icons/Update";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";

import Title from "../../components/Title";

import api from "../../services/api";
import { i18n } from "../../translate/i18n";
import TableRowSkeleton from "../../components/TableRowSkeleton";
import CompanyModal from "../../components/CompaniesModal";
import ConfirmationModal from "../../components/ConfirmationModal";
import toastError from "../../errors/toastError";
import { AuthContext } from "../../context/Auth/AuthContext";
import { useDate } from "../../hooks/useDate";
import usePlans from "../../hooks/usePlans";
import moment from "moment";

const reducer = (state, action) => {
    if (action.type === "LOAD_COMPANIES") {
        const companies = action.payload;
        const newCompanies = [];

        companies.forEach((company) => {
            const companyIndex = state.findIndex((u) => u.id === company.id);
            if (companyIndex !== -1) {
                state[companyIndex] = company;
            } else {
                newCompanies.push(company);
            }
        });

        return [...state, ...newCompanies];
    }

    if (action.type === "UPDATE_COMPANIES") {
        const company = action.payload;
        const companyIndex = state.findIndex((u) => u.id === company.id);

        if (companyIndex !== -1) {
            state[companyIndex] = company;
            return [...state];
        } else {
            return [company, ...state];
        }
    }

    if (action.type === "DELETE_COMPANIES") {
        const companyId = action.payload;

        const companyIndex = state.findIndex((u) => u.id === companyId);
        if (companyIndex !== -1) {
            state.splice(companyIndex, 1);
        }
        return [...state];
    }

    if (action.type === "RESET") {
        return [];
    }
};

const useStyles = makeStyles((theme) => ({
    root: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        width: "100%",
        maxWidth: "100%",
    },
    mainPaper: {
        flex: 1,
        borderRadius: 20,
        display: "flex",
        flexDirection: "column",
        width: "100%",
        maxWidth: "100%",
        minWidth: 0,
        boxSizing: "border-box",
        height: "calc(100vh - 200px)",
        boxShadow: theme.palette.mode === "dark" 
          ? "0 4px 20px rgba(0, 0, 0, 0.5), 0 2px 12px rgba(0, 0, 0, 0.3)" 
          : "0 4px 20px rgba(0, 0, 0, 0.08), 0 2px 12px rgba(0, 0, 0, 0.04)",
        [theme.breakpoints.down('md')]: {
            height: "calc(100vh - 150px)",
        },
        [theme.breakpoints.down('sm')]: {
            height: "calc(100vh - 120px)",
            borderRadius: 12,
        },
    },
    tableContainer: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        width: 0,
        minWidth: "100%",
        overflow: "hidden",
        position: "relative",
        borderRadius: 20,
        [theme.breakpoints.down('sm')]: {
            borderRadius: 12,
        },
    },
    tableWrapper: {
        flex: 1,
        width: 0,
        minWidth: "100%",
        overflowX: "auto",
        overflowY: "auto",
        position: "relative",
        WebkitOverflowScrolling: "touch",
        borderRadius: 20,
        // Scrollbar horizontal sempre visível
        "&::-webkit-scrollbar": {
            height: "14px",
            width: "14px",
            backgroundColor: "transparent",
        },
        "&::-webkit-scrollbar-track": {
            background: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.05)",
            borderRadius: 20,
            margin: "0",
        },
        "&::-webkit-scrollbar-track:horizontal": {
            borderRadius: "0 0 20px 20px",
            margin: "0 0 2px 0",
        },
        "&::-webkit-scrollbar-track:vertical": {
            borderRadius: "0 20px 20px 0",
            margin: "0 2px 0 0",
        },
        "&::-webkit-scrollbar-thumb": {
            background: theme.palette.mode === "dark" 
                ? "linear-gradient(180deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.25))" 
                : "linear-gradient(180deg, rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.25))",
            borderRadius: "10px",
            border: `3px solid ${theme.palette.mode === "dark" ? theme.palette.background.paper : "#fff"}`,
            "&:hover": {
                background: theme.palette.mode === "dark" 
                    ? "linear-gradient(180deg, rgba(255, 255, 255, 0.4), rgba(255, 255, 255, 0.35))" 
                    : "linear-gradient(180deg, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.35))",
            },
            "&:active": {
                background: theme.palette.mode === "dark" 
                    ? "rgba(255, 255, 255, 0.5)" 
                    : "rgba(0, 0, 0, 0.5)",
            },
        },
        "&::-webkit-scrollbar-corner": {
            background: "transparent",
            borderRadius: "0 0 20px 0",
        },
        // Firefox scrollbar
        scrollbarWidth: "auto",
        scrollbarColor: theme.palette.mode === "dark" 
            ? "rgba(255, 255, 255, 0.3) rgba(255, 255, 255, 0.05)"
            : "rgba(0, 0, 0, 0.3) rgba(0, 0, 0, 0.05)",
        [theme.breakpoints.down('sm')]: {
            borderRadius: 12,
            "&::-webkit-scrollbar-track:horizontal": {
                borderRadius: "0 0 12px 12px",
            },
            "&::-webkit-scrollbar-track:vertical": {
                borderRadius: "0 12px 12px 0",
            },
            "&::-webkit-scrollbar-corner": {
                borderRadius: "0 0 12px 0",
            },
        },
    },
    table: {
        minWidth: "2000px",
        width: "2000px",
        tableLayout: "fixed",
        borderCollapse: "separate",
        borderSpacing: 0,
        "& .MuiTableHead-root": {
            backgroundColor: theme.palette.background.default,
            position: "sticky",
            top: 0,
            zIndex: 10,
        },
        "& .MuiTableCell-head": {
            fontWeight: 700,
            fontSize: "0.85rem",
            color: theme.palette.text.primary,
            borderBottom: `2px solid ${theme.palette.divider}`,
            padding: "16px 12px",
            whiteSpace: "nowrap",
            backgroundColor: theme.palette.background.default,
            minWidth: "120px",
            [theme.breakpoints.down('lg')]: {
                fontSize: "0.78rem",
                padding: "12px 8px",
                minWidth: "100px",
            },
            [theme.breakpoints.down('md')]: {
                fontSize: "0.72rem",
                padding: "10px 6px",
                minWidth: "90px",
            },
            [theme.breakpoints.down('sm')]: {
                fontSize: "0.65rem",
                padding: "8px 4px",
                minWidth: "80px",
            },
        },
        "& .MuiTableRow-root": {
            transition: "all 0.2s ease",
            "&:hover": {
                backgroundColor: theme.palette.mode === "dark" ? "rgba(255, 255, 255, 0.03)" : "rgba(0, 0, 0, 0.02)",
            },
        },
        "& .MuiTableCell-body": {
            fontSize: "0.82rem",
            color: theme.palette.text.secondary,
            borderBottom: theme.palette.mode === "dark" ? "1px solid rgba(255, 255, 255, 0.05)" : "1px solid rgba(0, 0, 0, 0.08)",
            padding: "12px 8px",
            whiteSpace: "nowrap",
            minWidth: "120px",
            [theme.breakpoints.down('lg')]: {
                fontSize: "0.76rem",
                padding: "10px 6px",
                minWidth: "100px",
            },
            [theme.breakpoints.down('md')]: {
                fontSize: "0.70rem",
                padding: "8px 4px",
                minWidth: "90px",
            },
            [theme.breakpoints.down('sm')]: {
                fontSize: "0.64rem",
                padding: "6px 3px",
                minWidth: "80px",
            },
        },
    },
}));

const Companies = () => {
    const classes = useStyles();
    const theme = useTheme();
    const history = useHistory();

    const [loading, setLoading] = useState(false);
    const [pageNumber, setPageNumber] = useState(1);
    const [hasMore, setHasMore] = useState(false);
    const [selectedCompany, setSelectedCompany] = useState(null);
    const [deletingCompany, setDeletingCompany] = useState(null);
    const [companyModalOpen, setCompanyModalOpen] = useState(false);
    const [confirmModalOpen, setConfirmModalOpen] = useState(false);
    const [searchParam, setSearchParam] = useState("");
    const [companies, dispatch] = useReducer(reducer, []);
    const { dateToClient, datetimeToClient } = useDate();

    // const { getPlanCompany } = usePlans();
  //   const socketManager = useContext(SocketContext);
    const { user, socket } = useContext(AuthContext);


    useEffect(() => {
        async function fetchData() {
            if (!user.super) {
                toast.error("Esta empresa não possui permissão para acessar essa página! Estamos lhe redirecionando.");
                setTimeout(() => {
                    history.push(`/`)
                }, 1000);
            }
        }
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        dispatch({ type: "RESET" });
        setPageNumber(1);
    }, [searchParam]);

    useEffect(() => {
        setLoading(true);
        const delayDebounceFn = setTimeout(() => {
            const fetchCompanies = async () => {
                try {
                    const { data } = await api.get("/companiesPlan/", {
                        params: { searchParam, pageNumber },
                    });
                    dispatch({ type: "LOAD_COMPANIES", payload: data.companies });
                    setHasMore(data.hasMore);
                    setLoading(false);
                } catch (err) {
                    toastError(err);
                }
            };
            fetchCompanies();
        }, 500);
        return () => clearTimeout(delayDebounceFn);
    }, [searchParam, pageNumber]);

//     useEffect(() => {
//         const companyId = user.companyId;
//   //    const socket = socketManager.GetSocket();
//         // const socket = socketConnection();

//         return () => {
//             socket.disconnect();
//         };
//     }, []);

    const handleOpenCompanyModal = () => {
        setSelectedCompany(null);
        setCompanyModalOpen(true);
    };

    const handleCloseCompanyModal = () => {
        setSelectedCompany(null);
        setCompanyModalOpen(false);
    };

    const handleSearch = (event) => {
        setSearchParam(event.target.value.toLowerCase());
    };

    const handleEditCompany = (company) => {
        setSelectedCompany(company);
        setCompanyModalOpen(true);
    };

    const handleDeleteCompany = async (companyId) => {
        try {
            await api.delete(`/companies/${companyId}`);
            toast.success(i18n.t("compaies.toasts.deleted"));
        } catch (err) {
            toastError(err);
        }
        setDeletingCompany(null);
        setSearchParam("");
        setPageNumber(1);
    };

    const loadMore = () => {
        setPageNumber((prevState) => prevState + 1);
    };

    const handleScroll = (e) => {
        if (!hasMore || loading) return;
        const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
        if (scrollHeight - (scrollTop + 100) < clientHeight) {
            loadMore();
        }
    };

    const renderStatus = (row) => {
        return row.status === false ? "Não" : "Sim";
    };

    const renderPlanValue = (row) => {
        return row.planId !== null ? row.plan.amount ? row.plan.amount.toLocaleString('pt-br', { minimumFractionDigits: 2 }) : '00.00' : "-";
    };

    const renderWhatsapp = (row) => {
        return row.useWhatsapp === false ? "Não" : "Sim";
    };

    const renderFacebook = (row) => {
        return row.useFacebook === false ? "Não" : "Sim";
    };

    const renderInstagram = (row) => {
        return row.useInstagram === false ? "Não" : "Sim";
    };

    const renderCampaigns = (row) => {
        return row.useCampaigns === false ? "Não" : "Sim";
    };

    const renderSchedules = (row) => {
        return row.useSchedules === false ? "Não" : "Sim";
    };

    const renderInternalChat = (row) => {
        return row.useInternalChat === false ? "Não" : "Sim";
    };

    const renderExternalApi = (row) => {
        return row.useExternalApi === false ? "Não" : "Sim";
    };

    const rowStyle = (record) => {
        if (moment(record.dueDate).isValid()) {
            const now = moment();
            const dueDate = moment(record.dueDate);
            const diff = dueDate.diff(now, "days");
            const isDark = theme.palette.mode === "dark";
            
            // Vencimento próximo (1-5 dias) - Amarelo suave
            if (diff >= 1 && diff <= 5) {
                return { 
                    backgroundColor: isDark ? "rgba(255, 193, 7, 0.15)" : "rgba(255, 193, 7, 0.15)",
                    color: isDark ? "rgba(255, 255, 255, 0.95)" : "rgba(0, 0, 0, 0.87)"
                };
            }
            
            // Vencido - Vermelho suave
            if (diff <= 0) {
                return { 
                    backgroundColor: isDark ? "rgba(244, 67, 54, 0.2)" : "rgba(244, 67, 54, 0.15)",
                    color: isDark ? "rgba(255, 255, 255, 0.95)" : "rgba(0, 0, 0, 0.87)"
                };
            }
            // else {
            //   return { backgroundColor: "#affa8c" };
            // }
        }
        return {};
    };

    return (
        <MainContainer className={classes.root}>
            <ConfirmationModal
                title={
                    deletingCompany &&
                    `${i18n.t("compaies.confirmationModal.deleteTitle")} ${deletingCompany.name}?`
                }
                open={confirmModalOpen}
                onClose={setConfirmModalOpen}
                onConfirm={() => handleDeleteCompany(deletingCompany.id)}
            >
                {i18n.t("compaies.confirmationModal.deleteMessage")}
            </ConfirmationModal>
            <CompanyModal
                open={companyModalOpen}
                onClose={handleCloseCompanyModal}
                aria-labelledby="form-dialog-title"
                companyId={selectedCompany && selectedCompany.id}
            />
            <MainHeader>
                <Title>{i18n.t("compaies.title")} ({companies.length})</Title>
            </MainHeader>
            <Paper
                className={classes.mainPaper}
                elevation={1}
            >
                <Box className={classes.tableContainer}>
                    <div className={classes.tableWrapper} onScroll={handleScroll}>
                        <Table size="small" className={classes.table}>
                        <TableHead>
                            <TableRow>
                            <TableCell align="center">
                                <Tooltip title="ID da empresa">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <FingerprintIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.ID")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Status da empresa">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <CheckCircleIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.status")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Nome da empresa">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <BusinessIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.name")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Email da empresa">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <EmailIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.email")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Nome do plano">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <CardMembershipIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.namePlan")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Valor do plano">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <AttachMoneyIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.value")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Data de criação">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <EventIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.createdAt")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Data de vencimento">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <DateRangeIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.dueDate")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Último login">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <AccessTimeIcon fontSize="small" style={{ marginRight: 8 }} />
                                        {i18n.t("compaies.table.lastLogin")}
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Tamanho da pasta">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <FolderIcon fontSize="small" style={{ marginRight: 8 }} />
                                        Tamanho da pasta
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Total de arquivos">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <DescriptionIcon fontSize="small" style={{ marginRight: 8 }} />
                                        Total de arquivos
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            <TableCell align="center">
                                <Tooltip title="Última atualização">
                                    <Box display="flex" alignItems="center" justifyContent="center">
                                        <UpdateIcon fontSize="small" style={{ marginRight: 8 }} />
                                        Ultimo update
                                    </Box>
                                </Tooltip>
                            </TableCell>
                            {/* <TableCell align="center">{i18n.t("compaies.table.numberAttendants")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.numberConections")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.numberQueues")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useWhatsapp")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useFacebook")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useInstagram")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useCampaigns")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useExternalApi")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useInternalChat")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.useSchedules")}</TableCell> */}
                            {/* <TableCell align="center">{i18n.t("compaies.table.actions")}</TableCell> */}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <>
                            {companies.map((company) => (
                                <TableRow style={rowStyle(company)} key={company.id}>
                                    <TableCell align="center">{company.id}</TableCell>
                                    <TableCell align="center">{renderStatus(company.status)}</TableCell>
                                    <TableCell align="center">{company.name}</TableCell>
                                    <TableCell align="center">{company.email}</TableCell>
                                    <TableCell align="center">{company?.plan?.name}</TableCell>
                                    <TableCell align="center">R$ {renderPlanValue(company)}</TableCell>
                                    <TableCell align="center">{dateToClient(company.createdAt)}</TableCell>
                                    <TableCell align="center">{dateToClient(company.dueDate)}<br /><span>{company.recurrence}</span></TableCell>
                                    <TableCell align="center">{datetimeToClient(company.lastLogin)}</TableCell>
                                    <TableCell align="center">{company.folderSize}</TableCell>
                                    <TableCell align="center">{company.numberFileFolder}</TableCell>
                                    <TableCell align="center">{datetimeToClient(company.updatedAtFolder)}</TableCell>
                                    {/* <TableCell align="center">{company.plan.users}</TableCell> */}
                                    {/* <TableCell align="center">{company.plan.connections}</TableCell> */}
                                    {/* <TableCell align="center">{company.plan.queues}</TableCell> */}
                                    {/* <TableCell align="center">{renderWhatsapp(company.plan.useWhatsapp)}</TableCell> */}
                                    {/* <TableCell align="center">{renderFacebook(company.plan.useFacebook)}</TableCell> */}
                                    {/* <TableCell align="center">{renderInstagram(company.plan.useInstagram)}</TableCell> */}
                                    {/* <TableCell align="center">{renderCampaigns(company.plan.useCampaigns)}</TableCell> */}
                                    {/* <TableCell align="center">{renderExternalApi(company.plan.useExternalApi)}</TableCell> */}
                                    {/* <TableCell align="center">{renderInternalChat(company.plan.useInternalChat)}</TableCell> */}
                                    {/* <TableCell align="center">{renderSchedules(company.plan.useSchedules)}</TableCell> */}
                                    {/* <TableCell align="center">
                                        <IconButton
                                            size="small"
                                            onClick={() => handleEditCompany(company)}
                                        >
                                            <EditIcon />
                                        </IconButton>

                                        <IconButton
                                            size="small"
                                            onClick={(e) => {
                                                setConfirmModalOpen(true);
                                                setDeletingCompany(company);
                                            }}
                                        >
                                            <DeleteOutlineIcon />
                                        </IconButton>
                                    </TableCell> */}
                                </TableRow>
                            ))}
                            {loading && <TableRowSkeleton columns={4} />}
                        </>
                    </TableBody>
                </Table>
                    </div>
                </Box>
            </Paper>
        </MainContainer>
    );
};

export default Companies;
