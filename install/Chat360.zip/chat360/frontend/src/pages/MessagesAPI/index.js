import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";

import { i18n } from "../../translate/i18n";
import { Button, CircularProgress, Grid, TextField, Typography, Box, Divider } from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import toastError from "../../errors/toastError";
import { toast } from "react-toastify";
import { Code as CodeIcon, Send as SendIcon } from "@material-ui/icons";

import axios from "axios";
import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
  mainPaper: {
    borderRadius: 20,
    overflow: "hidden",
    boxShadow: theme.palette.mode === "dark"
      ? "0 8px 32px rgba(0, 0, 0, 0.6)"
      : "0 8px 32px rgba(0, 0, 0, 0.15)",
  },
  contentWrapper: {
    padding: theme.spacing(4),
    overflowY: "auto",
    maxHeight: "calc(100vh - 180px)",
    ...theme.scrollbarStyles,
  },
  sectionTitle: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1.5),
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(2),
    "& svg": {
      color: theme.palette.primary.main,
      fontSize: "1.5rem",
    },
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(3),
  },
  elementMargin: {
    marginBottom: theme.spacing(2),
  },
  formContainer: {
    maxWidth: 500,
    padding: theme.spacing(2),
    borderRadius: 12,
    backgroundColor: theme.palette.mode === "dark"
      ? "rgba(255, 255, 255, 0.05)"
      : "rgba(0, 0, 0, 0.02)",
    border: `1px solid ${theme.palette.divider}`,
  },
  textField: {
    "& .MuiOutlinedInput-root": {
      borderRadius: 8,
    },
  },
  sendButton: {
    borderRadius: 8,
    padding: "8px 24px",
    textTransform: "none",
    fontWeight: 600,
  },
  codeBlock: {
    backgroundColor: theme.palette.mode === "dark"
      ? "rgba(255, 255, 255, 0.05)"
      : "rgba(0, 0, 0, 0.02)",
    padding: theme.spacing(2),
    borderRadius: 8,
    border: `1px solid ${theme.palette.divider}`,
    fontFamily: "monospace",
    fontSize: "0.875rem",
    overflowX: "auto",
  },
  textRight: {
    textAlign: "right"
  }
}));

const MessagesAPI = () => {
  const classes = useStyles();
  const history = useHistory();

  const [formMessageTextData,] = useState({ token: '', number: '', body: '', userId: '', queueId: '' })
  const [formMessageMediaData,] = useState({ token: '', number: '', medias: '', body:'', userId: '', queueId: '' })
  const [file, setFile] = useState({})
  const { user, socket } = useContext(AuthContext);

  const { getPlanCompany } = usePlans();

  useEffect(() => {
    async function fetchData() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("Esta empresa não possui permissão para acessar essa página! Estamos lhe redirecionando.");
        setTimeout(() => {
          history.push(`/`)
        }, 1000);
      }
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getEndpoint = () => {
    return process.env.REACT_APP_BACKEND_URL + '/api/messages/send'
  }

  const handleSendTextMessage = async (values) => {
    const { number, body, userId, queueId } = values;
    const data = { number, body, userId, queueId };
    try {
      await axios.request({
        url: getEndpoint(),
        method: 'POST',
        data,
        headers: {
          'Content-type': 'application/json',
          'Authorization': `Bearer ${values.token}` 
        }
      })
      toast.success('Mensagem enviada com sucesso');
    } catch (err) {
      toastError(err);
    }
  }

  const handleSendMediaMessage = async (values) => {
    try {
      const firstFile = file[0];
      const data = new FormData();
      data.append('number', values.number);
      data.append('body', values.body ? values.body: firstFile.name);
      data.append('userId', values.userId);
      data.append('queueId', values.queueId);
      data.append('medias', firstFile);
      await axios.request({
        url: getEndpoint(),
        method: 'POST',
        data,
        headers: {
          'Content-type': 'multipart/form-data',
          'Authorization': `Bearer ${values.token}`
        }
      })
      toast.success('Mensagem enviada com sucesso');
    } catch (err) {
      toastError(err);
    }
  }

  const renderFormMessageText = () => {
    return (
      <Formik
        initialValues={formMessageTextData}
        enableReinitialize={true}
        onSubmit={(values, actions) => {
          setTimeout(async () => {
            await handleSendTextMessage(values);
            actions.setSubmitting(false);
            actions.resetForm()
          }, 400);
        }}
        className={classes.elementMargin}
      >
        {({ isSubmitting }) => (
          <Form className={classes.formContainer}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.token")}
                  name="token"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.number")}
                  name="number"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.body")}
                  name="body"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.userId")}
                  name="userId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.queueId")}
                  name="queueId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12} className={classes.textRight}>
                <Button
                  type="submit"
                  color="primary"
                  variant="contained"
                  className={classes.sendButton}
                  startIcon={!isSubmitting && <SendIcon />}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? <CircularProgress size={24} /> : 'Enviar'}
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    )
  }

  const renderFormMessageMedia = () => {
    return (
      <Formik
        initialValues={formMessageMediaData}
        enableReinitialize={true}
        onSubmit={(values, actions) => {
          setTimeout(async () => {
            await handleSendMediaMessage(values);
            actions.setSubmitting(false);
            actions.resetForm()
            document.getElementById('medias').files = null
            document.getElementById('medias').value = null
          }, 400);
        }}
        className={classes.elementMargin}
      >
        {({ isSubmitting }) => (
          <Form className={classes.formContainer}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.mediaMessage.token")}
                  name="token"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.mediaMessage.number")}
                  name="number"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.body")}
                  name="body"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.userId")}
                  name="userId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.queueId")}
                  name="queueId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}>
                <input type="file" name="medias" id="medias" required onChange={(e) => setFile(e.target.files)} />
              </Grid>
              <Grid item xs={12} className={classes.textRight}>
                <Button
                  type="submit"
                  color="primary"
                  variant="contained"
                  className={classes.sendButton}
                  startIcon={!isSubmitting && <SendIcon />}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? <CircularProgress size={24} /> : 'Enviar'}
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    )
  }

  return (
    <MainContainer className={classes.root}>
      <MainHeader>
        <Title>{i18n.t("messagesAPI.API.title")}</Title>
      </MainHeader>
      <Paper className={classes.mainPaper}>
        <Box className={classes.contentWrapper}>
          <Box className={classes.sectionTitle}>
            <CodeIcon />
            <Typography variant="h6" style={{ fontWeight: 600 }}>
              {i18n.t("messagesAPI.API.methods.title")}
            </Typography>
          </Box>
        <Typography component="div" className={classes.elementMargin}>
          <ol>
            <li>{i18n.t("messagesAPI.API.methods.messagesText")}</li>
            <li>{i18n.t("messagesAPI.API.methods.messagesMidia")}</li>
          </ol>
        </Typography>

        <Divider className={classes.divider} />

        <Box className={classes.sectionTitle}>
          <CodeIcon />
          <Typography variant="h6" style={{ fontWeight: 600 }}>
            {i18n.t("messagesAPI.API.instructions.title")}
          </Typography>
        </Box>
        <Typography className={classes.elementMargin} component="div">
        <b>{i18n.t("messagesAPI.API.instructions.comments")}</b><br />
        <ul>
          <li>{i18n.t("messagesAPI.API.instructions.comments1")}</li>
          <li>
          {i18n.t("messagesAPI.API.instructions.comments2")}
            <ul>
              <li>{i18n.t("messagesAPI.API.instructions.codeCountry")}</li>
              <li>{i18n.t("messagesAPI.API.instructions.code")}</li>
              <li>{i18n.t("messagesAPI.API.instructions.number")}</li>
            </ul>
          </li>
        </ul>
        </Typography>

        <Divider className={classes.divider} />

        <Box className={classes.sectionTitle}>
          <SendIcon />
          <Typography variant="h6" style={{ fontWeight: 600 }}>
            {i18n.t("messagesAPI.API.text.title")}
          </Typography>
        </Box>
        <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Box className={classes.elementMargin}>
            <Typography variant="body2" paragraph>
              {i18n.t("messagesAPI.API.text.instructions")}
            </Typography>
            <Box className={classes.codeBlock}>
              <div><b>Endpoint:</b> {getEndpoint()}</div>
              <div><b>Método:</b> POST</div>
              <div><b>Headers:</b> Authorization Bearer (token) e Content-Type (application/json)</div>
              <br />
              <div><b>Body:</b></div>
              <div>{"{"}</div>
              <div>&nbsp;&nbsp;"number": "558599999999"</div>
              <div>&nbsp;&nbsp;"body": "Message"</div>
              <div>&nbsp;&nbsp;"userId": "ID usuário ou empty"</div>
              <div>&nbsp;&nbsp;"queueId": "ID Fila ou empty"</div>
              <div>&nbsp;&nbsp;"sendSignature": true/false</div>
              <div>&nbsp;&nbsp;"closeTicket": true/false</div>
              <div>{"}"}</div>
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography className={classes.elementMargin}>
            <b>Teste de Envio</b>
          </Typography>
          {renderFormMessageText()}
        </Grid>
        </Grid>

        <Divider className={classes.divider} />

        <Box className={classes.sectionTitle}>
          <SendIcon />
          <Typography variant="h6" style={{ fontWeight: 600 }}>
            {i18n.t("messagesAPI.API.media.title")}
          </Typography>
        </Box>
        <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Box className={classes.elementMargin}>
            <Typography variant="body2" paragraph>
              {i18n.t("messagesAPI.API.media.instructions")}
            </Typography>
            <Box className={classes.codeBlock}>
              <div><b>Endpoint:</b> {getEndpoint()}</div>
              <div><b>Método:</b> POST</div>
              <div><b>Headers:</b> Authorization Bearer (token) e Content-Type (multipart/form-data)</div>
              <br />
              <div><b>FormData:</b></div>
              <div>&nbsp;&nbsp;• <b>number:</b> 558599999999</div>
              <div>&nbsp;&nbsp;• <b>body:</b> Message</div>
              <div>&nbsp;&nbsp;• <b>userId:</b> ID usuário ou empty</div>
              <div>&nbsp;&nbsp;• <b>queueId:</b> ID da fila ou empty</div>
              <div>&nbsp;&nbsp;• <b>medias:</b> arquivo</div>
              <div>&nbsp;&nbsp;• <b>sendSignature:</b> true/false</div>
              <div>&nbsp;&nbsp;• <b>closeTicket:</b> true/false</div>
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography className={classes.elementMargin}>
            <b>Teste de Envio</b>
          </Typography>
          {renderFormMessageMedia()}
        </Grid>
        </Grid>
        </Box>
      </Paper>
    </MainContainer>
  );
};

export default MessagesAPI;