import React from "react";
import { useParams } from "react-router-dom";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import { makeStyles } from "@material-ui/core/styles";

import TicketsManagerTabs from "../../components/TicketsManagerTabs";
import Ticket from "../../components/Ticket";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";

import { i18n } from "../../translate/i18n";

const useStyles = makeStyles(theme => ({
	root: {
		padding: theme.spacing(2),
		display: "flex",
		flexDirection: "column",
		height: "100%",
	},

	mainPaper: {
		width: '100%',
		borderRadius: 20,
		overflow: "hidden",
		boxShadow: theme.palette.mode === "dark"
			? "0 4px 20px rgba(0, 0, 0, 0.5)"
			: "0 4px 20px rgba(0, 0, 0, 0.08)",
		display: "flex",
		flex: 1,
		minHeight: 0,
	},

	gridContainer: {
		flex: 1,
		height: "100%",
		backgroundColor: theme.palette.background.default,
		padding: theme.spacing(2),
	},

	contactsWrapper: {
		display: "flex",
		height: "100%",
		flexDirection: "column",
		overflowY: "hidden",
		borderRight: `1px solid ${theme.palette.divider}`,
		marginRight: theme.spacing(1),
	},

	messagessWrapper: {
		display: "flex",
		height: "100%",
		flexDirection: "column",
		backgroundColor: theme.palette.background.paper,
		borderRadius: 12,
		overflow: "hidden",
	},

	welcomeMsg: {
		background: theme.palette.background.paper,
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		height: "100%",
		textAlign: "center",
		flexDirection: "column",
		padding: theme.spacing(2),
		boxSizing: "border-box",
	},

	welcomeContent: {
		padding: theme.spacing(4),
		borderRadius: 12,
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		textAlign: "center",
		flexDirection: "column",
		color: theme.palette.mode === "dark" ? "#1d293b" : theme.palette.text.secondary,
		border: `1px solid ${theme.palette.divider}`,
		backgroundColor: theme.palette.mode === "light" ? "#f5f7fa" : theme.palette.background.default,
		maxWidth: "90%",
		width: "100%",
	},

	welcomeText: {
		color: "inherit",
		fontSize: "1.1rem",
		marginTop: theme.spacing(2),
	},

	logo: {
		maxWidth: "50%",
		height: "auto",
		opacity: 0.6,
		filter: theme.palette.mode === "dark" ? "brightness(0.8)" : "brightness(1)",
	},

	welcomeIcon: {
		opacity: 0.2,
		color: "inherit",
	},
}));

const Tickets = () => {
	const classes = useStyles();
	const { ticketId } = useParams();

	return (
		<MainContainer className={classes.root}>
			<MainHeader>
				<Title>{i18n.t("tickets.title")}</Title>
			</MainHeader>
			<Paper className={classes.mainPaper} elevation={0}>
				<Grid container spacing={0} className={classes.gridContainer}>
					<Grid item xs={12} md={4} className={classes.contactsWrapper}>
						<TicketsManagerTabs />
					</Grid>
					<Grid item xs={12} md={8} className={classes.messagessWrapper}>
						{ticketId ? (
							<Ticket />
						) : (
							<div className={classes.welcomeMsg}>
								<Paper variant="outlined" className={classes.welcomeContent}>
									<svg
										width="120"
										height="120"
										viewBox="0 0 24 24"
										fill="none"
										xmlns="http://www.w3.org/2000/svg"
										className={classes.welcomeIcon}
									>
										<path
											d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H6L4 18V4H20V16Z"
											fill="currentColor"
										/>
										<path
											d="M7 9H17V11H7V9ZM7 12H14V14H7V12Z"
											fill="currentColor"
										/>
									</svg>
									<span className={classes.welcomeText}>
										{i18n.t("chat.noTicketMessage")}
									</span>
								</Paper>
							</div>
						)}
					</Grid>
				</Grid>
			</Paper>
		</MainContainer>
	);
};

export default Tickets;
