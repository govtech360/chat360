import React, { useState, useCallback, useContext, useEffect, useRef } from "react";
import { useParams, useHistory } from "react-router-dom";
import Paper from "@material-ui/core/Paper";
import Hidden from "@material-ui/core/Hidden";
import { makeStyles } from "@material-ui/core/styles";
import TicketsManager from "../../components/TicketsManagerTabs";
import Ticket from "../../components/Ticket";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";

import { QueueSelectedProvider } from "../../context/QueuesSelected/QueuesSelectedContext";
import { TicketsContext } from "../../context/Tickets/TicketsContext";
import { i18n } from "../../translate/i18n";
import { AuthContext } from "../../context/Auth/AuthContext";
import api from "../../services/api";
import { CircularProgress } from "@material-ui/core";
import { getBackendUrl } from "../../config";
import logo from "../../assets/logo.png";
import logoDark from "../../assets/logo-black.png";

const defaultTicketsManagerWidth = 550;
const minTicketsManagerWidth = 404;
const maxTicketsManagerWidth = 700;

const useStyles = makeStyles((theme) => ({
	mainWrapper: {
		display: "flex",
		flexDirection: "column",
		minHeight: "calc(100vh - 100px)",
		height: "100%",
	},
	mainPaper: {
		width: '100%',
		borderRadius: 20,
		overflow: "hidden",
		boxShadow: theme.palette.mode === "dark"
			? "0 4px 20px rgba(0, 0, 0, 0.5)"
			: "0 4px 20px rgba(0, 0, 0, 0.08)",
		display: "flex",
		flex: 1,
		minHeight: "calc(100vh - 180px)",
	},
	chatContainer: {
		flex: 1,
		width: "100%",
		display: "flex",
		flexDirection: "column",
	},
	chatPapper: {
		display: "flex",
		height: "100%",
		flex: 1,
		width: "100%",
	},
	contactsWrapper: {
		display: "flex",
		height: "100%",
		flexDirection: "column",
		overflow: "hidden",
		position: "relative",
		borderRight: `1px solid ${theme.palette.divider}`,
		backgroundColor: theme.palette.background.default,
	},
	messagesWrapper: {
		display: "flex",
		height: "100%",
		flexDirection: "column",
		flex: 1,
		backgroundColor: theme.palette.background.paper,
	},
	welcomeMsg: {
		backgroundColor: theme.palette.background.paper,
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		height: "100%",
		width: "100%",
		textAlign: "center",
		padding: theme.spacing(2),
	},
	dragger: {
		width: "6px",
		cursor: "ew-resize",
		position: "absolute",
		top: 0,
		right: -3,
		bottom: 0,
		zIndex: 100,
		backgroundColor: theme.palette.mode === "dark" 
			? "rgba(255, 255, 255, 0.1)" 
			: "rgba(0, 0, 0, 0.08)",
		transition: "all 0.2s ease",
		"&:hover": {
			backgroundColor: theme.palette.primary.main,
			width: "8px",
			right: -4,
		},
		userSelect: "none",
	},
	logo: {
		logo: theme.logo,
		content: "url(" + (theme.mode === "light" ? theme.calculatedLogoLight() : theme.calculatedLogoDark()) + ")",
		maxWidth: "450px",
		maxHeight: "220px",
		width: "100%",
		height: "auto",
		objectFit: "contain",
		display: "block",
		margin: "0 auto",
	},
	welcomeMsgText: {
		color: theme.palette.text.secondary,
		fontSize: "1.15rem",
		marginTop: theme.spacing(3),
		fontWeight: 400,
	},
	welcomeMsgContainer: {
		width: "100%",
		height: "100%",
		padding: theme.spacing(4),
		borderRadius: 16,
		backgroundColor: theme.palette.background.default,
		border: `1px solid ${theme.palette.divider}`,
		display: "flex",
		flexDirection: "column",
		justifyContent: "center",
		alignItems: "center",
	},
}));

const TicketsCustom = () => {
	const { user } = useContext(AuthContext);

	const classes = useStyles({ ticketsManagerWidth: user.defaultTicketsManagerWidth || defaultTicketsManagerWidth });

	const { ticketId } = useParams();

	const [ticketsManagerWidth, setTicketsManagerWidth] = useState(0);
	const ticketsManagerWidthRef = useRef(ticketsManagerWidth);

	useEffect(() => {
		if (user && user.defaultTicketsManagerWidth) {
			setTicketsManagerWidth(user.defaultTicketsManagerWidth);
		}
	}, [user]);

	// useEffect(() => {
	// 	if (ticketId && currentTicket.uuid === undefined) {
	// 		history.push("/tickets");
	// 	}
	// }, [ticketId, currentTicket.uuid, history]);

	const handleMouseDown = (e) => {
		document.addEventListener("mouseup", handleMouseUp, true);
		document.addEventListener("mousemove", handleMouseMove, true);
	};
	const handleSaveContact = async value => {
		if (value < 404)
			value = 404
		await api.put(`/users/toggleChangeWidht/${user.id}`, { defaultTicketsManagerWidth: value });

	}
	const handleMouseMove = useCallback(
		(e) => {
			const newWidth = e.clientX - document.body.offsetLeft;
			if (
				newWidth > minTicketsManagerWidth &&
				newWidth < maxTicketsManagerWidth
			) {
				ticketsManagerWidthRef.current = newWidth;
				setTicketsManagerWidth(newWidth);
			}
		},
		[]
	);

	const handleMouseUp = async () => {
		document.removeEventListener("mouseup", handleMouseUp, true);
		document.removeEventListener("mousemove", handleMouseMove, true);

		const newWidth = ticketsManagerWidthRef.current;

		if (newWidth !== ticketsManagerWidth) {
			await handleSaveContact(newWidth);
		}
	};

	return (
		<MainContainer>
			<div className={classes.mainWrapper}>
				<MainHeader>
					<Title>{i18n.t("tickets.title")}</Title>
				</MainHeader>
				<Paper className={classes.mainPaper} elevation={0}>
					<QueueSelectedProvider>
						<div className={classes.chatContainer}>
							<div className={classes.chatPapper}>
								<div
									className={classes.contactsWrapper}
									style={{ width: ticketsManagerWidth }}
								>
									<TicketsManager />
									<div onMouseDown={e => handleMouseDown(e)} className={classes.dragger} />
								</div>
								<div className={classes.messagesWrapper}>
									{ticketId ? (
										<>
											<Ticket />
										</>
									) : (
									<Hidden only={["sm", "xs"]}>
										<div className={classes.welcomeMsg}>
											<Paper variant="outlined" className={classes.welcomeMsgContainer} elevation={0}>
												<img className={classes.logo} alt="" />
												<div className={classes.welcomeMsgText}>
													{i18n.t("chat.noTicketMessage")}
												</div>
											</Paper>
										</div>
									</Hidden>
									)}
								</div>
							</div>
						</div>
					</QueueSelectedProvider>
				</Paper>
			</div>
		</MainContainer>
	);
};

export default TicketsCustom;