import { toast } from "react-toastify";
import { i18n } from "../translate/i18n";
import { isString } from 'lodash';

/**
 * Configuração padrão para toasts de erro
 */
const errorToastConfig = {
	autoClose: 4000,
	hideProgressBar: false,
	closeOnClick: true,
	pauseOnHover: true,
	draggable: true,
	progress: undefined,
};

/**
 * Exibe uma mensagem de erro com tratamento inteligente
 * @param {Error|string} err - Erro a ser exibido
 * @param {object} customConfig - Configurações customizadas para o toast
 */
const toastError = (err, customConfig = {}) => {
	// Extrai a mensagem de erro
	const errorMsg = err.response?.data?.error;
	
	if (errorMsg) {
		// Verifica se existe tradução para o erro
		if (i18n.exists(`backendErrors.${errorMsg}`)) {
			toast.error(i18n.t(`backendErrors.${errorMsg}`), {
				...errorToastConfig,
				...customConfig,
				toastId: errorMsg,
			});
			return;
		} else {
			// Exibe o erro original se não houver tradução
			toast.error(errorMsg, {
				...errorToastConfig,
				...customConfig,
				toastId: errorMsg,
			});
			return;
		}
	} 
	
	// Trata erros que são strings
	if (isString(err)) {
		toast.error(err, {
			...errorToastConfig,
			...customConfig,
			toastId: `error-${Date.now()}`,
		});
		return;
	} 
	
	// Mensagem genérica para erros não tratados
	const defaultMessage = i18n.exists("errors.generic") 
		? i18n.t("errors.generic") 
		: "Ocorreu um erro. Tente novamente.";
		
	toast.error(defaultMessage, {
		...errorToastConfig,
		...customConfig,
		toastId: "generic-error",
	});
};

export default toastError;
