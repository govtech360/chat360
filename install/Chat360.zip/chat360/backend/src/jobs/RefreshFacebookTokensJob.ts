import { CronJob } from "cron";
import { checkAndRefreshExpiredTokens } from "../services/FacebookServices/RefreshTokenService";
import logger from "../utils/logger";

/**
 * Cron Job que verifica e renova tokens do Facebook/Instagram
 * Executa diariamente às 03:00 AM
 */
export const refreshFacebookTokensJob = new CronJob(
  "0 3 * * *", // Todo dia às 03:00
  async function () {
    logger.info("Starting Facebook/Instagram token refresh job");
    try {
      await checkAndRefreshExpiredTokens();
      logger.info("Facebook/Instagram token refresh job completed successfully");
    } catch (error) {
      logger.error("Error in Facebook/Instagram token refresh job:", error);
    }
  },
  null,
  false, // Não inicia automaticamente
  "America/Sao_Paulo"
);

/**
 * Inicia o cron job
 */
export const startRefreshFacebookTokensJob = () => {
  refreshFacebookTokensJob.start();
  logger.info("Facebook/Instagram token refresh job scheduled (daily at 03:00 AM)");
};



