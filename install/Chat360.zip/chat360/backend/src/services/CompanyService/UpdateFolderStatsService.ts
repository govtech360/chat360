import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";
import path from "path";
import Company from "../../models/Company";

const execPromise = promisify(exec);

interface FolderStats {
  folderSize: string;
  numberFileFolder: string;
  updatedAtFolder: string;
}

const UpdateFolderStatsService = async (companyId: number): Promise<FolderStats | null> => {
  const publicPath = path.join(__dirname, "../../../public");
  const folderPath = path.join(publicPath, `company${companyId}`);

  // Verifica se a pasta existe
  if (!fs.existsSync(folderPath)) {
    console.log(`[UpdateFolderStats] Pasta não encontrada para empresa ${companyId}`);
    return null;
  }

  try {
    // Tamanho da pasta (formato humano: KB, MB, GB)
    const { stdout: sizeOutput } = await execPromise(`du -sh "${folderPath}" 2>/dev/null || echo "0"`);
    const folderSize = sizeOutput.split("\t")[0].trim() || "0";

    // Contar total de arquivos
    const { stdout: countOutput } = await execPromise(`find "${folderPath}" -type f 2>/dev/null | wc -l || echo "0"`);
    const numberFileFolder = countOutput.trim() || "0";

    // Última modificação (timestamp do arquivo mais recente)
    let updatedAtFolder = new Date().toISOString();
    try {
      const { stdout: timeOutput } = await execPromise(
        `find "${folderPath}" -type f -printf '%T@\n' 2>/dev/null | sort -n | tail -1 || echo ""`
      );
      
      if (timeOutput.trim()) {
        const timestamp = parseFloat(timeOutput.trim());
        updatedAtFolder = new Date(timestamp * 1000).toISOString();
      }
    } catch (error) {
      // Se falhar ao obter timestamp, usa data atual
      console.log(`[UpdateFolderStats] Não foi possível obter última modificação para empresa ${companyId}, usando data atual`);
    }

    // Atualizar no banco de dados
    await Company.update(
      {
        folderSize,
        numberFileFolder,
        updatedAtFolder
      },
      {
        where: { id: companyId }
      }
    );

    console.log(`[UpdateFolderStats] ✓ Empresa ${companyId}: ${folderSize}, ${numberFileFolder} arquivos, última modificação: ${updatedAtFolder}`);

    return {
      folderSize,
      numberFileFolder,
      updatedAtFolder
    };
  } catch (error) {
    console.error(`[UpdateFolderStats] ✗ Erro ao atualizar estatísticas da empresa ${companyId}:`, error);
    return null;
  }
};

/**
 * Atualiza estatísticas de pastas para todas as empresas
 */
export const UpdateAllCompaniesFolderStats = async (): Promise<void> => {
  try {
    console.log("[UpdateAllCompaniesFolderStats] Iniciando atualização de estatísticas de todas as empresas...");
    
    // Buscar todas as empresas ativas
    const companies = await Company.findAll({
      attributes: ["id", "name"],
      where: {
        status: true
      }
    });

    console.log(`[UpdateAllCompaniesFolderStats] Encontradas ${companies.length} empresas ativas`);

    let successCount = 0;
    let errorCount = 0;

    // Processar cada empresa
    for (const company of companies) {
      const result = await UpdateFolderStatsService(company.id);
      if (result) {
        successCount++;
      } else {
        errorCount++;
      }
    }

    console.log(`[UpdateAllCompaniesFolderStats] Concluído! Sucesso: ${successCount}, Erros: ${errorCount}`);
  } catch (error) {
    console.error("[UpdateAllCompaniesFolderStats] Erro ao atualizar estatísticas:", error);
    throw error;
  }
};

export default UpdateFolderStatsService;

