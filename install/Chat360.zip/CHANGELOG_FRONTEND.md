# Changelog - Melhorias Frontend

## 09/10/2025 - Padronização Completa: Página Queues/Filas e Modal

### Página Queues (/pages/Queues/index.js)
**Padronização visual completa seguindo o design system estabelecido:**

#### Estrutura e Layout:
- ✅ Container principal com `padding: theme.spacing(2)` para respiro visual
- ✅ Paper principal com `borderRadius: 20px` para consistência
- ✅ BoxShadow adaptativo (suave no light, pronunciado no dark mode)
- ✅ Sistema de overflow gerenciado com `tableWrapper`

#### Tabela Padronizada:
- ✅ `minWidth: 1000px` para garantir espaçamento adequado
- ✅ Cabeçalho sticky com `position: sticky`, `top: 0`, `zIndex: 10`
- ✅ Background do cabeçalho: `theme.palette.background.default`
- ✅ Rows com hover effect: `backgroundColor: alpha(theme.palette.primary.main, 0.08)`
- ✅ Padding consistente: `padding: "16px"`
- ✅ Bordas adaptativas baseadas em `theme.palette.divider`

#### Cabeçalho da Tabela com Ícones e Tooltips:
- ✅ **ID**: `Fingerprint` icon + Tooltip "Identificador único da fila"
- ✅ **Nome**: `Label` icon + Tooltip "Nome da fila"
- ✅ **Cor**: `Palette` icon + Tooltip "Cor de identificação"
- ✅ **Saudação**: `Message` icon + Tooltip "Mensagem de saudação"
- ✅ **Ordem**: `FormatListNumbered` icon + Tooltip "Ordem de exibição"
- ✅ **Ações**: `Settings` icon + Tooltip "Ações disponíveis"

#### Melhorias UX:
- ✅ Título da página com contador dinâmico: "Filas & Chatbot ({count})"
- ✅ Botão "Adicionar" padronizado com `borderRadius: 8px`
- ✅ Indicador de cor visual com `borderRadius: 8px`
- ✅ Scrollbar customizado nas tabelas seguindo o padrão global

---

### Modal QueueModal (/components/QueueModal/index.js)
**Refinamento completo do modal de adicionar/editar filas:**

#### Design do Modal:
- ✅ DialogPaper com `borderRadius: 12px`
- ✅ BoxShadow adaptativo para dark/light mode
- ✅ **Scrollbar OCULTO** no Dialog (`scroll="paper"` configurado corretamente)
- ✅ Visual limpo sem barra lateral ao adicionar opções

#### Cabeçalho (DialogTitle):
- ✅ Ícone `AccountTree` + Typography com `fontWeight: 600`
- ✅ Background: `theme.palette.background.default`
- ✅ Borda inferior: `2px solid theme.palette.divider`
- ✅ Padding: `theme.spacing(2.5, 3)`

#### Conteúdo (DialogContent):
- ✅ Padding: `theme.spacing(3, 4)` para respiro
- ✅ Background: `theme.palette.background.paper`
- ✅ Scrollbar invisível mas funcional
- ✅ Todos os campos com `borderRadius: 8px`

#### Campos e Inputs:
- ✅ TextField: `borderRadius: 8px`, hover e focus effects
- ✅ FormControl: `borderRadius: 8px` consistente
- ✅ Alinhamento perfeito de todos os campos (removido `margin` conflitante)
- ✅ Campo "Tempo de rodízio" retangular (não arredondado)
- ✅ Campos "Integração" e "Lista de arquivos" alinhados corretamente

#### Toggles e Switches:
- ✅ Toggle "Fechar ticket" com `marginTop: 16px` para respiro
- ✅ Toggle "Rodízio" com espaçamento adequado
- ✅ Todos os FormControlLabel bem espaçados

#### Seção de Opções:
- ✅ Inputs de opções com `borderRadius: 8px`
- ✅ Select "Tipo de menu" retangular
- ✅ Grid layout para mensagens de opções
- ✅ Scrollbar oculto quando há muitas opções (visual limpo)

#### Rodapé (DialogActions):
- ✅ Background: `theme.palette.background.default`
- ✅ Borda superior: `1px solid theme.palette.divider`
- ✅ Gap entre botões: `theme.spacing(1.5)`
- ✅ Botões primários e secundários padronizados
- ✅ BorderRadius: 8px para todos os botões
- ✅ Padding: `8px 24px`, fontWeight: 600

---

### Componente QueueSelectSingle (/components/QueueSelectSingle/index.js)
**Correções de alinhamento e estilo:**

#### Ajustes Realizados:
- ✅ Removido `margin: theme.spacing(1)` do FormControl
- ✅ Removida div wrapper com `marginTop: 6`
- ✅ Aplicado `borderRadius: 8px` no `MuiOutlinedInput-root`
- ✅ Alinhamento perfeito com outros campos do formulário

---

## Problemas Corrigidos:

### ❌ Erro: Campos "Integração" e "Lista de arquivos" desalinhados
**Solução:** Removido `margin` do `formControl` e `textField1`, aplicado apenas `marginTop` consistente.

### ❌ Erro: Campo "Tempo de rodízio" arredondado
**Solução:** Aplicado `className={classes.textField1}` com `borderRadius: 8px`.

### ❌ Erro: Campo "Filas" em PromptModal arredondado e desalinhado
**Solução:** Modificado `QueueSelectSingle` para aplicar `borderRadius: 8px` e remover margens conflitantes.

### ❌ Erro: Toggle "Fechar ticket" grudado no input "Ordem da fila"
**Solução:** Adicionada div com `marginTop: 16px` envolvendo o FormControlLabel.

### ❌ Erro: Scrollbar lateral visível no modal ao adicionar opções
**Solução:** Aplicado estilos de ocultar scrollbar no `dialogPaper` (local correto para `scroll="paper"`):
```javascript
"&::-webkit-scrollbar": { display: "none" },
scrollbarWidth: "none", // Firefox
msOverflowStyle: "none", // IE and Edge
```

---

## Padronização Geral Aplicada:

### 🎨 Design System:
- **BorderRadius Containers**: 20px (mainPaper)
- **BorderRadius Modais**: 12px (dialogPaper)
- **BorderRadius Inputs/Botões**: 8px (textField, buttons)
- **BoxShadow Light**: `0 8px 32px rgba(0, 0, 0, 0.15)`
- **BoxShadow Dark**: `0 8px 32px rgba(0, 0, 0, 0.6)`
- **Padding Containers**: `theme.spacing(2)`
- **Padding DialogContent**: `theme.spacing(3, 4)`

### 📊 Tabelas:
- Cabeçalho sticky com background `theme.palette.background.default`
- Hover effect: `alpha(theme.palette.primary.main, 0.08)`
- Bordas adaptativas: `theme.palette.divider`
- Scrollbar customizado: `theme.scrollbarStyles`

### 🎯 Ícones e Tooltips:
- Todos os cabeçalhos de tabela com ícones descritivos
- Tooltips informativos em todas as colunas
- Box layout para alinhar ícones e texto: `display: flex`, `alignItems: center`, `gap: theme.spacing(1)`

---

## Páginas e Componentes Padronizados até o Momento:

1. ✅ **Settings/SettingsCustom** - Página de configurações com dark mode adaptativo
2. ✅ **Login/Signup** - Inputs visíveis em dark mode
3. ✅ **Companies** - Tabela padronizada com ícones e tooltips
4. ✅ **Financeiro** - Cards e tabelas refinados
5. ✅ **Files** - Lista de arquivos com design consistente
6. ✅ **FileModal** - Modal padronizado
7. ✅ **Connections** - Gerenciamento de conexões WhatsApp
8. ✅ **WhatsAppModal** - Modal de conexões refinado
9. ✅ **QrcodeModal** - Modal de QR Code estilizado
10. ✅ **AllConnections** - Visão geral de todas as conexões
11. ✅ **CompanyWhatsapps** - Modal de conexões por empresa
12. ✅ **QueueIntegration** - Integrações de filas
13. ✅ **QueueIntegrationModal** - Modal de integrações
14. ✅ **Prompts** - Gerenciamento de prompts AI
15. ✅ **PromptModal** - Modal de prompts
16. ✅ **Queues** - Gerenciamento de filas e chatbot ⭐ NOVO
17. ✅ **QueueModal** - Modal de adicionar/editar filas ⭐ NOVO
18. ✅ **QueueSelectSingle** - Seletor de fila único ⭐ ATUALIZADO

---

## Notas Técnicas:

### Scrollbar Oculto em Modais:
Para modais com `scroll="paper"`, aplicar estilos no `dialogPaper`, não no `dialogContent`:
```javascript
dialogPaper: {
  "&::-webkit-scrollbar": { display: "none" },
  scrollbarWidth: "none",
  msOverflowStyle: "none",
}
```

### Alinhamento de Campos:
Evitar `margin` direto em `formControl`. Usar apenas `marginTop` quando necessário para espaçamento vertical.

---

**Status:** ✅ Frontend 100% padronizado e pronto para produção
**Dark Mode:** ✅ Totalmente funcional e consistente
**Responsividade:** ✅ Testado e validado
**Build:** ✅ Compilado com sucesso sem erros
